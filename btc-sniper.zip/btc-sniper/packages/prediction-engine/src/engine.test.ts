import { describe, it } from "node:test";
import assert from "node:assert/strict";
import type { BookTicker, Candle, IndicatorSnapshot, MarketStructure, TradeFlowSnapshot } from "@btc-sniper/types";
import { PredictionEngine, type PredictionEngineInput } from "./engine.js";
import { defaultStrategyConfig } from "./default-config.js";

const engine = new PredictionEngine();

function fillerCandle(i: number): Candle {
  return {
    symbol: "BTCUSDT",
    interval: "5m",
    openTime: i * 300_000,
    closeTime: i * 300_000 + 299_999,
    open: 100,
    high: 101,
    low: 99,
    close: 100,
    volume: 100,
    quoteVolume: 10_000,
    trades: 50,
    takerBuyBaseVolume: 50,
    takerBuySellVolume: 50,
    isClosed: true,
  };
}

function baseCandles(lastCandle: Candle): Candle[] {
  const filler = Array.from({ length: 24 }, (_, i) => fillerCandle(i));
  return [...filler, lastCandle];
}

function baseBookTicker(overrides: Partial<BookTicker>): BookTicker {
  return {
    symbol: "BTCUSDT",
    bidPrice: 100,
    bidQty: 50,
    askPrice: 100.01,
    askQty: 50,
    spread: 0.01,
    spreadBps: 1,
    timestamp: Date.now(),
    ...overrides,
  };
}

function baseTradeFlow(overrides: Partial<TradeFlowSnapshot>): TradeFlowSnapshot {
  return {
    symbol: "BTCUSDT",
    windowMs: 60_000,
    buyVolume: 50,
    sellVolume: 50,
    totalVolume: 100,
    volumeDelta: 0,
    buyRatio: 0.5,
    tradeCount: 100,
    timestamp: Date.now(),
    ...overrides,
  };
}

const flatStructure: MarketStructure = {
  higherHigh: false,
  higherLow: false,
  lowerHigh: false,
  lowerLow: false,
  breakout: false,
  breakdown: false,
  support: null,
  resistance: null,
};

function baseInput(overrides: Partial<PredictionEngineInput>): PredictionEngineInput {
  return {
    symbol: "BTCUSDT",
    cycleId: "cycle-1",
    timestamp: Date.now(),
    price: 100,
    indicators: {
      ema9: null,
      ema21: null,
      ema50: 100,
      ema200: null,
      vwap: null,
      rsi14: 50,
      macd: { macd: 0, signal: 0, histogram: 0 },
      stochRsi: null,
      roc: null,
      atr14: 50,
      bollinger: { upper: 105, middle: 100, lower: 95, bandwidth: 0.02 },
    },
    structure: flatStructure,
    tradeFlow: baseTradeFlow({}),
    bookTicker: baseBookTicker({}),
    candles5m: baseCandles(fillerCandle(24)),
    cycleRemainingMs: 200_000,
    stale: false,
    ...overrides,
  };
}

describe("PredictionEngine — bullish scenario", () => {
  it("produces a high-confidence BUY_UP signal when all factors align bullishly", () => {
    const indicators: IndicatorSnapshot = {
      ema9: 110,
      ema21: 105,
      ema50: 100,
      ema200: 90,
      vwap: 108,
      rsi14: 90,
      macd: { macd: 20, signal: 0, histogram: 20 },
      stochRsi: null,
      roc: null,
      atr14: 50,
      bollinger: { upper: 105, middle: 100, lower: 95, bandwidth: 0.02 },
    };
    const structure: MarketStructure = { ...flatStructure, higherHigh: true, higherLow: true, breakout: true };
    const lastCandle: Candle = { ...fillerCandle(24), open: 100, high: 112, low: 99, close: 110, takerBuyBaseVolume: 90, takerBuySellVolume: 10 };

    const input = baseInput({
      price: 115,
      indicators,
      structure,
      tradeFlow: baseTradeFlow({ buyVolume: 90, sellVolume: 10, totalVolume: 100, buyRatio: 0.9, volumeDelta: 80 }),
      bookTicker: baseBookTicker({ bidQty: 90, askQty: 10 }),
      candles5m: baseCandles(lastCandle),
    });

    const prediction = engine.generate(input, defaultStrategyConfig);

    assert.equal(prediction.signal, "BUY_UP");
    assert.ok(prediction.upProbability > prediction.downProbability);
    assert.ok(prediction.confidence >= defaultStrategyConfig.minConfidenceToTrade);
    assert.notEqual(prediction.signalStrength, "NONE");
  });
});

describe("PredictionEngine — bearish scenario", () => {
  it("produces a high-confidence BUY_DOWN signal when all factors align bearishly", () => {
    const indicators: IndicatorSnapshot = {
      ema9: 90,
      ema21: 95,
      ema50: 100,
      ema200: 110,
      vwap: 92,
      rsi14: 10,
      macd: { macd: -20, signal: 0, histogram: -20 },
      stochRsi: null,
      roc: null,
      atr14: 50,
      bollinger: { upper: 105, middle: 100, lower: 95, bandwidth: 0.02 },
    };
    const structure: MarketStructure = { ...flatStructure, lowerHigh: true, lowerLow: true, breakdown: true };
    const lastCandle: Candle = { ...fillerCandle(24), open: 100, high: 101, low: 88, close: 90, takerBuyBaseVolume: 10, takerBuySellVolume: 90 };

    const input = baseInput({
      price: 85,
      indicators,
      structure,
      tradeFlow: baseTradeFlow({ buyVolume: 10, sellVolume: 90, totalVolume: 100, buyRatio: 0.1, volumeDelta: -80 }),
      bookTicker: baseBookTicker({ bidQty: 10, askQty: 90 }),
      candles5m: baseCandles(lastCandle),
    });

    const prediction = engine.generate(input, defaultStrategyConfig);

    assert.equal(prediction.signal, "BUY_DOWN");
    assert.ok(prediction.downProbability > prediction.upProbability);
    assert.ok(prediction.confidence >= defaultStrategyConfig.minConfidenceToTrade);
  });
});

describe("PredictionEngine — neutral scenario", () => {
  it("does not trade when there is no directional edge", () => {
    const input = baseInput({});
    const prediction = engine.generate(input, defaultStrategyConfig);
    assert.equal(prediction.signal, "NO_TRADE");
  });
});

describe("PredictionEngine — conflicting signals scenario", () => {
  it("flags SIGNAL CONFLICT when factor count disagrees with the weighted directional bias", () => {
    // Trend + momentum + price action lean bearish (3 of 5 factors), while
    // volume + order flow lean strongly bullish (2 of 5) with enough weight
    // and magnitude to flip the combined score positive — a textbook
    // "majority disagrees with the weighted outcome" conflict.
    const indicators: IndicatorSnapshot = {
      ema9: 100,
      ema21: 105,
      ema50: 102,
      ema200: 110,
      vwap: 101,
      rsi14: 31.25,
      macd: { macd: 0, signal: 0, histogram: 0 },
      stochRsi: null,
      roc: null,
      atr14: 50,
      bollinger: { upper: 105, middle: 100, lower: 95, bandwidth: 0.02 },
    };
    const lastCandle: Candle = { ...fillerCandle(24), open: 101, high: 105, low: 95, close: 99, takerBuyBaseVolume: 95, takerBuySellVolume: 5 };

    const input = baseInput({
      price: 98,
      indicators,
      structure: flatStructure,
      tradeFlow: baseTradeFlow({ buyVolume: 95, sellVolume: 5, totalVolume: 100, buyRatio: 0.95, volumeDelta: 90 }),
      bookTicker: baseBookTicker({ bidQty: 95, askQty: 5 }),
      candles5m: baseCandles(lastCandle),
    });

    const prediction = engine.generate(input, defaultStrategyConfig);

    assert.equal(prediction.signal, "NO_TRADE");
    assert.equal(prediction.reason, "SIGNAL CONFLICT");
  });
});

describe("PredictionEngine — data quality gates", () => {
  it("refuses to trade on stale market data", () => {
    const input = baseInput({ stale: true });
    const prediction = engine.generate(input, defaultStrategyConfig);
    assert.equal(prediction.signal, "NO_TRADE");
    assert.equal(prediction.reason, "MARKET DATA STALE");
    assert.equal(prediction.entryStatus, "AVOID");
  });

  it("refuses to trade when market data is incomplete", () => {
    const input = baseInput({ indicators: { ...baseInput({}).indicators, macd: null } });
    const prediction = engine.generate(input, defaultStrategyConfig);
    assert.equal(prediction.signal, "NO_TRADE");
    assert.equal(prediction.reason, "INSUFFICIENT MARKET DATA");
  });

  it("refuses to trade when the spread is too wide", () => {
    const input = baseInput({ bookTicker: baseBookTicker({ spreadBps: 999 }) });
    const prediction = engine.generate(input, defaultStrategyConfig);
    assert.equal(prediction.signal, "NO_TRADE");
    assert.equal(prediction.reason, "SPREAD TOO WIDE");
  });
});

describe("PredictionEngine — execution timing", () => {
  function bullishInput(overrides: Partial<PredictionEngineInput>): PredictionEngineInput {
    const indicators: IndicatorSnapshot = {
      ema9: 110,
      ema21: 105,
      ema50: 100,
      ema200: 90,
      vwap: 108,
      rsi14: 90,
      macd: { macd: 20, signal: 0, histogram: 20 },
      stochRsi: null,
      roc: null,
      atr14: 50,
      bollinger: { upper: 105, middle: 100, lower: 95, bandwidth: 0.02 },
    };
    const structure: MarketStructure = { ...flatStructure, higherHigh: true, higherLow: true, breakout: true };
    const lastCandle: Candle = { ...fillerCandle(24), open: 100, high: 112, low: 99, close: 110, takerBuyBaseVolume: 90, takerBuySellVolume: 10 };
    return baseInput({
      price: 115,
      indicators,
      structure,
      tradeFlow: baseTradeFlow({ buyVolume: 90, sellVolume: 10, totalVolume: 100, buyRatio: 0.9, volumeDelta: 80 }),
      bookTicker: baseBookTicker({ bidQty: 90, askQty: 10 }),
      candles5m: baseCandles(lastCandle),
      ...overrides,
    });
  }

  it("scores a clean, mid-window, tight-spread instant as PEAK/GOOD, not just OPTIMAL", () => {
    // Dead center of the tradeable window: earlyEntryThresholdMs=20_000,
    // lateEntryThresholdMs=30_000 of a 300_000ms cycle -> window is
    // [20_000, 270_000], midpoint elapsed = 145_000 -> cycleRemainingMs = 155_000.
    const input = bullishInput({ cycleRemainingMs: 155_000 });
    const prediction = engine.generate(input, defaultStrategyConfig);

    assert.equal(prediction.entryStatus, "OPTIMAL");
    assert.ok(prediction.executionTiming.score >= 60, `expected a high timing score, got ${prediction.executionTiming.score}`);
    assert.ok(["PEAK", "GOOD"].includes(prediction.executionTiming.label));
    assert.ok(prediction.executionTiming.windowScore > 90, "midpoint of the window should score near the top of the window curve");
  });

  it("scores WAIT/0 during EARLY even though the signal itself is clean", () => {
    const input = bullishInput({ cycleRemainingMs: 295_000 }); // elapsed = 5_000ms, well under earlyEntryThresholdMs
    const prediction = engine.generate(input, defaultStrategyConfig);

    assert.equal(prediction.entryStatus, "EARLY");
    assert.equal(prediction.executionTiming.score, 0);
    assert.equal(prediction.executionTiming.label, "WAIT");
  });

  it("scores WAIT/0 whenever entryStatus is AVOID", () => {
    const input = bullishInput({ stale: true });
    const prediction = engine.generate(input, defaultStrategyConfig);

    assert.equal(prediction.entryStatus, "AVOID");
    assert.equal(prediction.executionTiming.score, 0);
    assert.equal(prediction.executionTiming.label, "WAIT");
  });

  it("rewards a tighter spread with a higher spreadScore", () => {
    const tight = engine.generate(
      bullishInput({ cycleRemainingMs: 155_000, bookTicker: baseBookTicker({ bidQty: 90, askQty: 10, spreadBps: 0.5 }) }),
      defaultStrategyConfig
    );
    const wide = engine.generate(
      bullishInput({ cycleRemainingMs: 155_000, bookTicker: baseBookTicker({ bidQty: 90, askQty: 10, spreadBps: 4.5 }) }),
      defaultStrategyConfig
    );
    assert.ok(tight.executionTiming.spreadScore > wide.executionTiming.spreadScore);
  });
});
