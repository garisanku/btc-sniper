import type {
  BookTicker,
  Candle,
  FactorScore,
  IndicatorSnapshot,
  MarketStructure,
  Prediction,
  StrategyConfig,
  TradeFlowSnapshot,
} from "@btc-sniper/types";
import { trendFactor, momentumFactor, volumeFactor, orderFlowFactor, priceActionFactor, volatilityFactor } from "./factors.js";
import { computeEntryStatus, computeExecutionTiming } from "./entry-timing.js";
import { computeSniperEvaluation } from "./sniper.js";
import { normalizeWeights } from "./default-config.js";
import { clamp, sign } from "./util.js";

export interface PredictionEngineInput {
  symbol: string;
  cycleId: string;
  timestamp: number;
  price: number;
  indicators: IndicatorSnapshot;
  structure: MarketStructure;
  tradeFlow: TradeFlowSnapshot;
  bookTicker: BookTicker | null;
  candles5m: Candle[];
  cycleRemainingMs: number;
  stale: boolean;
  riskHalted?: boolean;
}

const DIRECTIONAL_FACTOR_NAMES = ["trend", "momentum", "volume", "orderFlow", "priceAction"] as const;

export class PredictionEngine {
  generate(input: PredictionEngineInput, config: StrategyConfig): Prediction {
    const weights = normalizeWeights(config.weights);
    const relativeVolume = computeRelativeVolume(input.candles5m);
    const spreadBps = input.bookTicker?.spreadBps ?? Number.POSITIVE_INFINITY;

    const dataComplete =
      input.indicators.ema50 !== null &&
      input.indicators.rsi14 !== null &&
      input.indicators.macd !== null &&
      input.indicators.bollinger !== null &&
      input.indicators.atr14 !== null &&
      input.bookTicker !== null &&
      input.tradeFlow.totalVolume > 0 &&
      input.candles5m.length >= 20;

    const factorInputs = {
      price: input.price,
      indicators: input.indicators,
      structure: input.structure,
      tradeFlow: input.tradeFlow,
      bookTicker: input.bookTicker,
      candles5m: input.candles5m,
      relativeVolume,
    };

    const trend = trendFactor(factorInputs);
    const momentum = momentumFactor(factorInputs);
    const volume = volumeFactor(factorInputs);
    const orderFlow = orderFlowFactor(factorInputs);
    const priceAction = priceActionFactor(factorInputs);

    const directional = [trend, momentum, volume, orderFlow, priceAction];
    const dirWeightTotal = DIRECTIONAL_FACTOR_NAMES.reduce((sum, n) => sum + weights[n], 0) || 1;
    const directionalBias =
      directional.reduce((sum, f) => sum + f.score * weights[f.name as keyof typeof weights], 0) / dirWeightTotal;

    const volatility = volatilityFactor(factorInputs, directionalBias);

    const allFactors: FactorScore[] = [trend, momentum, volume, orderFlow, priceAction, volatility].map((f) => {
      const w = weights[f.name as keyof typeof weights];
      return { ...f, weight: w, weighted: f.score * w };
    });

    const combinedScore = clamp(
      allFactors.reduce((sum, f) => sum + f.weighted, 0),
      -100,
      100
    );

    const upProbability = clamp(50 + combinedScore / 2, 0, 100);
    const downProbability = 100 - upProbability;

    const combinedSign = sign(combinedScore);
    const agreeing = directional.filter((f) => combinedSign !== 0 && sign(f.score) === combinedSign).length;
    const agreement = combinedSign === 0 ? 0 : agreeing / directional.length;

    const confidence = clamp(Math.abs(combinedScore) * (0.6 + 0.4 * agreement), 0, 100);

    const bandwidthAbnormal = input.indicators.bollinger !== null && (input.indicators.bollinger.bandwidth > 0.05 || input.indicators.bollinger.bandwidth < 0.004);

    const { signal, reason } = decideSignal({
      combinedScore,
      confidence,
      agreement,
      spreadBps,
      dataComplete,
      stale: input.stale,
      config,
    });

    const signalStrength =
      confidence >= 80 ? "STRONG" : confidence >= 60 ? "MODERATE" : confidence >= 40 ? "WEAK" : "NONE";

    const entryTimingInput = {
      cycleMs: config.cycleMs,
      cycleRemainingMs: input.cycleRemainingMs,
      confidence,
      agreement,
      spreadBps,
      bandwidthAbnormal,
      dataComplete,
      stale: input.stale,
      hasSignal: signal !== "NO_TRADE",
      riskHalted: input.riskHalted ?? false,
    };

    const entryStatus = computeEntryStatus(config, entryTimingInput);

    const executionTiming = computeExecutionTiming(
      config,
      { ...entryTimingInput, bandwidth: input.indicators.bollinger?.bandwidth ?? null },
      entryStatus
    );

    const sniperEval = computeSniperEvaluation(allFactors, combinedScore, confidence, relativeVolume, spreadBps, config.sniper);

    return {
      symbol: input.symbol,
      timestamp: input.timestamp,
      cycleId: input.cycleId,
      upProbability,
      downProbability,
      confidence,
      signal,
      signalStrength,
      reason,
      entryStatus,
      executionTiming,
      price: input.price,
      volume: input.tradeFlow.totalVolume,
      factors: allFactors,
      sniperChecks: sniperEval.checks,
      sniperAligned: sniperEval.aligned,
      sniperReady: sniperEval.ready,
      cycleRemainingMs: input.cycleRemainingMs,
    };
  }
}

function computeRelativeVolume(candles5m: Candle[]): number {
  if (candles5m.length < 2) return 1;
  const current = candles5m[candles5m.length - 1]!;
  const history = candles5m.slice(Math.max(0, candles5m.length - 21), candles5m.length - 1);
  if (history.length === 0) return 1;
  const avg = history.reduce((sum, c) => sum + c.volume, 0) / history.length;
  if (avg <= 0) return 1;
  return current.volume / avg;
}

function decideSignal(params: {
  combinedScore: number;
  confidence: number;
  agreement: number;
  spreadBps: number;
  dataComplete: boolean;
  stale: boolean;
  config: StrategyConfig;
}): { signal: Prediction["signal"]; reason: string } {
  const { combinedScore, confidence, agreement, spreadBps, dataComplete, stale, config } = params;

  if (stale) return { signal: "NO_TRADE", reason: "MARKET DATA STALE" };
  if (!dataComplete) return { signal: "NO_TRADE", reason: "INSUFFICIENT MARKET DATA" };
  if (spreadBps > config.maxSpreadBpsToTrade) return { signal: "NO_TRADE", reason: "SPREAD TOO WIDE" };
  if (agreement < 0.5) return { signal: "NO_TRADE", reason: "SIGNAL CONFLICT" };
  if (confidence < config.minConfidenceToTrade) return { signal: "NO_TRADE", reason: "CONFIDENCE BELOW THRESHOLD" };
  if (combinedScore > 0) return { signal: "BUY_UP", reason: "Bullish multi-factor confluence" };
  if (combinedScore < 0) return { signal: "BUY_DOWN", reason: "Bearish multi-factor confluence" };
  return { signal: "NO_TRADE", reason: "NEUTRAL — no directional edge" };
}
