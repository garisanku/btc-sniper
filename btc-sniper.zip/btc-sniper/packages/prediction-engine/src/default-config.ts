import type { StrategyConfig } from "@btc-sniper/types";

/**
 * Default strategy configuration. Every value here is meant to be
 * overridden via .env or the dashboard's strategy config panel — nothing
 * in the prediction engine hard-codes these numbers internally.
 */
export const defaultStrategyConfig: StrategyConfig = {
  symbol: "BTCUSDT",
  cycleMs: 5 * 60_000,
  weights: {
    trend: 0.2,
    momentum: 0.2,
    volume: 0.2,
    orderFlow: 0.15,
    priceAction: 0.15,
    volatility: 0.1,
  },
  sniper: {
    minConfidence: 80,
    minVolumeRatio: 1.2,
    maxSpreadBps: 3,
    minSignalAlignment: 5,
    maxTradesPerCycle: 1,
  },
  risk: {
    maxRiskPerTradePct: 1,
    maxDailyLossPct: 5,
    maxConsecutiveLosses: 3,
    maxTradesPerHour: 6,
    cooldownAfterLossMs: 5 * 60_000,
    minConfidence: 65,
    maxPositionSizeUsd: 500,
  },
  mode: "SNIPER",
  executionMode: "PAPER",
  minConfidenceToTrade: 65,
  maxSpreadBpsToTrade: 5,
  lateEntryThresholdMs: 30_000,
  earlyEntryThresholdMs: 20_000,
  staleDataMs: 15_000,
};

export function normalizeWeights(weights: StrategyConfig["weights"]): StrategyConfig["weights"] {
  const total = weights.trend + weights.momentum + weights.volume + weights.orderFlow + weights.priceAction + weights.volatility;
  if (total <= 0) return defaultStrategyConfig.weights;
  return {
    trend: weights.trend / total,
    momentum: weights.momentum / total,
    volume: weights.volume / total,
    orderFlow: weights.orderFlow / total,
    priceAction: weights.priceAction / total,
    volatility: weights.volatility / total,
  };
}
