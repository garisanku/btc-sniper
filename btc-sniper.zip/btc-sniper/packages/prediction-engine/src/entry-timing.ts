import type { EntryStatus, ExecutionTiming, StrategyConfig, TimingLabel } from "@btc-sniper/types";
import { clamp } from "./util.js";

export interface EntryTimingInput {
  cycleMs: number;
  cycleRemainingMs: number;
  confidence: number;
  agreement: number; // 0..1, fraction of directional factors agreeing with the overall bias
  spreadBps: number;
  bandwidthAbnormal: boolean;
  dataComplete: boolean;
  stale: boolean;
  hasSignal: boolean; // true if signal is BUY_UP / BUY_DOWN (not NO_TRADE)
  riskHalted: boolean;
}

/**
 * The Smart Entry Timing Engine: classifies where in the 5-minute cycle we
 * are and whether conditions currently support entering a trade at all.
 */
export function computeEntryStatus(config: StrategyConfig, input: EntryTimingInput): EntryStatus {
  if (input.stale || !input.dataComplete || input.riskHalted || !input.hasSignal) return "AVOID";

  const elapsed = config.cycleMs - input.cycleRemainingMs;

  if (elapsed < config.earlyEntryThresholdMs) return "EARLY";

  if (input.cycleRemainingMs < config.lateEntryThresholdMs) {
    // Too close to expiry is only workable if everything else is still clean.
    if (input.spreadBps > config.maxSpreadBpsToTrade || input.confidence < config.minConfidenceToTrade) {
      return "AVOID";
    }
    return "LATE";
  }

  if (
    input.confidence < config.minConfidenceToTrade ||
    input.agreement < 0.5 ||
    input.bandwidthAbnormal ||
    input.spreadBps > config.maxSpreadBpsToTrade
  ) {
    return "AVOID";
  }

  return "OPTIMAL";
}

export interface ExecutionTimingInput extends EntryTimingInput {
  bandwidth: number | null; // bollinger bandwidth, null if indicators aren't complete yet
}

// Same low/high bandwidth cutoffs computeEntryStatus's bandwidthAbnormal
// check uses (see engine.ts) — below LOW the market is essentially flat
// (nothing to ride), above HIGH it's whipsawing too hard to trust any one
// instant. The "calm" sweet spot is the midpoint between them.
const CALM_BANDWIDTH_LOW = 0.004;
const CALM_BANDWIDTH_HIGH = 0.05;
const CALM_BANDWIDTH_MID = (CALM_BANDWIDTH_LOW + CALM_BANDWIDTH_HIGH) / 2;

function windowPositionScore(config: StrategyConfig, cycleRemainingMs: number): number {
  const elapsed = config.cycleMs - cycleRemainingMs;
  const windowStart = config.earlyEntryThresholdMs;
  const windowEnd = config.cycleMs - config.lateEntryThresholdMs;
  if (windowEnd <= windowStart) return 50; // degenerate config — no real window to peak within
  if (elapsed <= windowStart || elapsed >= windowEnd) return 0;
  const progress = (elapsed - windowStart) / (windowEnd - windowStart); // 0..1 across the tradeable window
  // Triangular curve: 0 at either edge of the window, 100 dead in the middle.
  return clamp(100 * (1 - Math.abs(progress - 0.5) * 2), 0, 100);
}

function spreadTightnessScore(spreadBps: number, maxSpreadBpsToTrade: number): number {
  if (!Number.isFinite(spreadBps) || maxSpreadBpsToTrade <= 0) return 0;
  return clamp(100 * (1 - spreadBps / maxSpreadBpsToTrade), 0, 100);
}

function confidenceAboveThresholdScore(confidence: number, minConfidenceToTrade: number): number {
  const headroom = 100 - minConfidenceToTrade;
  if (headroom <= 0) return confidence >= minConfidenceToTrade ? 100 : 0;
  return clamp(((confidence - minConfidenceToTrade) / headroom) * 100, 0, 100);
}

function volatilityCalmScore(bandwidth: number | null): number {
  if (bandwidth === null) return 50; // unknown — neutral, neither reward nor punish
  if (bandwidth <= CALM_BANDWIDTH_LOW || bandwidth >= CALM_BANDWIDTH_HIGH) return 20;
  const distFromMid = Math.abs(bandwidth - CALM_BANDWIDTH_MID) / (CALM_BANDWIDTH_HIGH - CALM_BANDWIDTH_LOW);
  return clamp(100 - distFromMid * 160, 0, 100);
}

function timingLabel(score: number): TimingLabel {
  if (score >= 80) return "PEAK";
  if (score >= 60) return "GOOD";
  if (score >= 40) return "FAIR";
  return "WAIT";
}

/**
 * Precision Execution Timing. `entryStatus` only says which coarse bucket
 * of the 5-minute cycle we're in (EARLY/OPTIMAL/LATE/AVOID); this scores
 * how good *this exact instant* is to actually fire, continuously from
 * 0-100, by blending:
 *  - position within the tradeable window (a bell curve peaking mid-window,
 *    not a flat "yes/no" bucket),
 *  - how tight the spread is right now relative to the max allowed,
 *  - how much headroom confidence has above the trade threshold, and
 *  - how "calm" recent volatility looks (neither dead-flat nor erratic).
 * The bot ticks once per second, so this recomputes every tick — the
 * dashboard can show a live "fire now" pulse instead of a static bucket.
 * EARLY and AVOID both score 0/WAIT because bot-engine's own gating
 * (see evaluateTradeDecision) never executes in either state anyway —
 * showing anything else there would just be misleading.
 */
export function computeExecutionTiming(
  config: StrategyConfig,
  input: ExecutionTimingInput,
  entryStatus: EntryStatus
): ExecutionTiming {
  if (entryStatus === "AVOID" || entryStatus === "EARLY" || !input.hasSignal) {
    return {
      score: 0,
      label: "WAIT",
      reason: !input.hasSignal ? "No directional signal yet" : entryStatus === "EARLY" ? "Too early in the cycle to fire" : "Conditions currently rule out entry",
      windowScore: 0,
      spreadScore: 0,
      confidenceScore: 0,
      volatilityScore: 0,
    };
  }

  const windowScore = windowPositionScore(config, input.cycleRemainingMs);
  const spreadScore = spreadTightnessScore(input.spreadBps, config.maxSpreadBpsToTrade);
  const confidenceScore = confidenceAboveThresholdScore(input.confidence, config.minConfidenceToTrade);
  const volatilityScore = volatilityCalmScore(input.bandwidth);

  const score = clamp(windowScore * 0.35 + spreadScore * 0.25 + confidenceScore * 0.25 + volatilityScore * 0.15, 0, 100);
  const label = timingLabel(score);

  const reason =
    label === "PEAK"
      ? "Window position, spread, and confidence are all lined up — best instant to fire"
      : label === "GOOD"
      ? "Conditions are solid, though not everything is peaking at once"
      : label === "FAIR"
      ? "Tradeable, but at least one factor (window position/spread/confidence/volatility) is mediocre"
      : "Technically tradeable, but this instant is a weak one — most factors are working against it";

  return { score, label, reason, windowScore, spreadScore, confidenceScore, volatilityScore };
}
