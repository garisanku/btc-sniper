import type { BookTicker, Candle, FactorScore, IndicatorSnapshot, MarketStructure, TradeFlowSnapshot } from "@btc-sniper/types";
import { clamp, sign } from "./util.js";

export interface FactorInputs {
  price: number;
  indicators: IndicatorSnapshot;
  structure: MarketStructure;
  tradeFlow: TradeFlowSnapshot;
  bookTicker: BookTicker | null;
  candles5m: Candle[];
  relativeVolume: number; // current 5m volume / average of recent 5m volumes
}

/**
 * Every factor below returns a score in [-100, 100]: positive = bullish
 * lean, negative = bearish lean. These are explainable heuristics combining
 * several inputs, not a statistically-fit model — the point is a
 * transparent, configurable multi-factor system rather than a single magic
 * indicator. Weights (applied by the engine) are what make it tunable.
 */

export function trendFactor(input: FactorInputs): FactorScore {
  const { indicators, structure, price } = input;
  let score = 0;
  const notes: string[] = [];

  if (indicators.ema9 !== null && indicators.ema21 !== null) {
    score += indicators.ema9 > indicators.ema21 ? 25 : -25;
    notes.push(`EMA9${indicators.ema9 > indicators.ema21 ? ">" : "<"}EMA21`);
  }
  if (indicators.ema21 !== null && indicators.ema50 !== null) {
    score += indicators.ema21 > indicators.ema50 ? 25 : -25;
    notes.push(`EMA21${indicators.ema21 > indicators.ema50 ? ">" : "<"}EMA50`);
  }
  if (indicators.ema50 !== null && indicators.ema200 !== null) {
    score += indicators.ema50 > indicators.ema200 ? 20 : -20;
    notes.push(`EMA50${indicators.ema50 > indicators.ema200 ? ">" : "<"}EMA200`);
  }
  if (indicators.vwap !== null) {
    score += price > indicators.vwap ? 15 : -15;
    notes.push(`price ${price > indicators.vwap ? "above" : "below"} VWAP`);
  }
  if (structure.higherHigh && structure.higherLow) {
    score += 15;
    notes.push("HH/HL structure");
  }
  if (structure.lowerHigh && structure.lowerLow) {
    score -= 15;
    notes.push("LH/LL structure");
  }
  if (structure.breakout) {
    score += 10;
    notes.push("breakout");
  }
  if (structure.breakdown) {
    score -= 10;
    notes.push("breakdown");
  }

  return {
    name: "trend",
    score: clamp(score, -100, 100),
    weight: 0,
    weighted: 0,
    detail: notes.length ? notes.join(", ") : "insufficient trend data",
  };
}

export function momentumFactor(input: FactorInputs): FactorScore {
  const { indicators } = input;
  let score = 0;
  let parts = 0;
  const notes: string[] = [];

  if (indicators.rsi14 !== null) {
    score += clamp((indicators.rsi14 - 50) * 1.6, -80, 80);
    parts++;
    notes.push(`RSI ${indicators.rsi14.toFixed(1)}`);
  }
  if (indicators.macd !== null && indicators.atr14 !== null && indicators.atr14 > 0) {
    const normalizedHist = indicators.macd.histogram / indicators.atr14;
    score += clamp(normalizedHist * 40, -40, 40);
    parts++;
    notes.push(`MACD hist ${indicators.macd.histogram.toFixed(2)} (${indicators.macd.histogram >= 0 ? "bullish" : "bearish"})`);
  }
  if (indicators.stochRsi !== null) {
    score += clamp((indicators.stochRsi.k - 50) * 0.8, -40, 40);
    parts++;
    notes.push(`StochRSI %K ${indicators.stochRsi.k.toFixed(1)}`);
  }
  if (indicators.roc !== null) {
    score += clamp(indicators.roc * 6, -30, 30);
    parts++;
    notes.push(`ROC ${indicators.roc.toFixed(2)}%`);
  }

  const normalized = parts > 0 ? score / Math.max(1, parts / 4) : 0;
  return {
    name: "momentum",
    score: clamp(normalized, -100, 100),
    weight: 0,
    weighted: 0,
    detail: notes.length ? notes.join(", ") : "insufficient momentum data",
  };
}

export function volumeFactor(input: FactorInputs): FactorScore {
  const { tradeFlow, relativeVolume } = input;
  if (tradeFlow.totalVolume <= 0) {
    return { name: "volume", score: 0, weight: 0, weighted: 0, detail: "no volume data" };
  }
  const directional = (tradeFlow.buyRatio - 0.5) * 2; // -1..1
  const volumeMultiplier = clamp(relativeVolume, 0.4, 1.6) / 1.0;
  const score = clamp(directional * 100 * clamp(volumeMultiplier, 0.5, 1.3), -100, 100);
  return {
    name: "volume",
    score,
    weight: 0,
    weighted: 0,
    detail: `buy ratio ${(tradeFlow.buyRatio * 100).toFixed(1)}%, rel. volume ${relativeVolume.toFixed(2)}x`,
  };
}

export function orderFlowFactor(input: FactorInputs): FactorScore {
  const { bookTicker, candles5m } = input;
  let score = 0;
  let parts = 0;
  const notes: string[] = [];

  if (bookTicker) {
    const totalQty = bookTicker.bidQty + bookTicker.askQty;
    if (totalQty > 0) {
      const imbalance = ((bookTicker.bidQty - bookTicker.askQty) / totalQty) * 100;
      score += imbalance;
      parts++;
      notes.push(`bid/ask imbalance ${imbalance.toFixed(1)}`);
    }
  }

  const lastCandle = candles5m[candles5m.length - 1];
  if (lastCandle && lastCandle.volume > 0) {
    const takerBuy = lastCandle.takerBuyBaseVolume;
    const takerSell = lastCandle.takerBuySellVolume;
    const total = takerBuy + takerSell;
    if (total > 0) {
      const ratioScore = ((takerBuy / total - 0.5) * 2) * 100;
      score += ratioScore;
      parts++;
      notes.push(`taker buy/sell ${(takerBuy / total * 100).toFixed(1)}%`);
    }
  }

  const normalized = parts > 0 ? score / parts : 0;
  return {
    name: "orderFlow",
    score: clamp(normalized, -100, 100),
    weight: 0,
    weighted: 0,
    detail: notes.length ? notes.join(", ") : "insufficient order-flow data",
  };
}

export function priceActionFactor(input: FactorInputs): FactorScore {
  const { candles5m } = input;
  const c = candles5m[candles5m.length - 1];
  if (!c) return { name: "priceAction", score: 0, weight: 0, weighted: 0, detail: "no candle data" };

  const range = Math.max(c.high - c.low, 1e-9);
  const body = c.close - c.open;
  const bodyRatio = body / range;
  let score = bodyRatio * 100;

  const upperWick = c.high - Math.max(c.open, c.close);
  const lowerWick = Math.min(c.open, c.close) - c.low;
  const notes = [`body ratio ${(bodyRatio * 100).toFixed(0)}%`];

  if (lowerWick > Math.abs(body) * 1.5 && lowerWick > upperWick) {
    score += 15;
    notes.push("bullish rejection wick");
  }
  if (upperWick > Math.abs(body) * 1.5 && upperWick > lowerWick) {
    score -= 15;
    notes.push("bearish rejection wick");
  }

  return { name: "priceAction", score: clamp(score, -100, 100), weight: 0, weighted: 0, detail: notes.join(", ") };
}

/**
 * Volatility does not have an inherent up/down direction, so it is modeled
 * as a *modifier* of the directional bias formed by the other five factors:
 * normal volatility amplifies confidence in the prevailing bias, a squeeze
 * (very low Bollinger bandwidth) dampens it because direction hasn't
 * resolved yet, and abnormally high bandwidth (blow-off / chop) also
 * dampens it because reversals become more likely.
 */
export function volatilityFactor(input: FactorInputs, directionalBias: number): FactorScore {
  const { indicators } = input;
  if (!indicators.bollinger || indicators.atr14 === null) {
    return { name: "volatility", score: 0, weight: 0, weighted: 0, detail: "insufficient volatility data" };
  }
  const bw = indicators.bollinger.bandwidth;
  let magnitude: number;
  let label: string;
  if (bw < 0.004) {
    magnitude = 20;
    label = "squeeze (low bandwidth)";
  } else if (bw > 0.05) {
    magnitude = 30;
    label = "abnormal (wide bandwidth)";
  } else {
    magnitude = 90;
    label = "normal";
  }
  const biasSign = sign(directionalBias);
  const score = biasSign * magnitude * (clamp(Math.abs(directionalBias), 0, 100) / 100);
  return {
    name: "volatility",
    score: clamp(score, -100, 100),
    weight: 0,
    weighted: 0,
    detail: `${label}, BB width ${(bw * 100).toFixed(2)}%`,
  };
}
