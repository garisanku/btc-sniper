import type { FactorScore, SniperAlignmentCheck, SniperRequirements } from "@btc-sniper/types";
import { sign } from "./util.js";

export interface SniperEvaluation {
  checks: SniperAlignmentCheck[];
  aligned: number;
  ready: boolean;
}

/**
 * Sniper Mode: a trade only qualifies when a majority of the six factors
 * agree with the overall directional bias by a meaningful margin AND the
 * aggregate confidence/volume/spread requirements are met. This is
 * deliberately stricter than the base "BUY_UP/BUY_DOWN" signal.
 */
export function computeSniperEvaluation(
  factors: FactorScore[],
  combinedScore: number,
  confidence: number,
  volumeRatio: number,
  spreadBps: number,
  requirements: SniperRequirements
): SniperEvaluation {
  const dirSign = sign(combinedScore);
  const checks: SniperAlignmentCheck[] = factors.map((f) => {
    const passed = dirSign !== 0 && sign(f.score) === dirSign && Math.abs(f.score) >= 15;
    return {
      name: f.name,
      passed,
      detail: `${f.name}: score ${f.score.toFixed(1)} — ${f.detail}`,
    };
  });

  const aligned = checks.filter((c) => c.passed).length;
  const ready =
    dirSign !== 0 &&
    confidence >= requirements.minConfidence &&
    volumeRatio >= requirements.minVolumeRatio &&
    spreadBps <= requirements.maxSpreadBps &&
    aligned >= requirements.minSignalAlignment;

  return { checks, aligned, ready };
}
