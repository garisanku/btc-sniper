import { randomUUID } from "node:crypto";
import type { Trade, TradeExecutionOutcome, TradeSignal } from "@btc-sniper/types";
import type { TradingExecutor } from "./executor.js";

export interface PaperExecutorConfig {
  initialBalance: number;
  /** Binary-market payout ratio: a WIN returns stake + stake*payoutRatio. */
  payoutRatio: number;
  maxPositionSizeUsd: number;
  strategyName: string;
}

export const defaultPaperExecutorConfig: PaperExecutorConfig = {
  initialBalance: 10_000,
  payoutRatio: 0.85,
  maxPositionSizeUsd: 500,
  strategyName: "sniper-v1",
};

/**
 * Simulates a binary 5-minute up/down market with a fixed payout ratio
 * (win: stake * payoutRatio profit; loss: stake forfeited; exact-tie exit:
 * push, stake returned). This never talks to a network — it is explicitly
 * a simulation, and every Trade it produces is tagged mode: "PAPER" so it
 * can never be confused with a real fill downstream.
 */
export class PaperTradingExecutor implements TradingExecutor {
  private balance: number;
  private readonly trades = new Map<string, Trade>();

  constructor(private readonly config: PaperExecutorConfig = defaultPaperExecutorConfig) {
    this.balance = config.initialBalance;
  }

  async openTrade(signal: TradeSignal): Promise<TradeExecutionOutcome> {
    if (signal.sizeUsd <= 0) {
      return { ok: false, error: { code: "INVALID_SIGNAL", message: "Trade size must be positive." } };
    }
    if (signal.sizeUsd > this.config.maxPositionSizeUsd) {
      return {
        ok: false,
        error: {
          code: "RISK_LIMIT",
          message: `Requested size ${signal.sizeUsd} exceeds max position size ${this.config.maxPositionSizeUsd}.`,
        },
      };
    }
    if (signal.sizeUsd > this.balance) {
      return { ok: false, error: { code: "INSUFFICIENT_BALANCE", message: `Balance ${this.balance} is below requested stake ${signal.sizeUsd}.` } };
    }

    this.balance -= signal.sizeUsd;

    const trade: Trade = {
      id: randomUUID(),
      cycleId: signal.cycleId,
      symbol: signal.symbol,
      direction: signal.direction,
      entryPrice: signal.entryPrice,
      exitPrice: null,
      entryTime: signal.entryTime,
      exitTime: null,
      confidence: signal.confidence,
      upProbability: signal.prediction.upProbability,
      downProbability: signal.prediction.downProbability,
      buyVolume: 0,
      sellVolume: 0,
      volumeDelta: 0,
      signalStrength: signal.prediction.signalStrength,
      result: "OPEN",
      pnl: null,
      sizeUsd: signal.sizeUsd,
      mode: "PAPER",
      strategyName: this.config.strategyName,
      createdAt: Date.now(),
    };

    this.trades.set(trade.id, trade);
    return { ok: true, trade };
  }

  async closeTrade(tradeId: string, exitPrice: number): Promise<TradeExecutionOutcome> {
    const trade = this.trades.get(tradeId);
    if (!trade) {
      return { ok: false, error: { code: "NOT_FOUND", message: `No open trade with id ${tradeId}.` } };
    }
    if (trade.result !== "OPEN") {
      return { ok: false, error: { code: "INVALID_SIGNAL", message: `Trade ${tradeId} is already settled.` } };
    }

    const moved = exitPrice - trade.entryPrice;
    let result: Trade["result"];
    if (moved === 0) {
      result = "PUSH";
    } else if ((trade.direction === "UP" && moved > 0) || (trade.direction === "DOWN" && moved < 0)) {
      result = "WIN";
    } else {
      result = "LOSS";
    }

    let pnl: number;
    if (result === "WIN") {
      const profit = trade.sizeUsd * this.config.payoutRatio;
      this.balance += trade.sizeUsd + profit;
      pnl = profit;
    } else if (result === "PUSH") {
      this.balance += trade.sizeUsd;
      pnl = 0;
    } else {
      pnl = -trade.sizeUsd;
    }

    const settled: Trade = { ...trade, exitPrice, exitTime: Date.now(), result, pnl };
    this.trades.set(tradeId, settled);
    return { ok: true, trade: settled };
  }

  async getBalance(): Promise<number> {
    return this.balance;
  }

  async getOpenTrades(): Promise<Trade[]> {
    return [...this.trades.values()].filter((t) => t.result === "OPEN");
  }
}
