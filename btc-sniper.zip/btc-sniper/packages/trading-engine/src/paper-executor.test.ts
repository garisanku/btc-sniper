import { describe, it, beforeEach } from "node:test";
import assert from "node:assert/strict";
import type { Prediction, TradeSignal } from "@btc-sniper/types";
import { PaperTradingExecutor } from "./paper-executor.js";

function close(actual: number, expected: number, tolerance = 1e-6) {
  assert.ok(Math.abs(actual - expected) <= tolerance, `expected ${actual} to be close to ${expected}`);
}

function makePrediction(overrides: Partial<Prediction> = {}): Prediction {
  return {
    symbol: "BTCUSDT",
    timestamp: Date.now(),
    cycleId: "cycle-1",
    upProbability: 75,
    downProbability: 25,
    confidence: 75,
    signal: "BUY_UP",
    signalStrength: "STRONG",
    reason: "test",
    entryStatus: "OPTIMAL",
    executionTiming: { score: 90, label: "PEAK", reason: "test", windowScore: 100, spreadScore: 90, confidenceScore: 90, volatilityScore: 80 },
    price: 100,
    volume: 100,
    factors: [],
    sniperChecks: [],
    sniperAligned: 6,
    sniperReady: true,
    cycleRemainingMs: 200_000,
    ...overrides,
  };
}

function makeSignal(overrides: Partial<TradeSignal> = {}): TradeSignal {
  return {
    cycleId: "cycle-1",
    symbol: "BTCUSDT",
    direction: "UP",
    confidence: 75,
    entryPrice: 100,
    entryTime: Date.now(),
    expiryTime: Date.now() + 300_000,
    prediction: makePrediction(),
    sizeUsd: 100,
    ...overrides,
  };
}

describe("PaperTradingExecutor", () => {
  let executor: PaperTradingExecutor;

  beforeEach(() => {
    executor = new PaperTradingExecutor({ initialBalance: 1000, payoutRatio: 0.8, maxPositionSizeUsd: 500, strategyName: "test" });
  });

  it("opens a trade, deducting the stake from balance", async () => {
    const outcome = await executor.openTrade(makeSignal({ sizeUsd: 100 }));
    assert.equal(outcome.ok, true);
    if (!outcome.ok) throw new Error("expected ok");
    assert.equal(outcome.trade.result, "OPEN");
    assert.equal(outcome.trade.mode, "PAPER");
    assert.equal(await executor.getBalance(), 900);
    assert.equal((await executor.getOpenTrades()).length, 1);
  });

  it("settles a winning UP trade with the configured payout ratio", async () => {
    const opened = await executor.openTrade(makeSignal({ direction: "UP", entryPrice: 100, sizeUsd: 100 }));
    if (!opened.ok) throw new Error("expected ok");
    const closed = await executor.closeTrade(opened.trade.id, 105);
    assert.equal(closed.ok, true);
    if (!closed.ok) throw new Error("expected ok");
    assert.equal(closed.trade.result, "WIN");
    close(closed.trade.pnl!, 80); // 100 * 0.8
    close(await executor.getBalance(), 1000 - 100 + 100 + 80);
  });

  it("settles a losing DOWN trade by forfeiting the stake", async () => {
    const opened = await executor.openTrade(makeSignal({ direction: "DOWN", entryPrice: 100, sizeUsd: 100 }));
    if (!opened.ok) throw new Error("expected ok");
    const closed = await executor.closeTrade(opened.trade.id, 105); // price went up, DOWN loses
    if (!closed.ok) throw new Error("expected ok");
    assert.equal(closed.trade.result, "LOSS");
    close(closed.trade.pnl!, -100);
    close(await executor.getBalance(), 900); // stake already deducted, nothing returned
  });

  it("treats an unchanged exit price as a push and refunds the stake", async () => {
    const opened = await executor.openTrade(makeSignal({ direction: "UP", entryPrice: 100, sizeUsd: 100 }));
    if (!opened.ok) throw new Error("expected ok");
    const closed = await executor.closeTrade(opened.trade.id, 100);
    if (!closed.ok) throw new Error("expected ok");
    assert.equal(closed.trade.result, "PUSH");
    assert.equal(closed.trade.pnl, 0);
    assert.equal(await executor.getBalance(), 1000);
  });

  it("rejects opening a trade beyond the max position size", async () => {
    const outcome = await executor.openTrade(makeSignal({ sizeUsd: 600 }));
    assert.equal(outcome.ok, false);
    if (outcome.ok) throw new Error("expected failure");
    assert.equal(outcome.error.code, "RISK_LIMIT");
  });

  it("rejects opening a trade beyond available balance", async () => {
    const executor2 = new PaperTradingExecutor({ initialBalance: 50, payoutRatio: 0.8, maxPositionSizeUsd: 500, strategyName: "test" });
    const outcome = await executor2.openTrade(makeSignal({ sizeUsd: 100 }));
    assert.equal(outcome.ok, false);
    if (outcome.ok) throw new Error("expected failure");
    assert.equal(outcome.error.code, "INSUFFICIENT_BALANCE");
  });

  it("fails to close a trade that does not exist (never fakes a successful close)", async () => {
    const outcome = await executor.closeTrade("does-not-exist", 100);
    assert.equal(outcome.ok, false);
    if (outcome.ok) throw new Error("expected failure");
    assert.equal(outcome.error.code, "NOT_FOUND");
  });

  it("fails to close an already-settled trade twice", async () => {
    const opened = await executor.openTrade(makeSignal({ sizeUsd: 100 }));
    if (!opened.ok) throw new Error("expected ok");
    await executor.closeTrade(opened.trade.id, 105);
    const second = await executor.closeTrade(opened.trade.id, 105);
    assert.equal(second.ok, false);
  });
});
