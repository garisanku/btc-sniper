import type { RiskConfig, RiskState, Trade } from "@btc-sniper/types";

export interface RiskCheckResult {
  allowed: boolean;
  reason: string | null;
}

/**
 * Central risk gate. The bot loop must call `canOpenTrade` before every
 * execution and `recordTradeResult` after every settlement — this is the
 * one place that can halt the whole system, independent of what the
 * prediction engine says.
 */
export class RiskManager {
  private tradeTimestamps: number[] = [];
  private state: RiskState = {
    dailyPnl: 0,
    dailyPnlPct: 0,
    consecutiveLosses: 0,
    tradesLastHour: 0,
    cooldownUntil: null,
    halted: false,
    haltReason: null,
  };

  constructor(private readonly config: RiskConfig, private startOfDayBalance: number) {}

  updateConfig(config: RiskConfig): void {
    Object.assign(this.config, config);
  }

  getState(): RiskState {
    this.pruneHourlyWindow();
    return { ...this.state, tradesLastHour: this.tradeTimestamps.length };
  }

  /**
   * Evaluates every configured limit against a proposed trade.
   *
   * `skipConfidenceGate` exempts only the minimum-confidence check — a
   * signal-quality gate, not a capital-risk one — for an operator-initiated
   * manual trade where there is deliberately no prediction to be confident
   * about. Every capital-based limit (halted/kill switch, cooldown, position
   * size, trades per hour, consecutive losses, daily loss) still applies
   * regardless of this flag; those exist to protect the balance, not to
   * second-guess the prediction engine, so a manual override never bypasses
   * them.
   */
  canOpenTrade(params: { confidence: number; sizeUsd: number; now?: number; skipConfidenceGate?: boolean }): RiskCheckResult {
    const now = params.now ?? Date.now();

    if (this.state.halted) {
      return { allowed: false, reason: `BOT HALTED: ${this.state.haltReason ?? "risk limit reached"}` };
    }
    if (this.state.cooldownUntil !== null && now < this.state.cooldownUntil) {
      const remainingSec = Math.ceil((this.state.cooldownUntil - now) / 1000);
      return { allowed: false, reason: `COOLDOWN ACTIVE (${remainingSec}s remaining)` };
    }
    if (!params.skipConfidenceGate && params.confidence < this.config.minConfidence) {
      return { allowed: false, reason: `CONFIDENCE ${params.confidence.toFixed(1)}% BELOW MINIMUM ${this.config.minConfidence}%` };
    }
    if (params.sizeUsd > this.config.maxPositionSizeUsd) {
      return { allowed: false, reason: `POSITION SIZE ${params.sizeUsd} EXCEEDS MAX ${this.config.maxPositionSizeUsd}` };
    }

    this.pruneHourlyWindow(now);
    if (this.tradeTimestamps.length >= this.config.maxTradesPerHour) {
      return { allowed: false, reason: `MAX TRADES PER HOUR REACHED (${this.config.maxTradesPerHour})` };
    }
    if (this.state.consecutiveLosses >= this.config.maxConsecutiveLosses) {
      return { allowed: false, reason: `MAX CONSECUTIVE LOSSES REACHED (${this.config.maxConsecutiveLosses})` };
    }

    const dailyLossLimit = -(this.config.maxDailyLossPct / 100) * this.startOfDayBalance;
    if (this.state.dailyPnl <= dailyLossLimit) {
      return { allowed: false, reason: "DAILY LOSS LIMIT" };
    }

    return { allowed: true, reason: null };
  }

  /** Call once a trade is settled to update streaks, daily P&L, and halts. */
  recordTradeResult(trade: Trade, now = Date.now()): void {
    this.tradeTimestamps.push(now);
    this.pruneHourlyWindow(now);

    if (trade.pnl !== null) {
      this.state.dailyPnl += trade.pnl;
      this.state.dailyPnlPct = this.startOfDayBalance > 0 ? (this.state.dailyPnl / this.startOfDayBalance) * 100 : 0;
    }

    if (trade.result === "LOSS") {
      this.state.consecutiveLosses += 1;
      this.state.cooldownUntil = now + this.config.cooldownAfterLossMs;
    } else if (trade.result === "WIN") {
      this.state.consecutiveLosses = 0;
    }

    const dailyLossLimit = -(this.config.maxDailyLossPct / 100) * this.startOfDayBalance;
    if (this.state.dailyPnl <= dailyLossLimit) {
      this.halt("DAILY LOSS LIMIT");
      return;
    }
    if (this.state.consecutiveLosses >= this.config.maxConsecutiveLosses) {
      this.halt(`MAX CONSECUTIVE LOSSES (${this.config.maxConsecutiveLosses})`);
    }
  }

  halt(reason: string): void {
    this.state.halted = true;
    this.state.haltReason = reason;
  }

  /** Kill switch / emergency stop — an explicit manual halt, same effect as a limit breach. */
  emergencyStop(reason = "MANUAL EMERGENCY STOP"): void {
    this.halt(reason);
  }

  resume(): void {
    this.state.halted = false;
    this.state.haltReason = null;
  }

  resetDaily(newStartOfDayBalance: number): void {
    this.startOfDayBalance = newStartOfDayBalance;
    this.state.dailyPnl = 0;
    this.state.dailyPnlPct = 0;
  }

  private pruneHourlyWindow(now = Date.now()): void {
    const oneHourAgo = now - 60 * 60 * 1000;
    this.tradeTimestamps = this.tradeTimestamps.filter((t) => t > oneHourAgo);
  }
}
