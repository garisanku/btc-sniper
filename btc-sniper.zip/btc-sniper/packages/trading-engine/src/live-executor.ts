import type { Trade, TradeExecutionOutcome, TradeSignal } from "@btc-sniper/types";
import type { TradingExecutor } from "./executor.js";

export interface LiveBrokerAdapter {
  /** Human-readable name of the broker/prediction-market this adapter targets. */
  name: string;
  placeOrder(signal: TradeSignal): Promise<Trade>;
  settleOrder(tradeId: string, exitPrice: number): Promise<Trade>;
  fetchBalance(): Promise<number>;
  fetchOpenPositions(): Promise<Trade[]>;
}

/**
 * LiveTradingExecutor is the real-money adapter boundary. It deliberately
 * ships with NO working broker wired in: the task spec references a
 * "Trading API" via TRADING_API_KEY/TRADING_API_SECRET but names no
 * concrete, documented prediction-market trading API to integrate against.
 * Rather than fabricate a fake integration or silently pretend trades
 * succeeded, every method fails loudly with UNSUPPORTED until a real
 * `LiveBrokerAdapter` (built against that broker's actual documented API)
 * is injected. This is the honest version of "never fake successful
 * execution": the system defaults to paper trading and live mode simply
 * does not function until someone wires in a real, working adapter.
 */
export class LiveTradingExecutor implements TradingExecutor {
  constructor(private readonly adapter: LiveBrokerAdapter | null = null) {}

  async openTrade(signal: TradeSignal): Promise<TradeExecutionOutcome> {
    if (!this.adapter) {
      return {
        ok: false,
        error: {
          code: "UNSUPPORTED",
          message:
            "Live trading has no broker adapter configured. Implement a LiveBrokerAdapter against your prediction-market's documented API and pass it to LiveTradingExecutor before switching EXECUTION_MODE to LIVE.",
        },
      };
    }
    try {
      const trade = await this.adapter.placeOrder(signal);
      return { ok: true, trade };
    } catch (err) {
      return { ok: false, error: { code: "PROVIDER_ERROR", message: err instanceof Error ? err.message : String(err) } };
    }
  }

  async closeTrade(tradeId: string, exitPrice: number): Promise<TradeExecutionOutcome> {
    if (!this.adapter) {
      return { ok: false, error: { code: "UNSUPPORTED", message: "Live trading has no broker adapter configured." } };
    }
    try {
      const trade = await this.adapter.settleOrder(tradeId, exitPrice);
      return { ok: true, trade };
    } catch (err) {
      return { ok: false, error: { code: "PROVIDER_ERROR", message: err instanceof Error ? err.message : String(err) } };
    }
  }

  async getBalance(): Promise<number> {
    if (!this.adapter) throw new Error("Live trading has no broker adapter configured.");
    return this.adapter.fetchBalance();
  }

  async getOpenTrades(): Promise<Trade[]> {
    if (!this.adapter) throw new Error("Live trading has no broker adapter configured.");
    return this.adapter.fetchOpenPositions();
  }
}
