import { describe, it } from "node:test";
import assert from "node:assert/strict";
import type { RiskConfig, Trade } from "@btc-sniper/types";
import { RiskManager } from "./risk-manager.js";

const baseConfig: RiskConfig = {
  maxRiskPerTradePct: 1,
  maxDailyLossPct: 5,
  maxConsecutiveLosses: 3,
  maxTradesPerHour: 6,
  cooldownAfterLossMs: 60_000,
  minConfidence: 65,
  maxPositionSizeUsd: 500,
};

function makeTrade(overrides: Partial<Trade>): Trade {
  return {
    id: "t1",
    cycleId: "c1",
    symbol: "BTCUSDT",
    direction: "UP",
    entryPrice: 100,
    exitPrice: 105,
    entryTime: Date.now(),
    exitTime: Date.now(),
    confidence: 80,
    upProbability: 80,
    downProbability: 20,
    buyVolume: 0,
    sellVolume: 0,
    volumeDelta: 0,
    signalStrength: "STRONG",
    result: "WIN",
    pnl: 80,
    sizeUsd: 100,
    mode: "PAPER",
    strategyName: "test",
    createdAt: Date.now(),
    ...overrides,
  };
}

describe("RiskManager — position and confidence gates", () => {
  it("blocks trades below the minimum confidence", () => {
    const rm = new RiskManager(baseConfig, 10_000);
    const result = rm.canOpenTrade({ confidence: 50, sizeUsd: 100 });
    assert.equal(result.allowed, false);
    assert.match(result.reason ?? "", /CONFIDENCE/);
  });

  it("blocks trades exceeding max position size", () => {
    const rm = new RiskManager(baseConfig, 10_000);
    const result = rm.canOpenTrade({ confidence: 90, sizeUsd: 600 });
    assert.equal(result.allowed, false);
    assert.match(result.reason ?? "", /POSITION SIZE/);
  });

  it("allows a trade that satisfies every gate", () => {
    const rm = new RiskManager(baseConfig, 10_000);
    const result = rm.canOpenTrade({ confidence: 90, sizeUsd: 100 });
    assert.equal(result.allowed, true);
  });
});

describe("RiskManager — max trades per hour", () => {
  it("blocks once the hourly trade cap is reached", () => {
    const rm = new RiskManager({ ...baseConfig, maxTradesPerHour: 2, cooldownAfterLossMs: 0 }, 10_000);
    const now = Date.now();
    rm.recordTradeResult(makeTrade({ result: "WIN", pnl: 10 }), now);
    rm.recordTradeResult(makeTrade({ result: "WIN", pnl: 10 }), now + 1000);
    const result = rm.canOpenTrade({ confidence: 90, sizeUsd: 100, now: now + 2000 });
    assert.equal(result.allowed, false);
    assert.match(result.reason ?? "", /MAX TRADES PER HOUR/);
  });
});

describe("RiskManager — consecutive losses", () => {
  it("halts the bot after the configured number of consecutive losses", () => {
    const rm = new RiskManager({ ...baseConfig, maxConsecutiveLosses: 3, cooldownAfterLossMs: 0 }, 10_000);
    const now = Date.now();
    rm.recordTradeResult(makeTrade({ result: "LOSS", pnl: -100 }), now);
    rm.recordTradeResult(makeTrade({ result: "LOSS", pnl: -100 }), now + 1000);
    assert.equal(rm.getState().halted, false);
    rm.recordTradeResult(makeTrade({ result: "LOSS", pnl: -100 }), now + 2000);
    const state = rm.getState();
    assert.equal(state.halted, true);
    assert.match(state.haltReason ?? "", /CONSECUTIVE LOSSES/);

    const check = rm.canOpenTrade({ confidence: 90, sizeUsd: 100, now: now + 3000 });
    assert.equal(check.allowed, false);
    assert.match(check.reason ?? "", /HALTED/);
  });

  it("resets the consecutive loss streak on a win", () => {
    const rm = new RiskManager({ ...baseConfig, cooldownAfterLossMs: 0 }, 10_000);
    const now = Date.now();
    rm.recordTradeResult(makeTrade({ result: "LOSS", pnl: -100 }), now);
    rm.recordTradeResult(makeTrade({ result: "LOSS", pnl: -100 }), now + 1000);
    rm.recordTradeResult(makeTrade({ result: "WIN", pnl: 80 }), now + 2000);
    assert.equal(rm.getState().consecutiveLosses, 0);
  });
});

describe("RiskManager — max daily loss", () => {
  it("halts the bot once cumulative daily loss breaches the configured percentage", () => {
    const rm = new RiskManager({ ...baseConfig, maxDailyLossPct: 5, maxConsecutiveLosses: 100, cooldownAfterLossMs: 0 }, 10_000);
    const now = Date.now();
    // 5% of 10,000 = 500. A single -500 loss should trip the limit.
    rm.recordTradeResult(makeTrade({ result: "LOSS", pnl: -500 }), now);
    const state = rm.getState();
    assert.equal(state.halted, true);
    assert.match(state.haltReason ?? "", /DAILY LOSS LIMIT/);
  });
});

describe("RiskManager — cooldown after loss", () => {
  it("blocks new trades until the cooldown window elapses", () => {
    const rm = new RiskManager({ ...baseConfig, cooldownAfterLossMs: 60_000, maxConsecutiveLosses: 100 }, 10_000);
    const now = Date.now();
    rm.recordTradeResult(makeTrade({ result: "LOSS", pnl: -50 }), now);
    assert.equal(rm.canOpenTrade({ confidence: 90, sizeUsd: 100, now: now + 1000 }).allowed, false);
    assert.equal(rm.canOpenTrade({ confidence: 90, sizeUsd: 100, now: now + 61_000 }).allowed, true);
  });
});

describe("RiskManager — kill switch", () => {
  it("emergencyStop halts trading immediately and resume re-enables it", () => {
    const rm = new RiskManager(baseConfig, 10_000);
    rm.emergencyStop("operator requested stop");
    assert.equal(rm.canOpenTrade({ confidence: 95, sizeUsd: 100 }).allowed, false);
    assert.equal(rm.getState().haltReason, "operator requested stop");

    rm.resume();
    assert.equal(rm.canOpenTrade({ confidence: 95, sizeUsd: 100 }).allowed, true);
  });
});
