import type { Trade, TradeExecutionOutcome, TradeSignal } from "@btc-sniper/types";

/**
 * TradingExecutor is the sole boundary between prediction/strategy logic and
 * whatever actually moves money. The prediction engine and bot loop only
 * ever talk to this interface, never to Binance, a broker SDK, or a
 * database directly — swapping paper trading for a real broker means
 * writing a new class here, nothing else in the system changes.
 *
 * `closeTrade` takes the settlement price explicitly: any real prediction
 * market / broker settlement API needs a price (or its own internal oracle
 * result) to resolve a position, so this is a minimal, honest extension of
 * the interface sketched in the spec rather than a deviation from it.
 */
export interface TradingExecutor {
  openTrade(signal: TradeSignal): Promise<TradeExecutionOutcome>;
  closeTrade(tradeId: string, exitPrice: number): Promise<TradeExecutionOutcome>;
  getBalance(): Promise<number>;
  getOpenTrades(): Promise<Trade[]>;
}
