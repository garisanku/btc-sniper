import { describe, it } from "node:test";
import assert from "node:assert/strict";
import type { Prediction, TradeSignal } from "@btc-sniper/types";
import { LiveTradingExecutor } from "./live-executor.js";

function makeSignal(): TradeSignal {
  const prediction: Prediction = {
    symbol: "BTCUSDT",
    timestamp: Date.now(),
    cycleId: "c1",
    upProbability: 80,
    downProbability: 20,
    confidence: 80,
    signal: "BUY_UP",
    signalStrength: "STRONG",
    reason: "test",
    entryStatus: "OPTIMAL",
    executionTiming: { score: 90, label: "PEAK", reason: "test", windowScore: 100, spreadScore: 90, confidenceScore: 90, volatilityScore: 80 },
    price: 100,
    volume: 100,
    factors: [],
    sniperChecks: [],
    sniperAligned: 6,
    sniperReady: true,
    cycleRemainingMs: 100_000,
  };
  return {
    cycleId: "c1",
    symbol: "BTCUSDT",
    direction: "UP",
    confidence: 80,
    entryPrice: 100,
    entryTime: Date.now(),
    expiryTime: Date.now() + 300_000,
    prediction,
    sizeUsd: 100,
  };
}

describe("LiveTradingExecutor without a broker adapter", () => {
  it("never fakes a successful open — it fails loudly with UNSUPPORTED", async () => {
    const executor = new LiveTradingExecutor(null);
    const outcome = await executor.openTrade(makeSignal());
    assert.equal(outcome.ok, false);
    if (outcome.ok) throw new Error("expected failure");
    assert.equal(outcome.error.code, "UNSUPPORTED");
  });

  it("never fakes a successful close", async () => {
    const executor = new LiveTradingExecutor(null);
    const outcome = await executor.closeTrade("t1", 100);
    assert.equal(outcome.ok, false);
  });

  it("throws rather than returning a fabricated balance", async () => {
    const executor = new LiveTradingExecutor(null);
    await assert.rejects(() => executor.getBalance());
  });
});

describe("LiveTradingExecutor with a broker adapter", () => {
  it("delegates to the adapter and surfaces provider errors instead of swallowing them", async () => {
    const executor = new LiveTradingExecutor({
      name: "test-broker",
      placeOrder: async () => {
        throw new Error("broker rejected order");
      },
      settleOrder: async () => {
        throw new Error("unreachable");
      },
      fetchBalance: async () => 1000,
      fetchOpenPositions: async () => [],
    });
    const outcome = await executor.openTrade(makeSignal());
    assert.equal(outcome.ok, false);
    if (outcome.ok) throw new Error("expected failure");
    assert.equal(outcome.error.code, "PROVIDER_ERROR");
    assert.ok(outcome.error.message.includes("broker rejected order"));
  });
});
