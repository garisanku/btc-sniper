/** Simple moving average series. Returns null until `period` samples are available. */
export function sma(values: number[], period: number): Array<number | null> {
  const out: Array<number | null> = new Array(values.length).fill(null);
  if (period <= 0) return out;
  let sum = 0;
  for (let i = 0; i < values.length; i++) {
    sum += values[i]!;
    if (i >= period) sum -= values[i - period]!;
    if (i >= period - 1) out[i] = sum / period;
  }
  return out;
}

/** Exponential moving average series, seeded with an SMA of the first `period` values. */
export function ema(values: number[], period: number): Array<number | null> {
  const out: Array<number | null> = new Array(values.length).fill(null);
  if (period <= 0 || values.length < period) return out;
  const k = 2 / (period + 1);
  let seed = 0;
  for (let i = 0; i < period; i++) seed += values[i]!;
  seed /= period;
  out[period - 1] = seed;
  let prev = seed;
  for (let i = period; i < values.length; i++) {
    const next = values[i]! * k + prev * (1 - k);
    out[i] = next;
    prev = next;
  }
  return out;
}

export function lastDefined(series: Array<number | null>): number | null {
  for (let i = series.length - 1; i >= 0; i--) {
    if (series[i] !== null) return series[i]!;
  }
  return null;
}

/** Volume-weighted average price, computed over the whole provided window (session VWAP). */
export function vwap(highs: number[], lows: number[], closes: number[], volumes: number[]): Array<number | null> {
  const out: Array<number | null> = new Array(closes.length).fill(null);
  let cumPV = 0;
  let cumV = 0;
  for (let i = 0; i < closes.length; i++) {
    const typicalPrice = (highs[i]! + lows[i]! + closes[i]!) / 3;
    cumPV += typicalPrice * volumes[i]!;
    cumV += volumes[i]!;
    out[i] = cumV > 0 ? cumPV / cumV : null;
  }
  return out;
}
