import type { Candle, IndicatorSnapshot } from "@btc-sniper/types";
import { ema, sma, vwap, lastDefined } from "./moving-averages.js";
import { rsi, stochasticRsi, roc } from "./rsi.js";
import { macd } from "./macd.js";
import { atr, bollingerBands } from "./volatility.js";
import { detectMarketStructure } from "./structure.js";

export * from "./moving-averages.js";
export * from "./rsi.js";
export * from "./macd.js";
export * from "./volatility.js";
export * from "./structure.js";

/**
 * Computes the full indicator snapshot (latest values only) from a candle
 * series. Candles must be sorted oldest -> newest. Returns nulls for any
 * indicator that doesn't yet have enough history — callers must treat null
 * as "not enough data" rather than defaulting to zero/neutral silently.
 */
export function computeIndicatorSnapshot(candles: Candle[]): IndicatorSnapshot {
  const closes = candles.map((c) => c.close);
  const highs = candles.map((c) => c.high);
  const lows = candles.map((c) => c.low);
  const volumes = candles.map((c) => c.volume);

  const ema9 = lastDefined(ema(closes, 9));
  const ema21 = lastDefined(ema(closes, 21));
  const ema50 = lastDefined(ema(closes, 50));
  const ema200 = lastDefined(ema(closes, 200));
  const vwapVal = lastDefined(vwap(highs, lows, closes, volumes));
  const rsi14 = lastDefined(rsi(closes, 14));
  const rocVal = lastDefined(roc(closes, 9));
  const atr14 = lastDefined(atr(highs, lows, closes, 14));

  const macdSeries = macd(closes, 12, 26, 9);
  const lastMacd = macdSeries[macdSeries.length - 1];
  const macdOut =
    lastMacd && lastMacd.macd !== null && lastMacd.signal !== null && lastMacd.histogram !== null
      ? { macd: lastMacd.macd, signal: lastMacd.signal, histogram: lastMacd.histogram }
      : null;

  const stochSeries = stochasticRsi(closes);
  const lastStoch = stochSeries[stochSeries.length - 1];
  const stochOut = lastStoch && lastStoch.k !== null && lastStoch.d !== null ? { k: lastStoch.k, d: lastStoch.d } : null;

  const bbSeries = bollingerBands(closes, 20, 2);
  const lastBb = bbSeries[bbSeries.length - 1];
  const bbOut =
    lastBb && lastBb.upper !== null && lastBb.middle !== null && lastBb.lower !== null && lastBb.bandwidth !== null
      ? { upper: lastBb.upper, middle: lastBb.middle, lower: lastBb.lower, bandwidth: lastBb.bandwidth }
      : null;

  return {
    ema9,
    ema21,
    ema50,
    ema200,
    vwap: vwapVal,
    rsi14,
    macd: macdOut,
    stochRsi: stochOut,
    roc: rocVal,
    atr14,
    bollinger: bbOut,
  };
}
