import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { sma, ema, vwap, lastDefined } from "./moving-averages.js";

function close(actual: number, expected: number, tolerance = 1e-6) {
  assert.ok(Math.abs(actual - expected) <= tolerance, `expected ${actual} to be close to ${expected}`);
}

describe("sma", () => {
  it("returns null until period samples exist", () => {
    const out = sma([1, 2, 3, 4, 5], 3);
    assert.deepEqual(out, [null, null, 2, 3, 4]);
  });
});

describe("ema", () => {
  it("seeds with SMA then applies exponential smoothing", () => {
    const out = ema([1, 2, 3, 4, 5], 3);
    assert.equal(out[0], null);
    assert.equal(out[1], null);
    close(out[2]!, 2);
    close(out[3]!, 3);
    close(out[4]!, 4);
  });

  it("returns all nulls when there is insufficient data", () => {
    const out = ema([1, 2], 5);
    assert.deepEqual(out, [null, null]);
  });
});

describe("vwap", () => {
  it("weights typical price by volume cumulatively", () => {
    const highs = [10, 10];
    const lows = [8, 8];
    const closes = [9, 9];
    const volumes = [1, 3];
    const out = vwap(highs, lows, closes, volumes);
    close(out[0]!, 9);
    close(out[1]!, 9);
  });
});

describe("lastDefined", () => {
  it("finds the last non-null value", () => {
    assert.equal(lastDefined([null, 1, 2, null]), 2);
    assert.equal(lastDefined([null, null]), null);
  });
});
