import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { rsi, roc } from "./rsi.js";

function close(actual: number, expected: number, tolerance = 1e-6) {
  assert.ok(Math.abs(actual - expected) <= tolerance, `expected ${actual} to be close to ${expected}`);
}

describe("rsi", () => {
  it("approaches 100 for a strictly increasing series", () => {
    const values = Array.from({ length: 30 }, (_, i) => 100 + i);
    const out = rsi(values, 14);
    const last = out[out.length - 1]!;
    assert.ok(last > 95, `expected ${last} > 95`);
  });

  it("approaches 0 for a strictly decreasing series", () => {
    const values = Array.from({ length: 30 }, (_, i) => 200 - i);
    const out = rsi(values, 14);
    const last = out[out.length - 1]!;
    assert.ok(last < 5, `expected ${last} < 5`);
  });

  it("sits near 50 for an alternating flat-ish series", () => {
    const values = Array.from({ length: 40 }, (_, i) => 100 + (i % 2 === 0 ? 1 : -1));
    const out = rsi(values, 14);
    const last = out[out.length - 1]!;
    assert.ok(last > 30 && last < 70, `expected ${last} in (30,70)`);
  });

  it("returns null before enough samples", () => {
    const out = rsi([1, 2, 3], 14);
    assert.ok(out.every((v) => v === null));
  });
});

describe("roc", () => {
  it("computes percent change over the period", () => {
    const values = [100, 100, 100, 100, 110];
    const out = roc(values, 4);
    close(out[4]!, 10);
  });
});
