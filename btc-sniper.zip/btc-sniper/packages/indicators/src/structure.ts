import type { Candle, MarketStructure } from "@btc-sniper/types";

interface SwingPoint {
  index: number;
  price: number;
}

/**
 * Detects simple market structure (swing highs/lows, higher-high/higher-low
 * patterns, breakout/breakdown against recent range, and naive support/resistance)
 * from a series of candles. Uses a fixed lookback window and a 3-candle
 * fractal definition for swing points — intentionally simple and explainable
 * rather than a full pivot-detection library.
 */
export function detectMarketStructure(candles: Candle[], lookback = 20): MarketStructure {
  const empty: MarketStructure = {
    higherHigh: false,
    higherLow: false,
    lowerHigh: false,
    lowerLow: false,
    breakout: false,
    breakdown: false,
    support: null,
    resistance: null,
  };
  if (candles.length < 7) return empty;

  const recent = candles.slice(-lookback);
  const swingHighs: SwingPoint[] = [];
  const swingLows: SwingPoint[] = [];

  for (let i = 2; i < recent.length - 2; i++) {
    const c = recent[i]!;
    const isHigh =
      c.high > recent[i - 1]!.high &&
      c.high > recent[i - 2]!.high &&
      c.high > recent[i + 1]!.high &&
      c.high > recent[i + 2]!.high;
    const isLow =
      c.low < recent[i - 1]!.low &&
      c.low < recent[i - 2]!.low &&
      c.low < recent[i + 1]!.low &&
      c.low < recent[i + 2]!.low;
    if (isHigh) swingHighs.push({ index: i, price: c.high });
    if (isLow) swingLows.push({ index: i, price: c.low });
  }

  const lastTwoHighs = swingHighs.slice(-2);
  const lastTwoLows = swingLows.slice(-2);

  const higherHigh = lastTwoHighs.length === 2 && lastTwoHighs[1]!.price > lastTwoHighs[0]!.price;
  const lowerHigh = lastTwoHighs.length === 2 && lastTwoHighs[1]!.price < lastTwoHighs[0]!.price;
  const higherLow = lastTwoLows.length === 2 && lastTwoLows[1]!.price > lastTwoLows[0]!.price;
  const lowerLow = lastTwoLows.length === 2 && lastTwoLows[1]!.price < lastTwoLows[0]!.price;

  const resistance = swingHighs.length > 0 ? Math.max(...swingHighs.map((s) => s.price)) : null;
  const support = swingLows.length > 0 ? Math.min(...swingLows.map((s) => s.price)) : null;

  const lastClose = recent[recent.length - 1]!.close;
  const breakout = resistance !== null && lastClose > resistance;
  const breakdown = support !== null && lastClose < support;

  return { higherHigh, higherLow, lowerHigh, lowerLow, breakout, breakdown, support, resistance };
}
