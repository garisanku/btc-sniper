/** Wilder's RSI. Returns a series aligned to `values`, null until enough samples exist. */
export function rsi(values: number[], period = 14): Array<number | null> {
  const out: Array<number | null> = new Array(values.length).fill(null);
  if (values.length <= period) return out;

  let gainSum = 0;
  let lossSum = 0;
  for (let i = 1; i <= period; i++) {
    const change = values[i]! - values[i - 1]!;
    if (change > 0) gainSum += change;
    else lossSum += -change;
  }
  let avgGain = gainSum / period;
  let avgLoss = lossSum / period;
  out[period] = computeRsi(avgGain, avgLoss);

  for (let i = period + 1; i < values.length; i++) {
    const change = values[i]! - values[i - 1]!;
    const gain = change > 0 ? change : 0;
    const loss = change < 0 ? -change : 0;
    avgGain = (avgGain * (period - 1) + gain) / period;
    avgLoss = (avgLoss * (period - 1) + loss) / period;
    out[i] = computeRsi(avgGain, avgLoss);
  }
  return out;
}

function computeRsi(avgGain: number, avgLoss: number): number {
  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return 100 - 100 / (1 + rs);
}

/** Stochastic RSI: %K and %D derived from the RSI series itself. */
export function stochasticRsi(
  values: number[],
  rsiPeriod = 14,
  stochPeriod = 14,
  kSmooth = 3,
  dSmooth = 3
): Array<{ k: number | null; d: number | null }> {
  const rsiSeries = rsi(values, rsiPeriod);
  const rawK: Array<number | null> = new Array(values.length).fill(null);

  for (let i = 0; i < rsiSeries.length; i++) {
    if (i < stochPeriod - 1) continue;
    const window = rsiSeries.slice(i - stochPeriod + 1, i + 1);
    if (window.some((v) => v === null)) continue;
    const nums = window as number[];
    const min = Math.min(...nums);
    const max = Math.max(...nums);
    const cur = rsiSeries[i]!;
    rawK[i] = max === min ? 50 : ((cur - min) / (max - min)) * 100;
  }

  const kSeries = smoothSeries(rawK, kSmooth);
  const dSeries = smoothSeries(kSeries, dSmooth);

  return values.map((_, i) => ({ k: kSeries[i] ?? null, d: dSeries[i] ?? null }));
}

function smoothSeries(series: Array<number | null>, period: number): Array<number | null> {
  const out: Array<number | null> = new Array(series.length).fill(null);
  for (let i = 0; i < series.length; i++) {
    if (i < period - 1) continue;
    const window = series.slice(i - period + 1, i + 1);
    if (window.some((v) => v === null)) continue;
    const nums = window as number[];
    out[i] = nums.reduce((a, b) => a + b, 0) / nums.length;
  }
  return out;
}

/** Rate of change, percent, over `period` samples. */
export function roc(values: number[], period = 9): Array<number | null> {
  const out: Array<number | null> = new Array(values.length).fill(null);
  for (let i = period; i < values.length; i++) {
    const prev = values[i - period]!;
    if (prev === 0) continue;
    out[i] = ((values[i]! - prev) / prev) * 100;
  }
  return out;
}
