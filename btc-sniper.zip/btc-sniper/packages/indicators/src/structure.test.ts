import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { detectMarketStructure } from "./structure.js";
import type { Candle } from "@btc-sniper/types";

function makeCandle(i: number, high: number, low: number, close: number): Candle {
  return {
    symbol: "BTCUSDT",
    interval: "1m",
    openTime: i * 60_000,
    closeTime: i * 60_000 + 59_999,
    open: (high + low) / 2,
    high,
    low,
    close,
    volume: 10,
    quoteVolume: 10 * close,
    trades: 5,
    takerBuyBaseVolume: 5,
    takerBuySellVolume: 5,
    isClosed: true,
  };
}

describe("detectMarketStructure", () => {
  it("detects an uptrend with higher highs and higher lows", () => {
    // A 13-candle zigzag with clear 3-bar-either-side fractal swing points:
    // swing highs at idx 2/6/9 (108 -> 118 -> 125, rising) and swing lows
    // at idx 4/8 (90 -> 95, rising).
    const highsLows: Array<[number, number]> = [
      [100, 90],
      [102, 92],
      [108, 96],
      [104, 98],
      [103, 90],
      [110, 99],
      [118, 101],
      [112, 103],
      [111, 95],
      [125, 108],
      [115, 109],
      [113, 110],
      [111, 107],
    ];
    const candles = highsLows.map(([h, l], i) => makeCandle(i, h, l, (h + l) / 2));
    const structure = detectMarketStructure(candles);
    assert.equal(structure.higherHigh, true);
    assert.equal(structure.higherLow, true);
    assert.equal(structure.lowerHigh, false);
    assert.equal(structure.lowerLow, false);
    assert.equal(structure.resistance, 125);
    assert.equal(structure.support, 90);
  });

  it("returns an empty/neutral structure with too little data", () => {
    const candles = [makeCandle(0, 10, 9, 9.5), makeCandle(1, 11, 9, 10)];
    const structure = detectMarketStructure(candles);
    assert.equal(structure.support, null);
    assert.equal(structure.resistance, null);
    assert.equal(structure.breakout, false);
  });
});
