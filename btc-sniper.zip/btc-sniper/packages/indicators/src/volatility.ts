import { sma } from "./moving-averages.js";

/** Average True Range (Wilder smoothing). */
export function atr(highs: number[], lows: number[], closes: number[], period = 14): Array<number | null> {
  const trueRanges: number[] = [];
  for (let i = 0; i < highs.length; i++) {
    if (i === 0) {
      trueRanges.push(highs[i]! - lows[i]!);
      continue;
    }
    const highLow = highs[i]! - lows[i]!;
    const highPrevClose = Math.abs(highs[i]! - closes[i - 1]!);
    const lowPrevClose = Math.abs(lows[i]! - closes[i - 1]!);
    trueRanges.push(Math.max(highLow, highPrevClose, lowPrevClose));
  }

  const out: Array<number | null> = new Array(highs.length).fill(null);
  if (trueRanges.length < period) return out;

  let avg = trueRanges.slice(0, period).reduce((a, b) => a + b, 0) / period;
  out[period - 1] = avg;
  for (let i = period; i < trueRanges.length; i++) {
    avg = (avg * (period - 1) + trueRanges[i]!) / period;
    out[i] = avg;
  }
  return out;
}

export interface BollingerPoint {
  upper: number | null;
  middle: number | null;
  lower: number | null;
  bandwidth: number | null; // (upper-lower)/middle, a normalized volatility measure
}

/** Bollinger Bands: SMA middle band +/- stdDevMultiplier standard deviations. */
export function bollingerBands(values: number[], period = 20, stdDevMultiplier = 2): BollingerPoint[] {
  const middle = sma(values, period);
  const out: BollingerPoint[] = new Array(values.length).fill(null).map(() => ({
    upper: null,
    middle: null,
    lower: null,
    bandwidth: null,
  }));

  for (let i = period - 1; i < values.length; i++) {
    const window = values.slice(i - period + 1, i + 1);
    const mean = middle[i]!;
    const variance = window.reduce((sum, v) => sum + (v - mean) ** 2, 0) / period;
    const stdDev = Math.sqrt(variance);
    const upper = mean + stdDevMultiplier * stdDev;
    const lower = mean - stdDevMultiplier * stdDev;
    out[i] = {
      upper,
      middle: mean,
      lower,
      bandwidth: mean !== 0 ? (upper - lower) / mean : null,
    };
  }
  return out;
}
