import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { atr, bollingerBands } from "./volatility.js";

function close(actual: number, expected: number, tolerance = 1e-6) {
  assert.ok(Math.abs(actual - expected) <= tolerance, `expected ${actual} to be close to ${expected}`);
}

describe("atr", () => {
  it("equals the constant true range for a series with fixed high-low range and no gaps", () => {
    const n = 20;
    const highs = Array.from({ length: n }, () => 110);
    const lows = Array.from({ length: n }, () => 100);
    const closes = Array.from({ length: n }, () => 105);
    const out = atr(highs, lows, closes, 14);
    close(out[13]!, 10);
    close(out[19]!, 10);
  });

  it("returns null before enough samples", () => {
    const out = atr([1, 2], [0, 1], [0.5, 1.5], 14);
    assert.ok(out.every((v) => v === null));
  });
});

describe("bollingerBands", () => {
  it("collapses to the mean with zero bandwidth for a constant series", () => {
    const values = Array.from({ length: 25 }, () => 100);
    const out = bollingerBands(values, 20, 2);
    const last = out[out.length - 1]!;
    close(last.middle!, 100);
    close(last.upper!, 100);
    close(last.lower!, 100);
    close(last.bandwidth!, 0);
  });

  it("widens bands with higher volatility", () => {
    const values = Array.from({ length: 25 }, (_, i) => 100 + (i % 2 === 0 ? 10 : -10));
    const out = bollingerBands(values, 20, 2);
    const last = out[out.length - 1]!;
    assert.ok(last.bandwidth! > 0.1);
  });
});
