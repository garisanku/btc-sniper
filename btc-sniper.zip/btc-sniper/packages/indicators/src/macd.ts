import { ema } from "./moving-averages.js";

export interface MacdPoint {
  macd: number | null;
  signal: number | null;
  histogram: number | null;
}

/** MACD line, signal line (EMA of MACD), and histogram. */
export function macd(values: number[], fast = 12, slow = 26, signalPeriod = 9): MacdPoint[] {
  const fastEma = ema(values, fast);
  const slowEma = ema(values, slow);
  const macdLine: Array<number | null> = values.map((_, i) =>
    fastEma[i] !== null && slowEma[i] !== null ? fastEma[i]! - slowEma[i]! : null
  );

  const firstValid = macdLine.findIndex((v) => v !== null);
  const signalLine: Array<number | null> = new Array(values.length).fill(null);

  if (firstValid !== -1 && values.length - firstValid >= signalPeriod) {
    const compact = macdLine.slice(firstValid).map((v) => v!);
    const signalCompact = ema(compact, signalPeriod);
    for (let i = 0; i < signalCompact.length; i++) {
      signalLine[firstValid + i] = signalCompact[i] ?? null;
    }
  }

  return values.map((_, i) => {
    const m = macdLine[i] ?? null;
    const s = signalLine[i] ?? null;
    return {
      macd: m,
      signal: s,
      histogram: m !== null && s !== null ? m - s : null,
    };
  });
}
