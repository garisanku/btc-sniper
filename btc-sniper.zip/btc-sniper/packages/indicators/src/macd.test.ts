import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { macd } from "./macd.js";
import { ema } from "./moving-averages.js";

function close(actual: number, expected: number, tolerance = 1e-6) {
  assert.ok(Math.abs(actual - expected) <= tolerance, `expected ${actual} to be close to ${expected}`);
}

describe("macd", () => {
  it("equals fastEma - slowEma at every point where both exist", () => {
    const values = Array.from({ length: 60 }, (_, i) => 100 + Math.sin(i / 3) * 5 + i * 0.2);
    const out = macd(values, 12, 26, 9);
    const fast = ema(values, 12);
    const slow = ema(values, 26);
    for (let i = 0; i < values.length; i++) {
      if (fast[i] !== null && slow[i] !== null) {
        close(out[i]!.macd!, fast[i]! - slow[i]!);
      } else {
        assert.equal(out[i]!.macd, null);
      }
    }
  });

  it("produces a positive histogram in a strong uptrend", () => {
    const values = Array.from({ length: 60 }, (_, i) => 100 + i * 1.5);
    const out = macd(values, 12, 26, 9);
    const last = out[out.length - 1]!;
    assert.notEqual(last.macd, null);
    assert.ok(last.macd! > 0);
  });
});
