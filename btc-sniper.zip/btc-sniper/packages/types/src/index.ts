// ============================================================================
// @btc-sniper/types — shared type definitions used across the whole system.
// ============================================================================

export type Direction = "UP" | "DOWN";
export type SignalStrength = "STRONG" | "MODERATE" | "WEAK" | "NONE";
export type EntryStatus = "EARLY" | "OPTIMAL" | "LATE" | "AVOID";
export type TradeResult = "WIN" | "LOSS" | "PUSH" | "OPEN" | "CANCELLED";
export type BotMode = "MANUAL" | "SEMI_AUTO" | "AUTOMATIC" | "SNIPER";
export type BotStatus = "STOPPED" | "RUNNING" | "PAUSED" | "HALTED";
export type ExecutionMode = "PAPER" | "LIVE";

/** OHLCV candle for a given timeframe. */
export interface Candle {
  symbol: string;
  interval: "1m" | "5m";
  openTime: number; // ms epoch, candle open
  closeTime: number; // ms epoch, candle close
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  quoteVolume: number;
  trades: number;
  takerBuyBaseVolume: number;
  takerBuySellVolume: number; // taker sell volume = volume - takerBuyBaseVolume, precomputed for convenience
  isClosed: boolean;
}

/** Best bid/ask + derived order-flow snapshot. */
export interface BookTicker {
  symbol: string;
  bidPrice: number;
  bidQty: number;
  askPrice: number;
  askQty: number;
  spread: number;
  spreadBps: number;
  timestamp: number;
}

/** Aggregated trade-flow snapshot over a rolling window. */
export interface TradeFlowSnapshot {
  symbol: string;
  windowMs: number;
  buyVolume: number;
  sellVolume: number;
  totalVolume: number;
  volumeDelta: number;
  buyRatio: number; // buyVolume / totalVolume
  tradeCount: number;
  timestamp: number;
}

export interface MarketSnapshot {
  symbol: string;
  price: number;
  bookTicker: BookTicker | null;
  tradeFlow: TradeFlowSnapshot;
  candles1m: Candle[];
  candles5m: Candle[];
  timestamp: number;
  stale: boolean;
}

// ----------------------------------------------------------------------------
// Indicators
// ----------------------------------------------------------------------------

export interface IndicatorSnapshot {
  ema9: number | null;
  ema21: number | null;
  ema50: number | null;
  ema200: number | null;
  vwap: number | null;
  rsi14: number | null;
  macd: { macd: number; signal: number; histogram: number } | null;
  stochRsi: { k: number; d: number } | null;
  roc: number | null;
  atr14: number | null;
  bollinger: { upper: number; middle: number; lower: number; bandwidth: number } | null;
}

export interface MarketStructure {
  higherHigh: boolean;
  higherLow: boolean;
  lowerHigh: boolean;
  lowerLow: boolean;
  breakout: boolean;
  breakdown: boolean;
  support: number | null;
  resistance: number | null;
}

// ----------------------------------------------------------------------------
// Strategy configuration (fully driven from config, never hard-coded)
// ----------------------------------------------------------------------------

export interface ScoreWeights {
  trend: number;
  momentum: number;
  volume: number;
  orderFlow: number;
  priceAction: number;
  volatility: number;
}

export interface SniperRequirements {
  minConfidence: number; // 0-100
  minVolumeRatio: number; // e.g. 1.2
  maxSpreadBps: number;
  minSignalAlignment: number; // out of 6 factors
  maxTradesPerCycle: number;
}

export interface RiskConfig {
  maxRiskPerTradePct: number; // % of balance
  maxDailyLossPct: number; // % of balance
  maxConsecutiveLosses: number;
  maxTradesPerHour: number;
  cooldownAfterLossMs: number;
  minConfidence: number;
  maxPositionSizeUsd: number;
}

export interface StrategyConfig {
  symbol: string;
  cycleMs: number; // 300_000 for 5 minutes
  weights: ScoreWeights;
  sniper: SniperRequirements;
  risk: RiskConfig;
  mode: BotMode;
  executionMode: ExecutionMode;
  minConfidenceToTrade: number;
  maxSpreadBpsToTrade: number;
  lateEntryThresholdMs: number; // avoid entries after this much of the cycle elapsed
  earlyEntryThresholdMs: number; // before this, considered "early"
  staleDataMs: number;
}

// ----------------------------------------------------------------------------
// Prediction / signal
// ----------------------------------------------------------------------------

export interface FactorScore {
  name: keyof ScoreWeights;
  score: number; // -100..100, negative = bearish, positive = bullish
  weight: number;
  weighted: number;
  detail: string;
}

export interface SniperAlignmentCheck {
  name: string;
  passed: boolean;
  detail: string;
}

export type TimingLabel = "PEAK" | "GOOD" | "FAIR" | "WAIT";

/**
 * Precision execution timing: entryStatus (EARLY/OPTIMAL/LATE/AVOID) only
 * says which coarse bucket of the 5-minute cycle we're in. This scores how
 * good *this exact instant* is to actually fire the order, continuously
 * from 0-100, by blending where we are within the tradeable window, how
 * tight the spread is right now, how far above threshold confidence is,
 * and how "calm" (neither dead-flat nor erratic) recent volatility looks.
 */
export interface ExecutionTiming {
  score: number; // 0-100 — higher = better instant to execute right now
  label: TimingLabel;
  reason: string;
  windowScore: number; // 0-100 — position within the tradeable window (peaks mid-window)
  spreadScore: number; // 0-100 — tighter spread relative to the max allowed = higher
  confidenceScore: number; // 0-100 — confidence scaled above the trade threshold
  volatilityScore: number; // 0-100 — how close bandwidth is to a "calm" sweet spot
}

export interface Prediction {
  symbol: string;
  timestamp: number;
  cycleId: string;
  upProbability: number; // 0-100
  downProbability: number; // 0-100
  confidence: number; // 0-100
  signal: "BUY_UP" | "BUY_DOWN" | "NO_TRADE";
  signalStrength: SignalStrength;
  reason: string;
  entryStatus: EntryStatus;
  executionTiming: ExecutionTiming;
  price: number;
  volume: number;
  factors: FactorScore[];
  sniperChecks: SniperAlignmentCheck[];
  sniperAligned: number; // count of passed checks
  sniperReady: boolean;
  cycleRemainingMs: number;
}

export interface TradeSignal {
  cycleId: string;
  symbol: string;
  direction: Direction;
  confidence: number;
  entryPrice: number;
  entryTime: number;
  expiryTime: number;
  prediction: Prediction;
  sizeUsd: number;
}

// ----------------------------------------------------------------------------
// Trades / execution
// ----------------------------------------------------------------------------

export interface Trade {
  id: string;
  cycleId: string;
  symbol: string;
  direction: Direction;
  entryPrice: number;
  exitPrice: number | null;
  entryTime: number;
  exitTime: number | null;
  confidence: number;
  upProbability: number;
  downProbability: number;
  buyVolume: number;
  sellVolume: number;
  volumeDelta: number;
  signalStrength: SignalStrength;
  result: TradeResult;
  pnl: number | null;
  sizeUsd: number;
  mode: ExecutionMode;
  strategyName: string;
  createdAt: number;
}

export interface TradeExecutionError {
  code:
    | "INSUFFICIENT_BALANCE"
    | "RISK_LIMIT"
    | "PROVIDER_ERROR"
    | "TIMEOUT"
    | "INVALID_SIGNAL"
    | "NOT_FOUND"
    | "UNSUPPORTED";
  message: string;
}

export type TradeExecutionOutcome =
  | { ok: true; trade: Trade }
  | { ok: false; error: TradeExecutionError };

// ----------------------------------------------------------------------------
// Risk / bot state
// ----------------------------------------------------------------------------

export interface RiskState {
  dailyPnl: number;
  dailyPnlPct: number;
  consecutiveLosses: number;
  tradesLastHour: number;
  cooldownUntil: number | null;
  halted: boolean;
  haltReason: string | null;
}

export interface BotState {
  id: string;
  mode: BotMode;
  status: BotStatus;
  executionMode: ExecutionMode;
  haltReason: string | null;
  dailyPnl: number;
  totalTrades: number;
  wins: number;
  losses: number;
  consecutiveLosses: number;
  currentStreak: number;
  bestStreak: number;
  worstStreak: number;
  balance: number;
  updatedAt: number;
}

export interface TradeStats {
  totalTrades: number;
  wins: number;
  losses: number;
  winRate: number;
  totalPnl: number;
  averageConfidence: number;
  averageDurationMs: number;
  currentStreak: number;
  bestStreak: number;
  worstStreak: number;
  profitFactor: number;
}

// ----------------------------------------------------------------------------
// Backtesting
// ----------------------------------------------------------------------------

export interface BacktestResult {
  totalTrades: number;
  wins: number;
  losses: number;
  winRate: number;
  profitFactor: number;
  maxDrawdown: number;
  averageConfidence: number;
  averageReturnPct: number;
  finalBalance: number;
  trades: Trade[];
}

// ----------------------------------------------------------------------------
// WebSocket event contracts (backend -> frontend)
// ----------------------------------------------------------------------------

export interface WsEventMap {
  PRICE_UPDATE: { symbol: string; price: number; timestamp: number };
  CANDLE_UPDATE: { interval: "1m" | "5m"; candle: Candle };
  VOLUME_UPDATE: TradeFlowSnapshot;
  ORDER_FLOW_UPDATE: BookTicker;
  INDICATOR_UPDATE: { symbol: string; timestamp: number; indicators: IndicatorSnapshot; structure: MarketStructure };
  PREDICTION_UPDATE: Prediction;
  SIGNAL_UPDATE: { prediction: Prediction; willTrade: boolean; blockReason: string | null };
  TRADE_OPENED: Trade;
  TRADE_CLOSED: Trade;
  BOT_STATUS_UPDATE: BotState;
  RISK_UPDATE: RiskState;
  LOG: { level: "info" | "warn" | "error"; message: string; timestamp: number; context?: Record<string, unknown> };
  MARKET_STALE: { symbol: string; lastUpdate: number };
}

export type WsEventName = keyof WsEventMap;

// A plain `interface { type: K; payload: WsEventMap[K] }` looks equivalent
// but is NOT a discriminated union when K defaults to the full
// WsEventName — `type` and `payload` each independently resolve to their
// own union, uncorrelated, so `switch (message.type)` cannot narrow
// `message.payload`'s type at all (every case sees the full payload union).
// This mapped-type-over-a-union form distributes per key instead, producing
// the real union `{type:"PRICE_UPDATE";payload:...} | {type:"CANDLE_UPDATE";payload:...} | ...`
// that TypeScript can actually narrow on `.type`.
export type WsMessage<K extends WsEventName = WsEventName> = {
  [P in K]: { type: P; payload: WsEventMap[P] };
}[K];

export function makeWsMessage<K extends WsEventName>(type: K, payload: WsEventMap[K]): WsMessage<K> {
  // TypeScript can't fully verify a mapped type indexed by a still-generic
  // K distributes correctly at this call site — the cast is safe because
  // `type` and `payload` are constructed together from the same K right
  // above; every external caller still gets the fully narrowed union.
  return { type, payload } as WsMessage<K>;
}
