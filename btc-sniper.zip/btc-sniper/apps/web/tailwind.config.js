/** @type {import('tailwindcss').Config} */
export default {
  // Class-based dark mode: a `.dark` class on <html> (toggled by
  // useThemeStore, see src/stores/useThemeStore.ts) flips the CSS custom
  // properties defined in index.css, which the terminal.* colors below
  // resolve through. No `dark:` variants needed anywhere in the app —
  // `bg-terminal-panel` etc. just repaint themselves.
  darkMode: "class",
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        // Neobrutalist palette. These token names (terminal.*) are kept
        // stable across the whole app even though the theme is no longer a
        // dark trading terminal — only the hex values changed — so every
        // existing `bg-terminal-up` / `text-terminal-muted` / etc. class
        // still means "the up color" / "the muted text color", just mapped
        // to bold, flat, high-contrast values instead of soft dark-mode ones.
        // Each token resolves through a CSS variable (defined in
        // index.css:root and overridden under .dark) so the same class
        // names repaint for both themes.
        terminal: {
          bg: "var(--terminal-bg)", // page background
          panel: "var(--terminal-panel)", // panel/card background
          border: "var(--terminal-border)", // the (thick) border + hard-shadow color
          ink: "var(--terminal-ink)", // primary text color
          up: "var(--terminal-up)", // bold flat green
          down: "var(--terminal-down)", // bold flat red
          amber: "var(--terminal-amber)", // bold flat yellow
          accent: "var(--terminal-accent)", // bold flat violet, used for neutral highlights
          muted: "var(--terminal-muted)", // secondary/label text
          pending: "var(--terminal-pending)", // "in progress / live-but-not-settled" text (was inline #8a6d00)
        },
      },
      fontFamily: {
        mono: ["ui-monospace", "SFMono-Regular", "Menlo", "Consolas", "monospace"],
      },
      boxShadow: {
        // Hard, non-blurred, offset shadows — the signature neobrutalism
        // "sticker" look — instead of Tailwind's default soft/blurred ones.
        // Shadow color follows --terminal-border so it flips with the theme
        // (black shadows on the light/cream theme, cream shadows on dark).
        brutal: "4px 4px 0 0 var(--terminal-border)",
        "brutal-sm": "2px 2px 0 0 var(--terminal-border)",
        "brutal-lg": "8px 8px 0 0 var(--terminal-border)",
        "brutal-pressed": "1px 1px 0 0 var(--terminal-border)",
      },
      borderRadius: {
        DEFAULT: "0px",
        none: "0px",
        sm: "0px",
        md: "0px",
        lg: "0px",
      },
    },
  },
  plugins: [],
};
