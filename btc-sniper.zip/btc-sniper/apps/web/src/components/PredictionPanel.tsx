import type { ExecutionTiming } from "@btc-sniper/types";
import { useMarketStore } from "../stores/useMarketStore";
import { formatCountdown, formatPct } from "../utils/format";
import { Panel } from "./Panel";

export function PredictionPanel() {
  const prediction = useMarketStore((s) => s.prediction);
  const blockReason = useMarketStore((s) => s.blockReason);

  if (!prediction) {
    return (
      <Panel title="BTC 5-MIN PREDICTION">
        <p className="text-sm text-terminal-muted">Waiting for enough market history to generate the first prediction…</p>
      </Panel>
    );
  }

  const isUp = prediction.upProbability >= prediction.downProbability;
  const confidenceLabel = prediction.confidence >= 80 ? "HIGH" : prediction.confidence >= 60 ? "MODERATE" : prediction.confidence >= 40 ? "LOW" : "VERY LOW";

  return (
    <Panel title="BTC 5-MIN PREDICTION">
      <div className="flex items-center justify-between">
        <div>
          <div className={`text-3xl font-extrabold ${isUp ? "text-terminal-up" : "text-terminal-down"}`}>{isUp ? "UP" : "DOWN"}</div>
          <div className="text-sm text-terminal-muted">{formatPct(isUp ? prediction.upProbability : prediction.downProbability)}</div>
        </div>
        <div className="text-right">
          <div className="text-xs text-terminal-muted">TIME REMAINING</div>
          <div className="text-2xl font-bold tabular-nums">{formatCountdown(prediction.cycleRemainingMs)}</div>
        </div>
      </div>

      <ProbabilityBar upProbability={prediction.upProbability} />

      <div className="mt-3 grid grid-cols-2 gap-2 text-sm sm:grid-cols-4">
        <Stat label="CONFIDENCE" value={`${formatPct(prediction.confidence)} (${confidenceLabel})`} />
        <Stat
          label="SIGNAL"
          value={prediction.signal.replace("_", " ")}
          valueClass={prediction.signal === "BUY_UP" ? "text-terminal-up" : prediction.signal === "BUY_DOWN" ? "text-terminal-down" : "text-terminal-muted"}
        />
        <Stat
          label="ENTRY"
          value={prediction.entryStatus}
          valueClass={prediction.entryStatus === "OPTIMAL" ? "text-terminal-up" : prediction.entryStatus === "AVOID" ? "text-terminal-down" : "text-terminal-pending"}
        />
        <Stat label="STRENGTH" value={prediction.signalStrength} />
      </div>

      <TimingMeter timing={prediction.executionTiming} />

      <p className="mt-2 text-xs text-terminal-muted">
        {prediction.reason}
        {blockReason ? ` — ${blockReason}` : ""}
      </p>
    </Panel>
  );
}

const TIMING_COLOR: Record<string, string> = {
  PEAK: "text-terminal-up",
  GOOD: "text-terminal-pending",
  FAIR: "text-terminal-muted",
  WAIT: "text-terminal-down",
};

const TIMING_FILL: Record<string, string> = {
  PEAK: "bg-terminal-up",
  GOOD: "bg-terminal-amber",
  FAIR: "bg-terminal-muted",
  WAIT: "bg-terminal-down",
};

/**
 * Precision execution timing: ENTRY (above) says which coarse bucket of the
 * cycle we're in; this is the continuous "how good is *this exact instant*"
 * score from the engine's Smart Entry Timing (see
 * packages/prediction-engine/src/entry-timing.ts), recomputed every tick —
 * a live "fire now" pulse rather than a static bucket.
 */
function TimingMeter({ timing }: { timing: ExecutionTiming }) {
  return (
    <div className="mt-3">
      <div className="mb-1 flex items-center justify-between text-xs">
        <span className="text-terminal-muted">EXECUTION TIMING</span>
        <span className={`font-extrabold ${TIMING_COLOR[timing.label]}`}>
          {timing.label} · {timing.score.toFixed(0)}
        </span>
      </div>
      <div className="h-2.5 overflow-hidden border-2 border-terminal-border bg-terminal-bg">
        <div className={`h-full transition-[width] ${TIMING_FILL[timing.label]}`} style={{ width: `${timing.score}%` }} />
      </div>
      <p className="mt-1 text-[10px] text-terminal-muted">{timing.reason}</p>
    </div>
  );
}

function ProbabilityBar({ upProbability }: { upProbability: number }) {
  return (
    <div className="mt-3">
      <div className="mb-1 flex justify-between text-xs text-terminal-muted">
        <span>UP {upProbability.toFixed(1)}%</span>
        <span>DOWN {(100 - upProbability).toFixed(1)}%</span>
      </div>
      <div className="flex h-4 overflow-hidden border-2 border-terminal-border bg-terminal-bg">
        <div className="bg-terminal-up transition-[width]" style={{ width: `${upProbability}%` }} />
        <div className="bg-terminal-down transition-[width]" style={{ width: `${100 - upProbability}%` }} />
      </div>
    </div>
  );
}

function Stat({ label, value, valueClass = "" }: { label: string; value: string; valueClass?: string }) {
  return (
    <div>
      <div className="text-[10px] text-terminal-muted">{label}</div>
      <div className={`font-semibold ${valueClass}`}>{value}</div>
    </div>
  );
}
