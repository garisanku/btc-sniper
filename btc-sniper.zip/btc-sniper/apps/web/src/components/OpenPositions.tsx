import { useMemo } from "react";
import { useMarketStore } from "../stores/useMarketStore";
import { formatCountdown, formatPrice, formatUsd } from "../utils/format";

/**
 * Live view of currently-open trades (manual test trades included) — this is
 * the closest thing to a "real-time P&L" for a position that hasn't settled
 * yet. A binary up/down trade doesn't have a continuous dollar P&L the way a
 * leveraged position does (it's win-the-full-payout or lose-the-full-stake
 * at settlement), so rather than inventing a number, this shows the
 * direction the trade is currently leaning — WOULD WIN / WOULD LOSE — based
 * on live price vs entry, updating every tick until it actually closes.
 */
export function OpenPositions() {
  const trades = useMarketStore((s) => s.trades);
  const price = useMarketStore((s) => s.price);
  const prediction = useMarketStore((s) => s.prediction);

  const openTrades = useMemo(() => trades.filter((t) => t.result === "OPEN"), [trades]);

  if (openTrades.length === 0) {
    return <p className="text-xs text-terminal-muted">No open positions.</p>;
  }

  return (
    <div className="space-y-1">
      {openTrades.map((t) => {
        const haveLivePrice = price > 0;
        const moved = price - t.entryPrice;
        const flat = !haveLivePrice || moved === 0;
        const winning = haveLivePrice && ((t.direction === "UP" && moved > 0) || (t.direction === "DOWN" && moved < 0));
        // The countdown only means anything if this trade belongs to the
        // cycle the engine is currently ticking through; near a cycle
        // boundary a settled-but-not-yet-closed trade can briefly mismatch.
        const remainingMs = prediction && prediction.cycleId === t.cycleId ? prediction.cycleRemainingMs : null;

        return (
          <div key={t.id} className="flex flex-wrap items-center justify-between gap-x-3 gap-y-1 border-2 border-terminal-border bg-terminal-bg px-2 py-1.5 text-xs">
            <div className="flex items-center gap-2">
              <span className={`font-extrabold ${t.direction === "UP" ? "text-terminal-up" : "text-terminal-down"}`}>{t.direction}</span>
              <span className="tabular-nums font-medium text-terminal-muted">
                {formatPrice(t.entryPrice)} → {haveLivePrice ? formatPrice(price) : "—"}
              </span>
              <span className={`brutal-badge px-1 py-0.5 text-[10px] ${t.mode === "LIVE" ? "bg-terminal-amber text-black" : "bg-terminal-panel text-terminal-muted"}`}>
                {t.mode}
              </span>
              <span className="tabular-nums font-medium text-terminal-muted">{formatUsd(t.sizeUsd)}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className={`font-extrabold ${flat ? "text-terminal-muted" : winning ? "text-terminal-up" : "text-terminal-down"}`}>
                {flat ? "FLAT" : winning ? "WOULD WIN" : "WOULD LOSE"}
              </span>
              <span className="tabular-nums font-medium text-terminal-muted">{remainingMs !== null ? formatCountdown(remainingMs) : "settling…"}</span>
            </div>
          </div>
        );
      })}
    </div>
  );
}
