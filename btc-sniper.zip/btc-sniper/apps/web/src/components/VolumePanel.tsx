import { useMarketStore } from "../stores/useMarketStore";
import { formatPrice, formatQty } from "../utils/format";
import { Panel } from "./Panel";

export function VolumePanel() {
  const tradeFlow = useMarketStore((s) => s.tradeFlow);
  const bookTicker = useMarketStore((s) => s.bookTicker);

  const buyPct = tradeFlow ? tradeFlow.buyRatio * 100 : 50;
  const sellPct = 100 - buyPct;

  const pressureLabel = buyPct >= 65 ? "STRONG BUY PRESSURE" : buyPct <= 35 ? "STRONG SELL PRESSURE" : "NEUTRAL";
  const pressureColor = buyPct >= 65 ? "text-terminal-up" : buyPct <= 35 ? "text-terminal-down" : "text-terminal-muted";

  return (
    <Panel title="BUY / SELL VOLUME">
      <BarRow label="BUY" pct={buyPct} colorClass="bg-terminal-up" />
      <BarRow label="SELL" pct={sellPct} colorClass="bg-terminal-down" />

      <div className="mt-2 grid grid-cols-2 gap-2 text-xs">
        <div>
          <div className="text-terminal-muted">VOLUME DELTA</div>
          <div className={`font-semibold ${tradeFlow && tradeFlow.volumeDelta >= 0 ? "text-terminal-up" : "text-terminal-down"}`}>
            {tradeFlow ? tradeFlow.volumeDelta.toFixed(3) : "—"}
          </div>
        </div>
        <div>
          <div className="text-terminal-muted">BUY/SELL RATIO</div>
          <div className="font-semibold">{tradeFlow && tradeFlow.sellVolume > 0 ? (tradeFlow.buyVolume / tradeFlow.sellVolume).toFixed(2) : "—"}</div>
        </div>
        <div>
          <div className="text-terminal-muted">SPREAD</div>
          <div className="font-semibold">{bookTicker ? `$${bookTicker.spread.toFixed(2)} · ${bookTicker.spreadBps.toFixed(2)} bps` : "—"}</div>
        </div>
        <div>
          <div className="text-terminal-muted">PRESSURE</div>
          <div className={`font-semibold ${pressureColor}`}>{pressureLabel}</div>
        </div>
      </div>

      <div className="mt-2 grid grid-cols-2 gap-2 border-t-2 border-terminal-border pt-2 text-xs">
        <div>
          <div className="text-terminal-muted">BEST BID</div>
          <div className="font-semibold text-terminal-up tabular-nums">
            {bookTicker ? `$${formatPrice(bookTicker.bidPrice)}` : "—"}
          </div>
          <div className="text-[10px] text-terminal-muted tabular-nums">{bookTicker ? `${formatQty(bookTicker.bidQty)} BTC` : ""}</div>
        </div>
        <div>
          <div className="text-terminal-muted">BEST ASK</div>
          <div className="font-semibold text-terminal-down tabular-nums">
            {bookTicker ? `$${formatPrice(bookTicker.askPrice)}` : "—"}
          </div>
          <div className="text-[10px] text-terminal-muted tabular-nums">{bookTicker ? `${formatQty(bookTicker.askQty)} BTC` : ""}</div>
        </div>
      </div>
    </Panel>
  );
}

function BarRow({ label, pct, colorClass }: { label: string; pct: number; colorClass: string }) {
  return (
    <div className="mb-1.5 flex items-center gap-2 text-xs">
      <span className="w-10 text-terminal-muted">{label}</span>
      <div className="h-4 flex-1 overflow-hidden border-2 border-terminal-border bg-terminal-bg">
        <div className={`h-full ${colorClass} transition-[width]`} style={{ width: `${pct}%` }} />
      </div>
      <span className="w-10 text-right tabular-nums">{pct.toFixed(0)}%</span>
    </div>
  );
}
