import { useMarketStore } from "../stores/useMarketStore";
import { formatTime } from "../utils/format";
import { Panel } from "./Panel";

export function LogPanel() {
  const logs = useMarketStore((s) => s.logs);

  return (
    <Panel title="LIVE LOG" className="col-span-full">
      <div className="max-h-56 space-y-0.5 overflow-auto border-2 border-terminal-border bg-terminal-bg p-2 text-xs">
        {logs.length === 0 && <p className="text-terminal-muted">Waiting for activity…</p>}
        {logs.map((log, i) => (
          <div key={i} className={`font-medium ${levelClass(log.level)}`}>
            <span className="font-bold text-terminal-muted">[{formatTime(log.timestamp)}]</span> {log.message}
            {log.context && <span className="text-terminal-muted"> {JSON.stringify(log.context)}</span>}
          </div>
        ))}
      </div>
    </Panel>
  );
}

function levelClass(level: string): string {
  if (level === "error") return "text-terminal-down";
  if (level === "warn") return "text-terminal-pending";
  return "text-terminal-ink";
}
