import { useEffect, useRef } from "react";
import {
  createChart,
  ColorType,
  CrosshairMode,
  LineStyle,
  type IChartApi,
  type ISeriesApi,
  type SeriesMarker,
  type UTCTimestamp,
} from "lightweight-charts";
import { ema, bollingerBands } from "@btc-sniper/indicators";
import { useMarketStore } from "../stores/useMarketStore";
import { useThemeStore } from "../stores/useThemeStore";
import { getChartTheme } from "../utils/chartTheme";
import { feedSeries } from "../utils/chartFeed";
import { Panel } from "./Panel";

interface ChartSeries {
  candle: ISeriesApi<"Candlestick">;
  ema9: ISeriesApi<"Line">;
  ema21: ISeriesApi<"Line">;
  ema50: ISeriesApi<"Line">;
  bbUpper: ISeriesApi<"Line">;
  bbLower: ISeriesApi<"Line">;
  volume: ISeriesApi<"Histogram">;
}

/**
 * The main candlestick chart: candles, EMA 9/21/50, Bollinger Bands, a
 * volume histogram sharing the same pane, and trade markers. EMA/Bollinger
 * values are computed client-side with the exact same @btc-sniper/indicators
 * functions the backend uses for the live snapshot — one shared
 * implementation, no drift between what the chart draws and what the
 * engine actually scored.
 */
export function PriceChart({ onReady }: { onReady?: (chart: IChartApi) => void }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const seriesRef = useRef<ChartSeries | null>(null);
  // Tracks each series' previously-fed point count so the data effect below
  // can tell "just the newest bar changed" (the overwhelmingly common case,
  // handled with a cheap `series.update()`) apart from "something bigger
  // changed" (first load, a reset — falls back to `setData`). See
  // utils/chartFeed.ts.
  const seriesLengthsRef = useRef<Record<string, number>>({});

  const candles5m = useMarketStore((s) => s.candles5m);
  const trades = useMarketStore((s) => s.trades);
  const theme = useThemeStore((s) => s.theme);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // Uses whatever theme is current at mount time; the [theme] effect
    // below repaints everything (including on this same first render) so
    // this initial value doesn't need to stay in sync on its own.
    const c = getChartTheme(theme);

    const chart = createChart(container, {
      width: container.clientWidth,
      height: 420,
      layout: { background: { type: ColorType.Solid, color: c.bg }, textColor: c.ink, fontFamily: "ui-monospace, SFMono-Regular, Menlo, Consolas, monospace" },
      grid: { vertLines: { color: c.grid }, horzLines: { color: c.grid } },
      crosshair: { mode: CrosshairMode.Normal },
      rightPriceScale: { borderColor: c.border },
      timeScale: { borderColor: c.border, timeVisible: true, secondsVisible: false },
    });

    const candle = chart.addCandlestickSeries({
      upColor: c.up,
      downColor: c.down,
      borderVisible: true,
      borderUpColor: c.ink,
      borderDownColor: c.ink,
      wickUpColor: c.ink,
      wickDownColor: c.ink,
    });
    candle.priceScale().applyOptions({ scaleMargins: { top: 0.05, bottom: 0.25 } });

    const ema9 = chart.addLineSeries({ color: "#2563EB", lineWidth: 2, priceLineVisible: false, lastValueVisible: false });
    const ema21 = chart.addLineSeries({ color: "#F59E0B", lineWidth: 2, priceLineVisible: false, lastValueVisible: false });
    const ema50 = chart.addLineSeries({ color: "#7C5CFF", lineWidth: 2, priceLineVisible: false, lastValueVisible: false });
    const bbUpper = chart.addLineSeries({ color: c.ink, lineWidth: 1, lineStyle: LineStyle.Dotted, priceLineVisible: false, lastValueVisible: false });
    const bbLower = chart.addLineSeries({ color: c.ink, lineWidth: 1, lineStyle: LineStyle.Dotted, priceLineVisible: false, lastValueVisible: false });

    const volume = chart.addHistogramSeries({ priceFormat: { type: "volume" }, priceScaleId: "" });
    volume.priceScale().applyOptions({ scaleMargins: { top: 0.82, bottom: 0 } });

    chartRef.current = chart;
    seriesRef.current = { candle, ema9, ema21, ema50, bbUpper, bbLower, volume };
    onReady?.(chart);

    const resizeObserver = new ResizeObserver(() => {
      if (containerRef.current) chart.applyOptions({ width: containerRef.current.clientWidth });
    });
    resizeObserver.observe(container);

    return () => {
      resizeObserver.disconnect();
      chart.remove();
      chartRef.current = null;
      seriesRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Repaints the chart's chrome (background/grid/borders/candle colors) on
  // every theme toggle — runs once right after the mount effect above too,
  // which is harmless and keeps this effect the single source of truth for
  // "what do the chart's theme-dependent options look like right now".
  useEffect(() => {
    const chart = chartRef.current;
    const s = seriesRef.current;
    if (!chart || !s) return;
    const c = getChartTheme(theme);

    chart.applyOptions({
      layout: { background: { type: ColorType.Solid, color: c.bg }, textColor: c.ink },
      grid: { vertLines: { color: c.grid }, horzLines: { color: c.grid } },
      rightPriceScale: { borderColor: c.border },
      timeScale: { borderColor: c.border },
    });
    s.candle.applyOptions({
      upColor: c.up,
      downColor: c.down,
      borderUpColor: c.ink,
      borderDownColor: c.ink,
      wickUpColor: c.ink,
      wickDownColor: c.ink,
    });
    s.bbUpper.applyOptions({ color: c.ink });
    s.bbLower.applyOptions({ color: c.ink });
  }, [theme]);

  useEffect(() => {
    const s = seriesRef.current;
    if (!s || candles5m.length === 0) return;
    const ct = getChartTheme(theme);

    const times = candles5m.map((c) => (c.openTime / 1000) as UTCTimestamp);
    const closes = candles5m.map((c) => c.close);
    const lengths = seriesLengthsRef.current;

    // Candle/EMA/Bollinger series are colored uniformly via applyOptions
    // (see the [theme] effect above), never per-point, so it's always safe
    // to only push the newest bar here.
    feedSeries(s.candle, candles5m.map((c, i) => ({ time: times[i]!, open: c.open, high: c.high, low: c.low, close: c.close })), lengths, "candle");

    // Volume bars are colored per-point (win/loss-tinted), so a theme
    // toggle needs every bar recolored, not just the newest — keep this on
    // a plain setData rather than feedSeries.
    s.volume.setData(
      candles5m.map((c, i) => ({ time: times[i]!, value: c.volume, color: c.close >= c.open ? `${ct.up}66` : `${ct.down}66` }))
    );

    feedLineSeries(s.ema9, times, ema(closes, 9), lengths, "ema9");
    feedLineSeries(s.ema21, times, ema(closes, 21), lengths, "ema21");
    feedLineSeries(s.ema50, times, ema(closes, 50), lengths, "ema50");

    const bb = bollingerBands(closes, 20, 2);
    feedLineSeries(s.bbUpper, times, bb.map((b) => b.upper), lengths, "bbUpper");
    feedLineSeries(s.bbLower, times, bb.map((b) => b.lower), lengths, "bbLower");
  }, [candles5m, theme]);

  useEffect(() => {
    const s = seriesRef.current;
    if (!s) return;
    const c = getChartTheme(theme);
    const markers: SeriesMarker<UTCTimestamp>[] = trades
      .filter((t) => t.result !== "OPEN" && t.result !== "CANCELLED")
      // Explicit return type here matters: without it, the ternaries below
      // have no contextual type to check against, so TS widens
      // "belowBar"/"aboveBar" and "arrowUp"/"arrowDown" to plain `string`
      // instead of keeping them as the literal union SeriesMarker expects.
      .map(
        (t): SeriesMarker<UTCTimestamp> => ({
          time: (t.entryTime / 1000) as UTCTimestamp,
          position: t.direction === "UP" ? "belowBar" : "aboveBar",
          color: t.result === "WIN" ? c.up : t.result === "LOSS" ? c.down : c.muted,
          shape: t.direction === "UP" ? "arrowUp" : "arrowDown",
          text: t.result,
        }),
      )
      .sort((a, b) => (a.time as number) - (b.time as number));
    s.candle.setMarkers(markers);
  }, [trades, theme]);

  return (
    <Panel title="BTC CHART — 5m — EMA 9/21/50 · BOLLINGER BANDS · VOLUME · TRADE MARKERS" className="col-span-full">
      <div ref={containerRef} className="h-[420px] w-full" />
    </Panel>
  );
}

function feedLineSeries(
  series: ISeriesApi<"Line">,
  times: UTCTimestamp[],
  values: Array<number | null>,
  lengths: Record<string, number>,
  key: string
): void {
  const data = times.map((time, i) => ({ time, value: values[i] })).filter((d): d is { time: UTCTimestamp; value: number } => d.value !== null && d.value !== undefined);
  feedSeries(series, data, lengths, key);
}
