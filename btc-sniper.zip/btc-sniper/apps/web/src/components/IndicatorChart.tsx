import { useEffect, useRef } from "react";
import { createChart, ColorType, type IChartApi, type ISeriesApi, type UTCTimestamp } from "lightweight-charts";
import { rsi, macd } from "@btc-sniper/indicators";
import { useMarketStore } from "../stores/useMarketStore";
import { useThemeStore } from "../stores/useThemeStore";
import { getChartTheme } from "../utils/chartTheme";
import { feedSeries } from "../utils/chartFeed";
import { Panel } from "./Panel";

/**
 * A secondary RSI + MACD chart, time-synced to the main price chart via
 * `syncWith` (the main chart's own visible-range changes are mirrored
 * here, and vice versa) so scrolling/zooming one moves both.
 */
export function IndicatorChart({ syncWith }: { syncWith: IChartApi | null }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const seriesRef = useRef<{ rsi: ISeriesApi<"Line">; macdLine: ISeriesApi<"Line">; signalLine: ISeriesApi<"Line">; hist: ISeriesApi<"Histogram"> } | null>(null);
  // See PriceChart's identical ref — tracks previously-fed point counts so
  // ordinary ticks can use the cheap `series.update()` path. utils/chartFeed.ts.
  const seriesLengthsRef = useRef<Record<string, number>>({});

  const candles5m = useMarketStore((s) => s.candles5m);
  const theme = useThemeStore((s) => s.theme);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // Uses whatever theme is current at mount time; the [theme] effect
    // below repaints everything (including on this same first render) so
    // this initial value doesn't need to stay in sync on its own.
    const c = getChartTheme(theme);

    const chart = createChart(container, {
      width: container.clientWidth,
      height: 220,
      layout: { background: { type: ColorType.Solid, color: c.bg }, textColor: c.ink, fontFamily: "ui-monospace, SFMono-Regular, Menlo, Consolas, monospace" },
      grid: { vertLines: { color: c.grid }, horzLines: { color: c.grid } },
      rightPriceScale: { borderColor: c.border },
      timeScale: { borderColor: c.border, timeVisible: true, secondsVisible: false },
    });

    const rsiSeries = chart.addLineSeries({ color: "#2563EB", lineWidth: 2, priceScaleId: "rsi" });
    chart.priceScale("rsi").applyOptions({ scaleMargins: { top: 0.05, bottom: 0.55 } });

    const macdLine = chart.addLineSeries({ color: "#F59E0B", lineWidth: 2, priceScaleId: "macd" });
    const signalLine = chart.addLineSeries({ color: "#7C5CFF", lineWidth: 2, priceScaleId: "macd" });
    const hist = chart.addHistogramSeries({ priceScaleId: "macd" });
    chart.priceScale("macd").applyOptions({ scaleMargins: { top: 0.55, bottom: 0.05 } });

    chartRef.current = chart;
    seriesRef.current = { rsi: rsiSeries, macdLine, signalLine, hist };

    const resizeObserver = new ResizeObserver(() => {
      if (containerRef.current) chart.applyOptions({ width: containerRef.current.clientWidth });
    });
    resizeObserver.observe(container);

    return () => {
      resizeObserver.disconnect();
      chart.remove();
      chartRef.current = null;
      seriesRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Repaints the chart's chrome (background/grid/borders) on every theme
  // toggle — runs once right after the mount effect above too, which is
  // harmless.
  useEffect(() => {
    const chart = chartRef.current;
    if (!chart) return;
    const c = getChartTheme(theme);
    chart.applyOptions({
      layout: { background: { type: ColorType.Solid, color: c.bg }, textColor: c.ink },
      grid: { vertLines: { color: c.grid }, horzLines: { color: c.grid } },
      rightPriceScale: { borderColor: c.border },
      timeScale: { borderColor: c.border },
    });
  }, [theme]);

  // Two-way time-scale sync with the main chart.
  useEffect(() => {
    const chart = chartRef.current;
    if (!chart || !syncWith) return;

    const fromMain = () => {
      const range = syncWith.timeScale().getVisibleLogicalRange();
      if (range) chart.timeScale().setVisibleLogicalRange(range);
    };
    const fromThis = () => {
      const range = chart.timeScale().getVisibleLogicalRange();
      if (range) syncWith.timeScale().setVisibleLogicalRange(range);
    };

    syncWith.timeScale().subscribeVisibleLogicalRangeChange(fromMain);
    chart.timeScale().subscribeVisibleLogicalRangeChange(fromThis);
    fromMain();

    return () => {
      syncWith.timeScale().unsubscribeVisibleLogicalRangeChange(fromMain);
      chart.timeScale().unsubscribeVisibleLogicalRangeChange(fromThis);
    };
  }, [syncWith]);

  useEffect(() => {
    const s = seriesRef.current;
    if (!s || candles5m.length === 0) return;
    const ct = getChartTheme(theme);
    const times = candles5m.map((c) => (c.openTime / 1000) as UTCTimestamp);
    const closes = candles5m.map((c) => c.close);
    const lengths = seriesLengthsRef.current;

    // RSI/MACD/signal lines are colored uniformly (series-level), so it's
    // safe to only push the newest point on ordinary ticks.
    const rsiValues = rsi(closes, 14);
    feedSeries(
      s.rsi,
      times.map((time, i) => ({ time, value: rsiValues[i] })).filter((d): d is { time: UTCTimestamp; value: number } => d.value !== null),
      lengths,
      "rsi"
    );

    const macdValues = macd(closes, 12, 26, 9);
    feedSeries(
      s.macdLine,
      times.map((time, i) => ({ time, value: macdValues[i]!.macd })).filter((d): d is { time: UTCTimestamp; value: number } => d.value !== null),
      lengths,
      "macdLine"
    );
    feedSeries(
      s.signalLine,
      times.map((time, i) => ({ time, value: macdValues[i]!.signal })).filter((d): d is { time: UTCTimestamp; value: number } => d.value !== null),
      lengths,
      "signalLine"
    );

    // The MACD histogram is colored per-bar (positive/negative), so a
    // theme toggle needs every bar recolored — keep it on plain setData.
    s.hist.setData(
      times
        .map((time, i) => ({ time, value: macdValues[i]!.histogram, color: (macdValues[i]!.histogram ?? 0) >= 0 ? `${ct.up}99` : `${ct.down}99` }))
        .filter((d): d is { time: UTCTimestamp; value: number; color: string } => d.value !== null)
    );
  }, [candles5m, theme]);

  return (
    <Panel title="RSI (14) · MACD (12,26,9)" className="col-span-full">
      <div ref={containerRef} className="h-[220px] w-full" />
    </Panel>
  );
}
