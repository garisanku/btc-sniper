import { useState } from "react";
import { useMarketStore } from "../stores/useMarketStore";
import { api } from "../services/api";
import { Panel } from "./Panel";
import { OpenPositions } from "./OpenPositions";

/**
 * Lets the operator fire an immediate UP or DOWN trade on demand, instead of
 * waiting for the prediction engine to emit a signal — this exists to
 * exercise the full open → settle → history pipeline for testing. It still
 * goes through the same risk manager and executor as every other trade (see
 * BotEngine.placeManualTrade), so it opens a REAL order whenever
 * EXECUTION_MODE=LIVE, exactly like an automatic trade would.
 */
export function ManualTradePanel() {
  const status = useMarketStore((s) => s.botState?.status ?? "STOPPED");
  const executionMode = useMarketStore((s) => s.botState?.executionMode ?? "PAPER");
  const [sizeDraft, setSizeDraft] = useState("");
  const [busyDirection, setBusyDirection] = useState<"UP" | "DOWN" | null>(null);
  const [feedback, setFeedback] = useState<{ ok: boolean; text: string } | null>(null);

  const isLive = executionMode === "LIVE";
  const disabled = status !== "RUNNING" || busyDirection !== null;

  async function fire(direction: "UP" | "DOWN") {
    setBusyDirection(direction);
    setFeedback(null);
    try {
      const size = sizeDraft.trim() ? Number(sizeDraft) : undefined;
      if (size !== undefined && (!Number.isFinite(size) || size <= 0)) {
        setFeedback({ ok: false, text: "Stake must be a positive number." });
        return;
      }
      const result = await api.placeManualTrade(direction, size);
      setFeedback({ ok: result.ok, text: result.message });
    } catch (err) {
      setFeedback({ ok: false, text: (err as Error).message });
    } finally {
      setBusyDirection(null);
    }
  }

  return (
    <Panel
      title="MANUAL TEST TRADE"
      className="col-span-full"
      actions={
        <span
          className={`brutal-badge px-1.5 py-0.5 text-[10px] ${
            isLive ? "bg-terminal-down text-white" : "bg-terminal-up text-black"
          }`}
        >
          {isLive ? "⚠ LIVE — REAL FUNDS" : "PAPER"}
        </span>
      }
    >
      <p className="mb-2 text-xs text-terminal-muted">
        Opens a trade immediately in the direction you pick, bypassing the prediction engine's signal and its
        minimum-confidence requirement — useful for confirming the open/settle/history pipeline end to end. Capital-based
        limits still apply and can still block it: kill switch, cooldown, max trades/hour, max consecutive losses,
        daily loss, and balance.
      </p>

      <div className="mb-2 flex items-center gap-2">
        <label htmlFor="manual-size" className="text-xs text-terminal-muted">
          Stake (USD)
        </label>
        <input
          id="manual-size"
          type="number"
          min="1"
          step="1"
          placeholder="auto"
          value={sizeDraft}
          onChange={(e) => setSizeDraft(e.target.value)}
          disabled={disabled}
          className="brutal-input w-24 px-2 py-1 text-xs disabled:opacity-40"
        />
        <span className="text-[10px] font-medium text-terminal-muted">blank = auto-sized from current confidence</span>
      </div>

      <div className="flex gap-2">
        <button
          type="button"
          disabled={disabled}
          onClick={() => fire("UP")}
          className="brutal-btn flex-1 bg-terminal-up py-2 text-sm text-black"
        >
          {busyDirection === "UP" ? "OPENING…" : "TEST BUY UP"}
        </button>
        <button
          type="button"
          disabled={disabled}
          onClick={() => fire("DOWN")}
          className="brutal-btn flex-1 bg-terminal-down py-2 text-sm text-white"
        >
          {busyDirection === "DOWN" ? "OPENING…" : "TEST SELL DOWN"}
        </button>
      </div>

      {status !== "RUNNING" && <p className="mt-2 text-[10px] font-bold text-terminal-pending">Start the bot to enable manual test trades.</p>}

      {feedback && (
        <p className={`mt-2 text-xs font-bold ${feedback.ok ? "text-terminal-up" : "text-terminal-down"}`}>{feedback.text}</p>
      )}

      <div className="mt-3 border-t-[3px] border-terminal-border pt-2">
        <h3 className="mb-1.5 text-[10px] font-extrabold uppercase tracking-wide text-terminal-muted">
          OPEN POSITIONS — LIVE UNTIL SETTLED
        </h3>
        <OpenPositions />
      </div>
    </Panel>
  );
}
