import { useState } from "react";
import type { BotMode } from "@btc-sniper/types";
import { useMarketStore } from "../stores/useMarketStore";
import { useThemeStore } from "../stores/useThemeStore";
import { api, setApiKey } from "../services/api";
import { formatPrice, formatUsd } from "../utils/format";

const MODES: BotMode[] = ["MANUAL", "SEMI_AUTO", "AUTOMATIC", "SNIPER"];

export function Header() {
  const price = useMarketStore((s) => s.price);
  const connectionStatus = useMarketStore((s) => s.connectionStatus);
  const marketStale = useMarketStore((s) => s.marketStale);
  const botState = useMarketStore((s) => s.botState);
  const risk = useMarketStore((s) => s.risk);
  const themeMode = useThemeStore((s) => s.mode);
  const cycleThemeMode = useThemeStore((s) => s.cycleMode);
  const [busy, setBusy] = useState(false);
  const [keyDraft, setKeyDraft] = useState("");

  const status = botState?.status ?? "STOPPED";
  const mode = (botState?.mode as BotMode | undefined) ?? "SNIPER";
  const executionMode = botState?.executionMode ?? "PAPER";
  const balance = typeof botState?.balance === "number" ? botState.balance : null;

  async function run(action: () => Promise<unknown>) {
    setBusy(true);
    try {
      await action();
    } catch (err) {
      // eslint-disable-next-line no-alert
      alert((err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  const statusColor =
    status === "RUNNING" ? "text-terminal-up" : status === "HALTED" ? "text-terminal-down" : status === "PAUSED" ? "text-terminal-pending" : "text-terminal-muted";

  return (
    <header className="border-b-[3px] border-terminal-border bg-terminal-panel px-3 py-3 sm:px-4">
      <div className="flex flex-wrap items-center gap-x-6 gap-y-2">
        <div className="flex items-baseline gap-2">
          <span className="text-xs font-bold text-terminal-muted">BTC/USDT</span>
          <span className="text-xl font-extrabold tabular-nums sm:text-2xl">${formatPrice(price)}</span>
          {marketStale && <span className="brutal-badge bg-terminal-down px-1.5 py-0.5 text-[10px] text-white">STALE</span>}
        </div>

        <div className="flex items-center gap-1.5 text-xs">
          <span
            className={`h-3 w-3 rounded-full border-2 border-terminal-border ${connectionStatus === "open" ? "bg-terminal-up" : connectionStatus === "connecting" ? "bg-terminal-amber" : "bg-terminal-down"}`}
          />
          <span className="font-bold text-terminal-muted">{connectionStatus === "open" ? "LIVE" : connectionStatus.toUpperCase()}</span>
        </div>

        <div className="flex items-center gap-1.5 text-xs">
          <span className="font-bold text-terminal-muted">STATUS</span>
          <span className={`font-extrabold ${statusColor}`}>{status}</span>
          <span className="text-terminal-muted">·</span>
          <span className="font-bold text-terminal-muted">{executionMode}</span>
          {status === "HALTED" && risk?.haltReason && (
            <span className="brutal-badge bg-terminal-down px-1.5 py-0.5 text-white">REASON: {risk.haltReason}</span>
          )}
        </div>

        {balance !== null && (
          <div className="text-xs">
            <span className="font-bold text-terminal-muted">BALANCE </span>
            <span className="font-extrabold">{formatUsd(balance)}</span>
          </div>
        )}

        <div className="ml-auto flex flex-wrap items-center gap-2">
          <button
            type="button"
            className="brutal-btn bg-terminal-panel px-2 py-1 text-xs"
            onClick={cycleThemeMode}
            aria-label={`Theme: ${themeMode}. Click to cycle light → dark → system.`}
            title={`Theme: ${themeMode} (click to cycle)`}
          >
            {themeMode === "dark" ? "☾ DARK" : themeMode === "system" ? "🖥 SYSTEM" : "☀ LIGHT"}
          </button>

          <select
            className="brutal-input px-2 py-1 text-xs font-bold uppercase"
            value={mode}
            disabled={busy}
            onChange={(e) => run(() => api.setMode(e.target.value as BotMode))}
          >
            {MODES.map((m) => (
              <option key={m} value={m}>
                {m}
              </option>
            ))}
          </select>

          <button
            className="brutal-btn bg-terminal-up px-2 py-1 text-xs text-black"
            disabled={busy || status === "RUNNING"}
            onClick={() => run(() => api.startBot())}
          >
            Start
          </button>
          <button
            className="brutal-btn bg-terminal-amber px-2 py-1 text-xs text-black"
            disabled={busy || status !== "RUNNING"}
            onClick={() => run(() => api.pauseBot())}
          >
            Pause
          </button>
          <button
            className="brutal-btn bg-terminal-panel px-2 py-1 text-xs"
            disabled={busy || status !== "PAUSED"}
            onClick={() => run(() => api.resumeBot())}
          >
            Resume
          </button>
          <button
            className="brutal-btn bg-terminal-panel px-2 py-1 text-xs"
            disabled={busy || status === "STOPPED"}
            onClick={() => run(() => api.stopBot())}
          >
            Stop
          </button>
          <button
            className="brutal-btn bg-terminal-down px-2 py-1 text-xs text-white"
            disabled={busy || status === "HALTED"}
            onClick={() => run(() => api.emergencyStop("Operator emergency stop from dashboard"))}
          >
            Kill Switch
          </button>
          {status === "HALTED" && (
            <button
              className="brutal-btn bg-terminal-up px-2 py-1 text-xs text-black"
              disabled={busy}
              onClick={() => run(() => api.resumeHalt())}
            >
              Clear Halt
            </button>
          )}

          <input
            className="brutal-input w-28 px-2 py-1 text-xs"
            placeholder="API key"
            type="password"
            value={keyDraft}
            onChange={(e) => setKeyDraft(e.target.value)}
            onBlur={() => setApiKey(keyDraft || null)}
          />
        </div>
      </div>
    </header>
  );
}
