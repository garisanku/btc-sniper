import type { ReactNode } from "react";

export function Panel({
  title,
  actions,
  children,
  className = "",
}: {
  title: string;
  actions?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <section className={`brutal-panel p-3 ${className}`}>
      <div className="mb-2 flex items-center justify-between gap-2 border-b-[3px] border-terminal-border pb-2">
        <h2 className="text-xs font-extrabold uppercase tracking-wide text-terminal-ink">{title}</h2>
        {actions}
      </div>
      {children}
    </section>
  );
}
