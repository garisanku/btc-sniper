import { useEffect, useMemo, useState } from "react";
import type { ExecutionMode, TradeStats } from "@btc-sniper/types";
import { useMarketStore } from "../stores/useMarketStore";
import { api } from "../services/api";
import { formatDuration, formatPct, formatPrice, formatTime, formatUsd } from "../utils/format";
import { Panel } from "./Panel";

type ModeFilter = "ALL" | ExecutionMode;
const MODE_FILTERS: ModeFilter[] = ["ALL", "PAPER", "LIVE"];

export function TradeHistory() {
  const trades = useMarketStore((s) => s.trades);
  const [stats, setStats] = useState<TradeStats | null>(null);
  const [filter, setFilter] = useState<ModeFilter>("ALL");

  // Once live trading is wired up, paper simulation trades and real trades
  // land in the same history — this toggle swaps the table and the stats
  // strip between "everything", "paper only", and "live only" so the two
  // are never averaged together by accident.
  const filteredTrades = useMemo(
    () => (filter === "ALL" ? trades : trades.filter((t) => t.mode === filter)),
    [trades, filter],
  );

  // Zero-latency running total: the store already updates `trades` the
  // instant a TRADE_CLOSED event arrives, so summing settled P&L here needs
  // no network round trip at all. This is what actually makes P&L feel
  // "real time" — the server-computed stats below still refresh on every
  // change too, but a fetch is never instant the way this is.
  const livePnl = useMemo(
    () => filteredTrades.reduce((sum, t) => sum + (t.pnl ?? 0), 0),
    [filteredTrades],
  );

  useEffect(() => {
    let cancelled = false;
    const modeArg = filter === "ALL" ? undefined : filter;
    const load = () => api.getStats(modeArg).then((s) => !cancelled && setStats(s)).catch(() => undefined);
    load();
    const interval = setInterval(load, 15_000);
    return () => {
      cancelled = true;
      clearInterval(interval);
    };
    // Depending on `trades` itself (not `trades.length`) matters: a trade
    // settling (TRADE_CLOSED) mutates an existing entry rather than adding
    // one, so `.length` doesn't change but the array reference still does —
    // this is what makes the stats refetch the instant a trade closes,
    // instead of waiting up to 15s for the next poll.
  }, [trades, filter]);

  return (
    <Panel
      title="TRADE HISTORY"
      className="col-span-full"
      actions={
        <div className="flex border-2 border-terminal-border bg-terminal-panel p-0.5 text-[10px]">
          {MODE_FILTERS.map((f) => (
            <button
              key={f}
              type="button"
              onClick={() => setFilter(f)}
              className={`px-2 py-0.5 font-extrabold transition-colors ${
                filter === f ? "bg-terminal-accent text-white" : "text-terminal-muted hover:text-terminal-ink"
              }`}
            >
              {f}
            </button>
          ))}
        </div>
      }
    >
      <div className="mb-3 grid grid-cols-2 gap-2 text-xs sm:grid-cols-4 lg:grid-cols-9">
        <StatCell
          label="LIVE P&L"
          value={formatUsd(livePnl)}
          valueClass={livePnl >= 0 ? "text-terminal-up" : "text-terminal-down"}
        />
        {stats && (
          <>
            <StatCell label="TOTAL" value={String(stats.totalTrades)} />
            <StatCell label="WINS" value={String(stats.wins)} valueClass="text-terminal-up" />
            <StatCell label="LOSSES" value={String(stats.losses)} valueClass="text-terminal-down" />
            <StatCell label="WIN RATE" value={formatPct(stats.winRate)} />
            <StatCell label="TOTAL P&L" value={formatUsd(stats.totalPnl)} valueClass={stats.totalPnl >= 0 ? "text-terminal-up" : "text-terminal-down"} />
            <StatCell label="AVG CONFIDENCE" value={formatPct(stats.averageConfidence)} />
            <StatCell label="AVG DURATION" value={formatDuration(stats.averageDurationMs)} />
            <StatCell label="STREAK" value={`${stats.currentStreak > 0 ? "+" : ""}${stats.currentStreak}`} />
          </>
        )}
      </div>
      <p className="mb-2 text-[10px] text-terminal-muted">
        LIVE P&L sums the settled trades currently loaded below (updates instantly, no server round trip) — TOTAL P&L
        is the all-time server total for {filter === "ALL" ? "every mode" : filter}.
      </p>

      <div className="max-h-72 overflow-auto border-2 border-terminal-border">
        <table className="w-full min-w-[560px] text-left text-xs">
          <thead className="sticky top-0 border-b-2 border-terminal-border bg-terminal-accent text-white">
            <tr>
              <th className="py-1.5 pl-2 pr-2 font-extrabold uppercase">Time</th>
              <th className="py-1.5 pr-2 font-extrabold uppercase">Direction</th>
              <th className="py-1.5 pr-2 font-extrabold uppercase">Entry</th>
              <th className="py-1.5 pr-2 font-extrabold uppercase">Exit</th>
              <th className="py-1.5 pr-2 font-extrabold uppercase">Exit Time</th>
              <th className="py-1.5 pr-2 font-extrabold uppercase">Mode</th>
              <th className="py-1.5 pr-2 font-extrabold uppercase">Confidence</th>
              <th className="py-1.5 pr-2 font-extrabold uppercase">Result</th>
              <th className="py-1.5 pr-2 font-extrabold uppercase">P&L</th>
            </tr>
          </thead>
          <tbody>
            {filteredTrades.length === 0 && (
              <tr>
                <td colSpan={9} className="py-4 text-center font-medium text-terminal-muted">
                  {trades.length === 0 ? "No trades yet." : `No ${filter.toLowerCase()} trades yet.`}
                </td>
              </tr>
            )}
            {filteredTrades.map((t) => (
              <tr key={t.id} className="border-t-2 border-terminal-border/30 odd:bg-terminal-bg">
                <td className="py-1 pl-2 pr-2 tabular-nums">{formatTime(t.entryTime)}</td>
                <td className={`py-1 pr-2 font-extrabold ${t.direction === "UP" ? "text-terminal-up" : "text-terminal-down"}`}>{t.direction}</td>
                <td className="py-1 pr-2 tabular-nums">{formatPrice(t.entryPrice)}</td>
                <td className="py-1 pr-2 tabular-nums">{t.exitPrice !== null ? formatPrice(t.exitPrice) : "—"}</td>
                <td className="py-1 pr-2 tabular-nums">{t.exitTime !== null ? formatTime(t.exitTime) : "—"}</td>
                <td className={`py-1 pr-2 font-extrabold ${t.mode === "LIVE" ? "text-terminal-pending" : "text-terminal-muted"}`}>{t.mode}</td>
                <td className="py-1 pr-2 tabular-nums">{formatPct(t.confidence)}</td>
                <td className={`py-1 pr-2 font-extrabold ${resultColor(t.result)}`}>{t.result}</td>
                <td className={`py-1 pr-2 tabular-nums font-bold ${t.pnl !== null && t.pnl >= 0 ? "text-terminal-up" : "text-terminal-down"}`}>
                  {t.pnl !== null ? formatUsd(t.pnl) : "—"}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Panel>
  );
}

function resultColor(result: string): string {
  if (result === "WIN") return "text-terminal-up";
  if (result === "LOSS") return "text-terminal-down";
  if (result === "OPEN") return "text-terminal-pending";
  return "text-terminal-muted";
}

function StatCell({ label, value, valueClass = "" }: { label: string; value: string; valueClass?: string }) {
  return (
    <div className="border-2 border-terminal-border bg-terminal-bg px-2 py-1">
      <div className="text-[10px] font-bold text-terminal-muted">{label}</div>
      <div className={`font-extrabold ${valueClass}`}>{value}</div>
    </div>
  );
}
