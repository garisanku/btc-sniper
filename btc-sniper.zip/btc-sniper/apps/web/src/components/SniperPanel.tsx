import { useMarketStore } from "../stores/useMarketStore";
import { Panel } from "./Panel";

export function SniperPanel() {
  const prediction = useMarketStore((s) => s.prediction);

  if (!prediction) {
    return (
      <Panel title="SNIPER MODE">
        <p className="text-sm text-terminal-muted">No prediction yet.</p>
      </Panel>
    );
  }

  return (
    <Panel title="SNIPER MODE">
      <ul className="space-y-1 text-sm">
        {prediction.sniperChecks.map((check) => (
          <li key={check.name} className="flex items-center justify-between gap-2" title={check.detail}>
            <span className="capitalize text-terminal-muted">{humanizeFactorName(check.name)}</span>
            <span className={check.passed ? "text-terminal-up" : "text-terminal-down"}>{check.passed ? "✓" : "✗"}</span>
          </li>
        ))}
      </ul>
      <div className="mt-3 flex items-center justify-between border-t-[3px] border-terminal-border pt-2">
        <span className="text-xs font-bold text-terminal-muted">ALIGNMENT</span>
        <span className="font-extrabold">{prediction.sniperAligned}/6</span>
      </div>
      <div
        className={`brutal-badge mt-2 px-2 py-1 text-center text-sm ${
          prediction.sniperReady ? "bg-terminal-up text-black" : "bg-terminal-bg text-terminal-muted"
        }`}
      >
        {prediction.sniperReady ? `SNIPER SIGNAL — BUY ${prediction.signal === "BUY_UP" ? "UP" : "DOWN"}` : "WAITING FOR ALIGNMENT"}
      </div>
    </Panel>
  );
}

function humanizeFactorName(name: string): string {
  switch (name) {
    case "trend":
      return "Trend";
    case "momentum":
      return "Momentum";
    case "volume":
      return "Buy Volume";
    case "orderFlow":
      return "Order Flow";
    case "priceAction":
      return "Price Action";
    case "volatility":
      return "Volatility";
    default:
      return name;
  }
}
