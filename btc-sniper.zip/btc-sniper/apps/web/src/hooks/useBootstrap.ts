import { useEffect } from "react";
import type { Candle } from "@btc-sniper/types";
import { api } from "../services/api";
import { dashboardSocket } from "../services/ws";
import { useMarketStore } from "../stores/useMarketStore";

/**
 * Loads initial state over REST (candle history, recent trades) once, then
 * opens the live WebSocket feed for everything after that. REST is only
 * ever used for the initial snapshot and user-triggered actions (start/
 * stop/mode/backtest) — the running dashboard never polls.
 */
export function useBootstrap(): void {
  const applyMessage = useMarketStore((s) => s.applyMessage);
  const setInitialCandles = useMarketStore((s) => s.setInitialCandles);
  const setInitialTrades = useMarketStore((s) => s.setInitialTrades);
  const setConnectionStatus = useMarketStore((s) => s.setConnectionStatus);

  useEffect(() => {
    let cancelled = false;

    (async () => {
      try {
        const [candles5m, candles1m, trades] = await Promise.all([
          api.getCandles("5m", 300),
          api.getCandles("1m", 300),
          api.getTrades(100),
        ]);
        if (cancelled) return;
        setInitialCandles("5m", candles5m.candles as Candle[]);
        setInitialCandles("1m", candles1m.candles as Candle[]);
        setInitialTrades(trades);
      } catch {
        // The API may not be reachable yet on first paint — the WS
        // connection below will backfill live state as soon as it's up,
        // and the user can retry actions once the backend is reachable.
      }
    })();

    const offStatus = dashboardSocket.onStatusChange(setConnectionStatus);
    const offAll = subscribeToAllEvents(applyMessage);
    dashboardSocket.connect();

    return () => {
      cancelled = true;
      offStatus();
      offAll();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
}

function subscribeToAllEvents(applyMessage: (message: import("@btc-sniper/types").WsMessage) => void): () => void {
  const eventNames: Array<import("@btc-sniper/types").WsEventName> = [
    "PRICE_UPDATE",
    "CANDLE_UPDATE",
    "VOLUME_UPDATE",
    "ORDER_FLOW_UPDATE",
    "INDICATOR_UPDATE",
    "PREDICTION_UPDATE",
    "SIGNAL_UPDATE",
    "TRADE_OPENED",
    "TRADE_CLOSED",
    "BOT_STATUS_UPDATE",
    "RISK_UPDATE",
    "LOG",
    "MARKET_STALE",
  ];
  const unsubscribers = eventNames.map((name) =>
    dashboardSocket.on(name, (payload) => applyMessage({ type: name, payload } as import("@btc-sniper/types").WsMessage))
  );
  return () => unsubscribers.forEach((u) => u());
}
