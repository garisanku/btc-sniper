import { useState } from "react";
import type { IChartApi } from "lightweight-charts";
import { useBootstrap } from "./hooks/useBootstrap";
import { Header } from "./components/Header";
import { PriceChart } from "./components/PriceChart";
import { IndicatorChart } from "./components/IndicatorChart";
import { PredictionPanel } from "./components/PredictionPanel";
import { VolumePanel } from "./components/VolumePanel";
import { SniperPanel } from "./components/SniperPanel";
import { ManualTradePanel } from "./components/ManualTradePanel";
import { TradeHistory } from "./components/TradeHistory";
import { LogPanel } from "./components/LogPanel";

export default function App() {
  useBootstrap();
  const [mainChart, setMainChart] = useState<IChartApi | null>(null);

  return (
    <div className="min-h-screen bg-terminal-bg text-terminal-ink">
      <Header />
      <main className="mx-auto grid max-w-[1600px] grid-cols-1 gap-3 p-3 lg:grid-cols-3">
        <PriceChart onReady={setMainChart} />
        <IndicatorChart syncWith={mainChart} />

        <PredictionPanel />
        <VolumePanel />
        <SniperPanel />

        <ManualTradePanel />
        <TradeHistory />
        <LogPanel />
      </main>
      <footer className="mx-auto max-w-[1600px] px-3 pb-4 text-[10px] text-terminal-muted">
        Predictions are probabilistic estimates, not guarantees. Nothing here is financial advice. Paper trading is the
        default — real funds are only at risk if EXECUTION_MODE is explicitly set to LIVE with a working broker adapter.
      </footer>
    </div>
  );
}
