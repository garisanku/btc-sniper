import type { Theme } from "../stores/useThemeStore";

// lightweight-charts is configured imperatively (createChart / applyOptions)
// and can't read CSS custom properties, so the palette from index.css's
// :root / .dark blocks is duplicated here in plain hex. Keep these two in
// sync if the palette ever changes.
export interface ChartTheme {
  bg: string;
  ink: string;
  grid: string;
  border: string;
  up: string;
  down: string;
  muted: string;
}

const LIGHT: ChartTheme = {
  bg: "#FFFFFF",
  ink: "#111111",
  grid: "#D8CFB8",
  border: "#111111",
  up: "#00C853",
  down: "#FF3B3B",
  muted: "#55503F",
};

const DARK: ChartTheme = {
  bg: "#14171F",
  ink: "#F0ECDD",
  grid: "#2A2E3A",
  border: "#F0ECDD",
  up: "#2FE07C",
  down: "#FF5C5C",
  muted: "#A39C86",
};

export function getChartTheme(theme: Theme): ChartTheme {
  return theme === "dark" ? DARK : LIGHT;
}
