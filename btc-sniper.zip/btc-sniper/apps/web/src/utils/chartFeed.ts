// The bot ticks (and candles5m can change) about once per second, and each
// price/indicator chart feeds 6+ series off that single array. The naive
// approach — `series.setData(wholeArray)` on every tick — makes
// lightweight-charts re-index and re-render the *entire* series every time,
// even though a closed historical bar never actually changes: only ever the
// newest point does (it's either being revised in place, mid-candle, or a
// brand new bar just opened). `series.update()` is the O(1) primitive
// lightweight-charts provides for exactly that streaming case. This helper
// picks between the two: `update` on the common single-point-changed tick,
// falling back to a full `setData` for the first load or anything
// unexpected (a shrink, or more than one new point landing between two
// renders — e.g. a throttled/backgrounded tab) so correctness never
// depends on ticks arriving one at a time.
//
// Only safe for series whose per-point styling doesn't vary — e.g. a plain
// line's color is a series-level `applyOptions`, not per-point, so
// repainting just the newest point never leaves stale-colored history
// behind. A series with per-point color (a histogram bar colored
// win/loss-green/red) should keep using `setData` directly instead, since
// changing the *whole series'* color scheme (a theme toggle) requires
// touching every existing point, not just the newest one.
//
// Typed structurally (not against lightweight-charts' own ISeriesApi<T>)
// so this one helper can take a candlestick series, a line series, or
// anything else with the same two methods without fighting generic
// variance at every call site.
interface FeedableSeries<T> {
  setData(data: T[]): void;
  update(point: T): void;
}

export function feedSeries<T extends { time: unknown }>(series: FeedableSeries<T>, points: T[], lengths: Record<string, number>, key: string): void {
  if (points.length === 0) return;
  const prevLength = lengths[key] ?? 0;
  const delta = points.length - prevLength;

  if (prevLength === 0 || delta > 1 || delta < 0) {
    series.setData(points);
  } else {
    series.update(points[points.length - 1]!);
  }
  lengths[key] = points.length;
}
