import { create } from "zustand";
import type {
  BookTicker,
  BotState,
  Candle,
  IndicatorSnapshot,
  MarketStructure,
  Prediction,
  RiskState,
  Trade,
  TradeFlowSnapshot,
  WsMessage,
} from "@btc-sniper/types";
import type { ConnectionStatus } from "../services/ws";

export interface LogLine {
  level: "info" | "warn" | "error";
  message: string;
  timestamp: number;
  context?: Record<string, unknown>;
}

interface MarketStoreState {
  connectionStatus: ConnectionStatus;
  price: number;
  priceTimestamp: number;
  marketStale: boolean;
  candles1m: Candle[];
  candles5m: Candle[];
  indicators: IndicatorSnapshot | null;
  structure: MarketStructure | null;
  tradeFlow: TradeFlowSnapshot | null;
  bookTicker: BookTicker | null;
  prediction: Prediction | null;
  willTrade: boolean;
  blockReason: string | null;
  trades: Trade[];
  botState: Partial<BotState> | null;
  risk: RiskState | null;
  logs: LogLine[];

  setConnectionStatus: (status: ConnectionStatus) => void;
  setInitialCandles: (interval: "1m" | "5m", candles: Candle[]) => void;
  setInitialTrades: (trades: Trade[]) => void;
  applyMessage: (message: WsMessage) => void;
}

const MAX_CANDLES = 300;
const MAX_LOGS = 200;
const MAX_TRADES = 200;

function upsertCandle(list: Candle[], candle: Candle): Candle[] {
  const last = list[list.length - 1];
  if (last && last.openTime === candle.openTime) {
    const copy = list.slice(0, -1);
    copy.push(candle);
    return copy;
  }
  const next = [...list, candle];
  return next.length > MAX_CANDLES ? next.slice(next.length - MAX_CANDLES) : next;
}

export const useMarketStore = create<MarketStoreState>((set, get) => ({
  connectionStatus: "connecting",
  price: 0,
  priceTimestamp: 0,
  marketStale: false,
  candles1m: [],
  candles5m: [],
  indicators: null,
  structure: null,
  tradeFlow: null,
  bookTicker: null,
  prediction: null,
  willTrade: false,
  blockReason: null,
  trades: [],
  botState: null,
  risk: null,
  logs: [],

  setConnectionStatus: (status) => set({ connectionStatus: status }),

  setInitialCandles: (interval, candles) => set(interval === "1m" ? { candles1m: candles } : { candles5m: candles }),

  setInitialTrades: (trades) => set({ trades }),

  applyMessage: (message) => {
    switch (message.type) {
      case "PRICE_UPDATE":
        set({ price: message.payload.price, priceTimestamp: message.payload.timestamp, marketStale: false });
        return;
      case "CANDLE_UPDATE": {
        const { interval, candle } = message.payload;
        if (interval === "1m") set({ candles1m: upsertCandle(get().candles1m, candle), marketStale: false });
        else set({ candles5m: upsertCandle(get().candles5m, candle), marketStale: false });
        return;
      }
      case "VOLUME_UPDATE":
        set({ tradeFlow: message.payload });
        return;
      case "ORDER_FLOW_UPDATE":
        set({ bookTicker: message.payload });
        return;
      case "INDICATOR_UPDATE":
        set({ indicators: message.payload.indicators, structure: message.payload.structure });
        return;
      case "PREDICTION_UPDATE":
        set({ prediction: message.payload });
        return;
      case "SIGNAL_UPDATE":
        set({ prediction: message.payload.prediction, willTrade: message.payload.willTrade, blockReason: message.payload.blockReason });
        return;
      case "TRADE_OPENED": {
        const trades = [message.payload, ...get().trades].slice(0, MAX_TRADES);
        set({ trades });
        return;
      }
      case "TRADE_CLOSED": {
        const trades = get().trades.map((t) => (t.id === message.payload.id ? message.payload : t));
        const exists = trades.some((t) => t.id === message.payload.id);
        set({ trades: exists ? trades : [message.payload, ...trades].slice(0, MAX_TRADES) });
        return;
      }
      case "BOT_STATUS_UPDATE":
        set({ botState: { ...get().botState, ...message.payload } });
        return;
      case "RISK_UPDATE":
        set({ risk: message.payload });
        return;
      case "MARKET_STALE":
        set({ marketStale: true });
        return;
      case "LOG": {
        const logs = [message.payload as LogLine, ...get().logs].slice(0, MAX_LOGS);
        set({ logs });
        return;
      }
      default:
        return;
    }
  },
}));
