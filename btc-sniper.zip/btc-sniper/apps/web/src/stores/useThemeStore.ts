import { create } from "zustand";

// `Theme` is the resolved value actually painted (what PriceChart/
// IndicatorChart and the `.dark` class care about). `ThemeMode` is the
// user's stored preference — "system" means "whatever the OS says right
// now", which can change without the user touching this app at all.
export type Theme = "light" | "dark";
export type ThemeMode = Theme | "system";

// Kept in sync with the inline script in index.html, which sets the same
// class on <html> before React ever mounts (so there's no flash of the
// wrong theme on load) — this store takes over from there for toggling and
// for tracking live OS-theme changes while mode === "system".
export const THEME_STORAGE_KEY = "btc-sniper-theme";

function getSystemTheme(): Theme {
  return typeof window !== "undefined" && window.matchMedia?.("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}

function getInitialMode(): ThemeMode {
  if (typeof window === "undefined") return "system";
  const stored = window.localStorage.getItem(THEME_STORAGE_KEY);
  if (stored === "light" || stored === "dark" || stored === "system") return stored;
  return "system";
}

function resolveTheme(mode: ThemeMode): Theme {
  return mode === "system" ? getSystemTheme() : mode;
}

function applyTheme(theme: Theme): void {
  document.documentElement.classList.toggle("dark", theme === "dark");
}

interface ThemeStoreState {
  mode: ThemeMode;
  theme: Theme;
  setMode: (mode: ThemeMode) => void;
  /** Cycles light -> dark -> system -> light. */
  cycleMode: () => void;
}

const initialMode = getInitialMode();
const initialTheme = resolveTheme(initialMode);
if (typeof document !== "undefined") applyTheme(initialTheme);

const MODE_ORDER: ThemeMode[] = ["light", "dark", "system"];

export const useThemeStore = create<ThemeStoreState>((set, get) => ({
  mode: initialMode,
  theme: initialTheme,
  setMode: (mode) => {
    try {
      window.localStorage.setItem(THEME_STORAGE_KEY, mode);
    } catch {
      // localStorage can throw (private browsing, disabled storage) — the
      // switch still works for the rest of the session, it just won't
      // persist across reloads.
    }
    const theme = resolveTheme(mode);
    applyTheme(theme);
    set({ mode, theme });
  },
  cycleMode: () => {
    const next = MODE_ORDER[(MODE_ORDER.indexOf(get().mode) + 1) % MODE_ORDER.length]!;
    get().setMode(next);
  },
}));

// While mode === "system", follow the OS setting live (no reload needed) —
// e.g. the dashboard flips to dark automatically when the OS switches at
// sunset.
if (typeof window !== "undefined" && window.matchMedia) {
  const mql = window.matchMedia("(prefers-color-scheme: dark)");
  const handleSystemChange = () => {
    if (useThemeStore.getState().mode !== "system") return;
    const theme = getSystemTheme();
    applyTheme(theme);
    useThemeStore.setState({ theme });
  };
  // addEventListener is the modern API; addListener is the Safari <14 fallback.
  if (mql.addEventListener) mql.addEventListener("change", handleSystemChange);
  else mql.addListener(handleSystemChange);
}
