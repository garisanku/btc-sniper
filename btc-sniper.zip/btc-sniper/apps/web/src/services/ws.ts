import type { WsEventMap, WsEventName, WsMessage } from "@btc-sniper/types";

const WS_URL = import.meta.env.VITE_WS_URL ?? "ws://localhost:4000/ws";

export type ConnectionStatus = "connecting" | "open" | "closed";

type Listener = (message: WsMessage) => void;
type StatusListener = (status: ConnectionStatus) => void;

const INITIAL_BACKOFF_MS = 1_000;
const MAX_BACKOFF_MS = 15_000;

/**
 * Browser-side WebSocket client with the same reconnect-with-backoff
 * philosophy as the backend's Binance client: the dashboard must recover
 * from a dropped connection to the API server on its own, without a page
 * refresh.
 */
class DashboardSocket {
  private socket: WebSocket | null = null;
  private listeners = new Set<Listener>();
  private statusListeners = new Set<StatusListener>();
  private attempt = 0;
  private status: ConnectionStatus = "closed";
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null;

  connect(): void {
    if (this.socket) return;
    this.setStatus("connecting");
    const socket = new WebSocket(WS_URL);
    this.socket = socket;

    socket.onopen = () => {
      this.attempt = 0;
      this.setStatus("open");
    };
    socket.onmessage = (event) => {
      try {
        const message = JSON.parse(event.data) as WsMessage;
        for (const listener of this.listeners) listener(message);
      } catch {
        // Ignore malformed frames rather than crashing the dashboard.
      }
    };
    socket.onclose = () => {
      this.socket = null;
      this.setStatus("closed");
      this.scheduleReconnect();
    };
    socket.onerror = () => {
      socket.close();
    };
  }

  disconnect(): void {
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    this.socket?.close();
    this.socket = null;
  }

  on<K extends WsEventName>(type: K, handler: (payload: WsEventMap[K]) => void): () => void {
    const listener: Listener = (message) => {
      if (message.type === type) handler(message.payload as WsEventMap[K]);
    };
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  onStatusChange(handler: StatusListener): () => void {
    this.statusListeners.add(handler);
    handler(this.status);
    return () => this.statusListeners.delete(handler);
  }

  private setStatus(status: ConnectionStatus): void {
    this.status = status;
    for (const l of this.statusListeners) l(status);
  }

  private scheduleReconnect(): void {
    this.attempt += 1;
    const delay = Math.min(INITIAL_BACKOFF_MS * 2 ** (this.attempt - 1), MAX_BACKOFF_MS);
    this.reconnectTimer = setTimeout(() => this.connect(), delay);
  }
}

export const dashboardSocket = new DashboardSocket();
