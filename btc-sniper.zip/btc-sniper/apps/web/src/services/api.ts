import type { BacktestResult, BotMode, Direction, ExecutionMode, Prediction, Trade, TradeStats } from "@btc-sniper/types";

// Never put secrets in Vite env vars — they end up in the client bundle.
// This is a base URL only; auth (when DASHBOARD_API_KEY is set server-side)
// is entered by the operator in the UI and kept in memory, not baked into
// the build.
const API_BASE = import.meta.env.VITE_API_URL ?? "http://localhost:4000";

let apiKey: string | null = null;
export function setApiKey(key: string | null): void {
  apiKey = key;
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const headers = new Headers(init?.headers);
  // Only set Content-Type when there's an actual JSON body to send. Fastify's
  // built-in body parser rejects a request that declares
  // "Content-Type: application/json" but sends an empty body (as every
  // no-payload POST here does — start/stop/pause/resume/etc.) with a 400
  // ("Body cannot be empty when content-type is set to 'application/json'"),
  // which is exactly the "Bad Request" the Start button was hitting.
  if (init?.body !== undefined) headers.set("Content-Type", "application/json");
  if (apiKey) headers.set("x-api-key", apiKey);

  const res = await fetch(`${API_BASE}${path}`, { ...init, headers });
  const body = await res.json().catch(() => null);
  if (!res.ok) {
    const message = (body && typeof body === "object" && "error" in body ? String((body as { error: unknown }).error) : res.statusText) ?? "Request failed";
    throw new Error(message);
  }
  return body as T;
}

export const api = {
  getBtc: () => request<{ symbol: string; price: number; stale: boolean; timestamp: number }>("/api/market/btc"),
  getCandles: (interval: "1m" | "5m", limit = 300) => request<{ candles: unknown[] }>(`/api/market/candles?interval=${interval}&limit=${limit}`),
  getPrediction: () => request<Prediction>("/api/prediction/current"),
  getTrades: (limit = 100, mode?: ExecutionMode) =>
    request<Trade[]>(`/api/trades?limit=${limit}${mode ? `&mode=${mode}` : ""}`),
  getStats: (mode?: ExecutionMode) => request<TradeStats>(`/api/stats${mode ? `?mode=${mode}` : ""}`),
  getBotStatus: () => request<Record<string, unknown>>("/api/bot/status"),
  startBot: () => request<{ ok: boolean }>("/api/bot/start", { method: "POST" }),
  stopBot: () => request<{ ok: boolean }>("/api/bot/stop", { method: "POST" }),
  pauseBot: () => request<{ ok: boolean }>("/api/bot/pause", { method: "POST" }),
  resumeBot: () => request<{ ok: boolean }>("/api/bot/resume", { method: "POST" }),
  setMode: (mode: BotMode) => request<{ ok: boolean }>("/api/bot/mode", { method: "POST", body: JSON.stringify({ mode }) }),
  emergencyStop: (reason?: string) => request<{ ok: boolean }>("/api/bot/emergency-stop", { method: "POST", body: JSON.stringify({ reason }) }),
  resumeHalt: () => request<{ ok: boolean }>("/api/bot/resume-halt", { method: "POST" }),
  confirmTrade: () => request<{ ok: boolean; message: string }>("/api/trade/execute", { method: "POST" }),
  placeManualTrade: (direction: Direction, sizeUsd?: number) =>
    request<{ ok: boolean; message: string }>("/api/trade/manual", {
      method: "POST",
      body: JSON.stringify({ direction, ...(sizeUsd ? { sizeUsd } : {}) }),
    }),
  runBacktest: (days: number) => request<BacktestResult>("/api/backtest/run", { method: "POST", body: JSON.stringify({ days }) }),
};
