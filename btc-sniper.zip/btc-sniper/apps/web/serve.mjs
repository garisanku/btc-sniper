// Minimal static file server for the production build (apps/web/dist).
// Deliberately dependency-free (no express/serve-static) — this only ever
// needs to hand back pre-built static assets behind a reverse proxy or
// directly on a small VM, and one less runtime dependency in the final
// Docker image is worth a ~40-line http server.
import { createServer } from "node:http";
import { readFile, stat } from "node:fs/promises";
import { extname, join, normalize } from "node:path";

const ROOT = join(process.cwd(), "dist");
const PORT = Number(process.env.PORT ?? 4173);

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".ico": "image/x-icon",
  ".map": "application/json",
};

const server = createServer(async (req, res) => {
  try {
    const url = new URL(req.url ?? "/", "http://localhost");
    let filePath = normalize(join(ROOT, decodeURIComponent(url.pathname)));
    if (!filePath.startsWith(ROOT)) {
      res.writeHead(403).end("Forbidden");
      return;
    }

    let fileStat;
    try {
      fileStat = await stat(filePath);
    } catch {
      filePath = join(ROOT, "index.html"); // SPA fallback
      fileStat = await stat(filePath);
    }
    if (fileStat.isDirectory()) filePath = join(filePath, "index.html");

    const body = await readFile(filePath);
    res.writeHead(200, { "content-type": MIME[extname(filePath)] ?? "application/octet-stream" });
    res.end(body);
  } catch (err) {
    res.writeHead(500).end(`Internal error: ${(err instanceof Error ? err.message : String(err))}`);
  }
});

server.listen(PORT, "0.0.0.0", () => {
  // eslint-disable-next-line no-console
  console.log(`Static dashboard build served at http://0.0.0.0:${PORT}`);
});
