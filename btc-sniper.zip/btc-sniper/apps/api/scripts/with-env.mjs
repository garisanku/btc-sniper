#!/usr/bin/env node
// ============================================================================
// Runs an arbitrary command (typically the Prisma CLI) with the monorepo's
// root .env file loaded into its environment first.
//
// Why this exists: the Prisma CLI does its own independent environment
// loading, completely separate from the dotenv.config() call in
// src/config.ts (that only runs once the actual API process starts). Because
// this workspace's schema lives at a custom path (../../prisma/schema.prisma,
// see the "prisma.schema" field in package.json) and npm workspace scripts
// run with cwd set to apps/api, Prisma's own auto-discovery does not reliably
// find the root-level .env two directories up — on some platforms/versions
// it looks next to the schema file, on others next to cwd, and neither is
// where our single .env lives. Loading it explicitly here, in plain Node,
// works the same way on Linux, macOS, and Windows.
// ============================================================================

import { fileURLToPath } from "node:url";
import path from "node:path";
import { spawnSync } from "node:child_process";
import dotenv from "dotenv";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const rootEnvPath = path.resolve(__dirname, "../../../.env");

const result = dotenv.config({ path: rootEnvPath });
if (result.error) {
  // Not fatal: a missing root .env doesn't mean the variables the wrapped
  // command needs are actually missing — a Docker build passes them as
  // build ARG/ENV instead (see Dockerfile), and CI commonly injects them as
  // real environment variables. .dockerignore deliberately excludes .env
  // from the build context in the first place (never bake secrets into an
  // image layer), so this warning is expected and harmless there. If
  // something genuinely isn't set, the wrapped command (usually the Prisma
  // CLI) will fail on its own with a specific "which variable" error.
  console.warn(
    `[with-env] Could not load ${rootEnvPath} (${result.error.message}) — continuing with the current process environment. ` +
      `If you're developing locally and a command below fails, run "cp .env.example .env" in the project root.`,
  );
}

const [, , command, ...args] = process.argv;
if (!command) {
  console.error("Usage: node scripts/with-env.mjs <command> [args...]");
  process.exit(1);
}

// shell: true on Windows so the resolved binary (e.g. prisma.cmd in
// node_modules/.bin) actually executes; on POSIX it runs directly.
const run = spawnSync(command, args, {
  stdio: "inherit",
  env: process.env,
  shell: process.platform === "win32",
});

if (run.error) {
  console.error(`[with-env] Failed to run "${command}": ${run.error.message}`);
  process.exit(1);
}

process.exit(run.status ?? 1);
