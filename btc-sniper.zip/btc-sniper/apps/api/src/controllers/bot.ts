import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { botEngine } from "../services/bot-engine.js";
import { requireApiKey } from "./auth.js";
import * as repo from "../db/repository.js";
import { strategyConfig, env } from "../config.js";

const modeSchema = z.object({
  mode: z.enum(["MANUAL", "SEMI_AUTO", "AUTOMATIC", "SNIPER"]),
});

const manualTradeSchema = z.object({
  direction: z.enum(["UP", "DOWN"]),
  // Optional stake override in USD; omit to use the engine's own
  // confidence-scaled position sizing, same as an automatic trade.
  sizeUsd: z.coerce.number().positive().max(1_000_000).optional(),
});

export async function botController(fastify: FastifyInstance): Promise<void> {
  fastify.get("/api/bot/status", async () => {
    const snapshot = botEngine.getStatusSnapshot();
    const persisted = await repo.getOrCreateBotState({
      mode: snapshot.botState.mode,
      executionMode: strategyConfig.executionMode,
      balance: env.PAPER_INITIAL_BALANCE,
    });
    return { ...persisted, status: snapshot.botState.status, mode: snapshot.botState.mode, risk: snapshot.risk };
  });

  fastify.post("/api/bot/start", { preHandler: requireApiKey }, async () => {
    await botEngine.start();
    return { ok: true };
  });

  fastify.post("/api/bot/stop", { preHandler: requireApiKey }, async () => {
    await botEngine.stop();
    return { ok: true };
  });

  fastify.post("/api/bot/pause", { preHandler: requireApiKey }, async () => {
    await botEngine.pause();
    return { ok: true };
  });

  fastify.post("/api/bot/resume", { preHandler: requireApiKey }, async () => {
    await botEngine.resumeFromPause();
    return { ok: true };
  });

  fastify.post("/api/bot/mode", { preHandler: requireApiKey }, async (request, reply) => {
    const parsed = modeSchema.safeParse(request.body);
    if (!parsed.success) {
      reply.code(400);
      return { error: parsed.error.flatten() };
    }
    await botEngine.setMode(parsed.data.mode);
    return { ok: true };
  });

  fastify.post("/api/bot/emergency-stop", { preHandler: requireApiKey }, async (request) => {
    const body = (request.body as { reason?: string } | undefined) ?? {};
    await botEngine.emergencyStop(body.reason ?? "MANUAL EMERGENCY STOP");
    return { ok: true };
  });

  fastify.post("/api/bot/resume-halt", { preHandler: requireApiKey }, async () => {
    await botEngine.resumeFromHalt();
    return { ok: true };
  });

  fastify.post("/api/trade/execute", { preHandler: requireApiKey }, async (_request, reply) => {
    const result = await botEngine.confirmPendingTrade();
    if (!result.ok) reply.code(409);
    return result;
  });

  // Manual UP/DOWN test trade — opens immediately in the operator-chosen
  // direction, bypassing the prediction engine's own signal (see
  // BotEngine.placeManualTrade for what it does and does not bypass). Used
  // by the dashboard's "Manual Test Trade" panel to exercise the full
  // open/settle/history pipeline on demand.
  fastify.post("/api/trade/manual", { preHandler: requireApiKey }, async (request, reply) => {
    const parsed = manualTradeSchema.safeParse(request.body);
    if (!parsed.success) {
      reply.code(400);
      return { error: parsed.error.flatten() };
    }
    const result = await botEngine.placeManualTrade(parsed.data.direction, parsed.data.sizeUsd);
    if (!result.ok) reply.code(409);
    return result;
  });
}
