import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { botEngine } from "../services/bot-engine.js";
import { strategyConfig } from "../config.js";

const candlesQuerySchema = z.object({
  interval: z.enum(["1m", "5m"]).default("5m"),
  limit: z.coerce.number().int().positive().max(500).default(200),
});

export async function marketController(fastify: FastifyInstance): Promise<void> {
  fastify.get("/api/market/btc", async () => {
    const snapshot = botEngine.getMarketProvider().getSnapshot();
    return {
      symbol: snapshot.symbol,
      price: snapshot.price,
      bookTicker: snapshot.bookTicker,
      stale: snapshot.stale,
      timestamp: snapshot.timestamp,
    };
  });

  fastify.get("/api/market/candles", async (request) => {
    const query = candlesQuerySchema.parse(request.query);
    const snapshot = botEngine.getMarketProvider().getSnapshot();
    const source = query.interval === "1m" ? snapshot.candles1m : snapshot.candles5m;
    return { symbol: strategyConfig.symbol, interval: query.interval, candles: source.slice(-query.limit) };
  });

  fastify.get("/api/market/volume", async () => {
    const snapshot = botEngine.getMarketProvider().getSnapshot();
    return snapshot.tradeFlow;
  });
}
