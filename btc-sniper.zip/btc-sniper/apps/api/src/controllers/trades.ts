import type { FastifyInstance } from "fastify";
import { z } from "zod";
import * as repo from "../db/repository.js";

const modeSchema = z.enum(["PAPER", "LIVE"]).optional();

const listQuerySchema = z.object({
  limit: z.coerce.number().int().positive().max(500).default(100),
  mode: modeSchema,
});

const statsQuerySchema = z.object({
  mode: modeSchema,
});

export async function tradesController(fastify: FastifyInstance): Promise<void> {
  // ?mode=PAPER|LIVE filters to one execution mode; omit for both combined.
  // The dashboard's trade-history panel uses this to swap between paper and
  // live history once real trading is wired up, so paper simulation results
  // never get silently averaged into real P&L (or vice versa).
  fastify.get("/api/trades", async (request) => {
    const { limit, mode } = listQuerySchema.parse(request.query);
    return repo.listRecentTrades(limit, mode);
  });

  fastify.get("/api/stats", async (request) => {
    const { mode } = statsQuerySchema.parse(request.query);
    return repo.computeTradeStats(mode);
  });
}
