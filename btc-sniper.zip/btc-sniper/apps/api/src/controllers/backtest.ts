import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { BacktestEngine } from "../backtest/engine.js";
import { fetchHistoricalCandles } from "../backtest/fetch-history.js";
import { requireApiKey } from "./auth.js";
import { strategyConfig, env } from "../config.js";
import { logger } from "../logger.js";

const backtestBodySchema = z.object({
  days: z.number().int().positive().max(30).default(7),
});

export async function backtestController(fastify: FastifyInstance): Promise<void> {
  fastify.post("/api/backtest/run", { preHandler: requireApiKey }, async (request, reply) => {
    const parsed = backtestBodySchema.safeParse(request.body ?? {});
    if (!parsed.success) {
      reply.code(400);
      return { error: parsed.error.flatten() };
    }

    const endTime = Date.now();
    const startTime = endTime - parsed.data.days * 24 * 60 * 60 * 1000;

    try {
      const candles = await fetchHistoricalCandles("5m", startTime, endTime);
      if (candles.length === 0) {
        reply.code(502);
        return { error: "No historical candles returned by Binance REST API. Requires network access to api.binance.com." };
      }
      const engine = new BacktestEngine();
      const result = await engine.run(candles, strategyConfig, env.PAPER_INITIAL_BALANCE, env.PAPER_PAYOUT_RATIO);
      logger.info("BACKTEST COMPLETE", { days: parsed.data.days, totalTrades: result.totalTrades, winRate: result.winRate.toFixed(1) });
      return result;
    } catch (err) {
      logger.error("Backtest failed", { error: (err as Error).message });
      reply.code(502);
      return { error: `Backtest failed: ${(err as Error).message}. This endpoint requires live network access to Binance's REST API.` };
    }
  });
}
