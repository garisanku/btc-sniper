import type { FastifyInstance } from "fastify";
import { botEngine } from "../services/bot-engine.js";

export async function predictionController(fastify: FastifyInstance): Promise<void> {
  fastify.get("/api/prediction/current", async (_request, reply) => {
    const { lastPrediction } = botEngine.getStatusSnapshot();
    if (!lastPrediction) {
      reply.code(503);
      return { error: "No prediction available yet — the bot may still be warming up its candle history." };
    }
    return lastPrediction;
  });
}
