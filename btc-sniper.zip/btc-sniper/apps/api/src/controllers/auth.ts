import type { FastifyReply, FastifyRequest } from "fastify";
import { env } from "../config.js";

/**
 * Guards mutating "trading" endpoints (start/stop/mode/execute/emergency
 * stop). If DASHBOARD_API_KEY is unset (the default for local/dev use),
 * every request is allowed — this keeps `npm run dev` frictionless. Set it
 * in production so the control endpoints require `x-api-key`. This is
 * intentionally simple (a shared secret, not a full auth system) because
 * the spec calls for protecting these routes and never exposing broker
 * secrets to the frontend — it does not call for a user/session system.
 */
export function requireApiKey(request: FastifyRequest, reply: FastifyReply, done: (err?: Error) => void): void {
  if (!env.DASHBOARD_API_KEY) {
    done();
    return;
  }
  const provided = request.headers["x-api-key"];
  if (provided !== env.DASHBOARD_API_KEY) {
    reply.code(401).send({ error: "Unauthorized — missing or invalid x-api-key header." });
    return;
  }
  done();
}
