import type { BookTicker, BotMode, BotState, Direction, Prediction, Trade, TradeSignal } from "@btc-sniper/types";
import { computeIndicatorSnapshot, detectMarketStructure } from "@btc-sniper/indicators";
import { PredictionEngine } from "@btc-sniper/prediction-engine";
import { RiskManager, type TradingExecutor } from "@btc-sniper/trading-engine";
import { strategyConfig, env } from "../config.js";
import { logger } from "../logger.js";
import { wsHub } from "../websocket/hub.js";
import { createMarketDataProvider } from "../marketdata/index.js";
import { MarketDataProvider } from "../marketdata/types.js";
import { createExecutor } from "../execution/index.js";
import { getCurrentCycle } from "./cycle.js";
import * as repo from "../db/repository.js";

const TICK_MS = 1_000;
const PREDICTION_PERSIST_EVERY_N_TICKS = 5;

export class BotEngine {
  private readonly market: MarketDataProvider;
  private readonly predictionEngine = new PredictionEngine();
  private readonly riskManager: RiskManager;
  private readonly executor: TradingExecutor;

  private mode: BotMode = strategyConfig.mode;
  private status: BotState["status"] = "STOPPED";
  private tickTimer: ReturnType<typeof setInterval> | null = null;
  private tickCount = 0;

  private currentCycleId: string | null = null;
  private tradedThisCycle = 0;
  private openTrades = new Map<string, { trade: Trade; expiryTime: number }>();
  private pendingSignal: TradeSignal | null = null;
  private lastPrediction: Prediction | null = null;

  constructor() {
    this.market = createMarketDataProvider();
    this.executor = createExecutor();
    this.riskManager = new RiskManager(strategyConfig.risk, env.PAPER_INITIAL_BALANCE);
    this.wireMarketEvents();
  }

  async init(): Promise<void> {
    const state = await repo.getOrCreateBotState({ mode: this.mode, executionMode: strategyConfig.executionMode, balance: env.PAPER_INITIAL_BALANCE });
    this.mode = state.mode;
    this.riskManager.resetDaily(state.balance - state.dailyPnl);
  }

  async start(): Promise<void> {
    if (this.status === "RUNNING") return;
    await this.market.start();
    this.status = "RUNNING";
    this.tickTimer = setInterval(() => this.tick().catch((err) => logger.error("Tick failed", { error: (err as Error).message })), TICK_MS);
    await this.persistStatus();
    logger.info("BOT STATUS: RUNNING", { mode: this.mode, executionMode: strategyConfig.executionMode });
  }

  async stop(): Promise<void> {
    this.status = "STOPPED";
    if (this.tickTimer) clearInterval(this.tickTimer);
    this.tickTimer = null;
    this.market.stop();
    await this.persistStatus();
    logger.info("BOT STATUS: STOPPED");
  }

  async pause(): Promise<void> {
    if (this.status !== "RUNNING") return;
    this.status = "PAUSED";
    await this.persistStatus();
    logger.info("BOT STATUS: PAUSED");
  }

  async resumeFromPause(): Promise<void> {
    if (this.status !== "PAUSED") return;
    this.status = "RUNNING";
    await this.persistStatus();
    logger.info("BOT STATUS: RUNNING (resumed)");
  }

  async setMode(mode: BotMode): Promise<void> {
    this.mode = mode;
    await repo.updateBotState({ mode });
    logger.info("BOT MODE CHANGED", { mode });
    await this.broadcastStatus();
  }

  async emergencyStop(reason = "MANUAL EMERGENCY STOP"): Promise<void> {
    this.riskManager.emergencyStop(reason);
    this.status = "HALTED";
    await this.persistStatus(reason);
    logger.error("BOT STATUS: HALTED", { reason });
    await this.broadcastStatus();
  }

  async resumeFromHalt(): Promise<void> {
    this.riskManager.resume();
    this.status = "RUNNING";
    await this.persistStatus();
    await this.broadcastStatus();
  }

  /** Executes a pending SEMI_AUTO signal on explicit user confirmation. */
  async confirmPendingTrade(): Promise<{ ok: boolean; message: string }> {
    if (!this.pendingSignal) return { ok: false, message: "No pending signal awaiting confirmation." };
    const signal = this.pendingSignal;
    this.pendingSignal = null;
    const result = await this.attemptExecute(signal);
    return result.ok ? { ok: true, message: "Trade executed." } : { ok: false, message: result.error.message };
  }

  /**
   * Opens a trade in an operator-chosen direction right now, bypassing the
   * prediction engine's own signal (direction/entry-timing/sniper alignment)
   * and the risk manager's minimum-confidence gate — there is deliberately
   * no prediction being confident about here, it's an explicit manual
   * override, so gating it on confidence would make it impossible to ever
   * fire a test trade outside a real high-confidence signal. Every
   * capital-based risk limit still applies: kill switch, cooldown, position
   * size, max trades/hour, max consecutive losses, daily loss, and balance.
   * The configured executor is never bypassed either — this places a real
   * trade in whatever EXECUTION_MODE is currently active, same as any other
   * trade.
   */
  async placeManualTrade(direction: Direction, sizeUsdOverride?: number): Promise<{ ok: boolean; message: string }> {
    if (this.status !== "RUNNING") {
      return { ok: false, message: "Bot must be RUNNING to place a manual test trade." };
    }
    if (!this.lastPrediction) {
      return { ok: false, message: "No market data yet — wait a moment for the first tick and try again." };
    }
    const snapshot = this.market.getSnapshot();
    if (snapshot.stale || snapshot.price <= 0) {
      return { ok: false, message: "Market data is stale — refusing to place a trade." };
    }

    const cycle = getCurrentCycle(strategyConfig.cycleMs);
    const sizeUsd =
      sizeUsdOverride && sizeUsdOverride > 0
        ? Math.round(sizeUsdOverride * 100) / 100
        : this.computePositionSize(this.lastPrediction.confidence);

    const signal: TradeSignal = {
      cycleId: cycle.cycleId,
      symbol: strategyConfig.symbol,
      direction,
      confidence: this.lastPrediction.confidence,
      entryPrice: snapshot.price,
      entryTime: Date.now(),
      expiryTime: cycle.cycleEnd,
      prediction: this.lastPrediction,
      sizeUsd,
    };

    const result = await this.attemptExecute(signal, { skipConfidenceGate: true });
    if (!result.ok) return { ok: false, message: result.error.message };
    logger.info("MANUAL TEST TRADE OPENED", { direction, sizeUsd, entryPrice: snapshot.price });
    return { ok: true, message: `Manual ${direction} test trade opened at ${snapshot.price.toFixed(2)} for ${sizeUsd.toFixed(2)}.` };
  }

  getStatusSnapshot(): { botState: Pick<BotState, "mode" | "status" | "executionMode">; risk: ReturnType<RiskManager["getState"]>; lastPrediction: Prediction | null } {
    return {
      botState: { mode: this.mode, status: this.status, executionMode: strategyConfig.executionMode },
      risk: this.riskManager.getState(),
      lastPrediction: this.lastPrediction,
    };
  }

  getMarketProvider(): MarketDataProvider {
    return this.market;
  }

  // ---------------------------------------------------------------------
  // Internals
  // ---------------------------------------------------------------------

  private wireMarketEvents(): void {
    this.market.on("price", (price: number, timestamp: number) => {
      wsHub.broadcast("PRICE_UPDATE", { symbol: strategyConfig.symbol, price, timestamp });
    });
    this.market.on("candle", (interval: "1m" | "5m", candle) => {
      wsHub.broadcast("CANDLE_UPDATE", { interval, candle });
    });
    this.market.on("bookTicker", (ticker: BookTicker) => {
      wsHub.broadcast("ORDER_FLOW_UPDATE", ticker);
    });
    this.market.on("disconnected", (reason: string) => {
      logger.warn("MARKET DATA DISCONNECTED", { reason });
    });
    this.market.on("reconnecting", (attempt: number, delayMs: number) => {
      logger.warn("MARKET DATA RECONNECTING", { attempt, delayMs: Math.round(delayMs) });
    });
    this.market.on("error", (err: Error) => {
      logger.error("MARKET DATA ERROR", { error: err.message });
    });
  }

  private async tick(): Promise<void> {
    this.tickCount += 1;
    const cycle = getCurrentCycle(strategyConfig.cycleMs);
    if (this.currentCycleId !== cycle.cycleId) {
      this.currentCycleId = cycle.cycleId;
      this.tradedThisCycle = 0;
      this.pendingSignal = null;
    }

    await this.resolveExpiredTrades();

    const snapshot = this.market.getSnapshot();
    if (snapshot.stale) {
      wsHub.broadcast("MARKET_STALE", { symbol: strategyConfig.symbol, lastUpdate: snapshot.timestamp });
    }

    const indicators = computeIndicatorSnapshot(snapshot.candles5m);
    const structure = detectMarketStructure(snapshot.candles5m);

    const prediction = this.predictionEngine.generate(
      {
        symbol: strategyConfig.symbol,
        cycleId: cycle.cycleId,
        timestamp: snapshot.timestamp,
        price: snapshot.price,
        indicators,
        structure,
        tradeFlow: snapshot.tradeFlow,
        bookTicker: snapshot.bookTicker,
        candles5m: snapshot.candles5m,
        cycleRemainingMs: cycle.remainingMs,
        stale: snapshot.stale,
        riskHalted: this.riskManager.getState().halted,
      },
      strategyConfig
    );
    this.lastPrediction = prediction;

    wsHub.broadcast("INDICATOR_UPDATE", { symbol: strategyConfig.symbol, timestamp: snapshot.timestamp, indicators, structure });
    wsHub.broadcast("PREDICTION_UPDATE", prediction);
    wsHub.broadcast("VOLUME_UPDATE", snapshot.tradeFlow);

    const decision = this.evaluateTradeDecision(prediction, snapshot.price, cycle.cycleEnd);
    wsHub.broadcast("SIGNAL_UPDATE", { prediction, willTrade: decision.willTrade, blockReason: decision.blockReason });

    if (this.tickCount % PREDICTION_PERSIST_EVERY_N_TICKS === 0) {
      repo.persistPrediction(prediction).catch((err) => logger.error("Failed to persist prediction", { error: (err as Error).message }));
    }

    if (decision.signal) {
      if (this.mode === "SEMI_AUTO") {
        this.pendingSignal = decision.signal;
        logger.info("SIGNAL AWAITING CONFIRMATION (semi-automatic mode)", { direction: decision.signal.direction, confidence: decision.signal.confidence.toFixed(1) });
      } else if (this.mode === "AUTOMATIC" || this.mode === "SNIPER") {
        await this.attemptExecute(decision.signal);
      }
      // MANUAL mode: signal is broadcast/logged only, never executed.
    }
  }

  private evaluateTradeDecision(
    prediction: Prediction,
    price: number,
    cycleEnd: number
  ): { willTrade: boolean; blockReason: string | null; signal: TradeSignal | null } {
    if (this.status !== "RUNNING") return { willTrade: false, blockReason: "BOT NOT RUNNING", signal: null };
    if (this.mode === "MANUAL") return { willTrade: false, blockReason: "MANUAL MODE — SIGNAL ONLY", signal: null };
    if (prediction.signal === "NO_TRADE") return { willTrade: false, blockReason: prediction.reason, signal: null };
    if (prediction.entryStatus === "AVOID" || prediction.entryStatus === "EARLY") {
      return { willTrade: false, blockReason: `ENTRY STATUS ${prediction.entryStatus}`, signal: null };
    }
    if (this.tradedThisCycle >= strategyConfig.sniper.maxTradesPerCycle) {
      return { willTrade: false, blockReason: "MAX TRADES PER CYCLE REACHED", signal: null };
    }
    if (this.mode === "SNIPER" && !prediction.sniperReady) {
      return { willTrade: false, blockReason: `SNIPER ALIGNMENT ${prediction.sniperAligned}/6 BELOW REQUIREMENT`, signal: null };
    }

    const sizeUsd = this.computePositionSize(prediction.confidence);
    const riskCheck = this.riskManager.canOpenTrade({ confidence: prediction.confidence, sizeUsd });
    if (!riskCheck.allowed) {
      return { willTrade: false, blockReason: riskCheck.reason, signal: null };
    }

    const signal: TradeSignal = {
      cycleId: prediction.cycleId,
      symbol: strategyConfig.symbol,
      direction: prediction.signal === "BUY_UP" ? "UP" : "DOWN",
      confidence: prediction.confidence,
      entryPrice: price,
      entryTime: Date.now(),
      expiryTime: cycleEnd,
      prediction,
      sizeUsd,
    };
    return { willTrade: true, blockReason: null, signal };
  }

  private computePositionSize(confidence: number): number {
    const scaled = strategyConfig.risk.maxPositionSizeUsd * Math.min(1, confidence / 100);
    return Math.max(1, Math.round(scaled * 100) / 100);
  }

  private async attemptExecute(
    signal: TradeSignal,
    options: { skipConfidenceGate?: boolean } = {},
  ): Promise<{ ok: true } | { ok: false; error: { message: string } }> {
    const riskCheck = this.riskManager.canOpenTrade({
      confidence: signal.confidence,
      sizeUsd: signal.sizeUsd,
      skipConfidenceGate: options.skipConfidenceGate,
    });
    if (!riskCheck.allowed) {
      logger.warn("TRADE BLOCKED BY RISK MANAGER", { reason: riskCheck.reason });
      return { ok: false, error: { message: riskCheck.reason ?? "blocked" } };
    }

    const outcome = await this.executor.openTrade(signal);
    if (!outcome.ok) {
      logger.error("TRADE EXECUTION FAILED", { code: outcome.error.code, message: outcome.error.message });
      return { ok: false, error: { message: outcome.error.message } };
    }

    this.tradedThisCycle += 1;
    this.openTrades.set(outcome.trade.id, { trade: outcome.trade, expiryTime: signal.expiryTime });
    await repo.persistTrade(outcome.trade);
    const currentState = await repo.getOrCreateBotState({ mode: this.mode, executionMode: strategyConfig.executionMode, balance: env.PAPER_INITIAL_BALANCE });
    await repo.updateBotState({ totalTrades: currentState.totalTrades + 1 });
    wsHub.broadcast("TRADE_OPENED", outcome.trade);
    logger.info("SNIPER: TRIGGERED", { direction: outcome.trade.direction, confidence: outcome.trade.confidence.toFixed(1), sizeUsd: outcome.trade.sizeUsd });
    return { ok: true };
  }

  private async resolveExpiredTrades(): Promise<void> {
    const now = Date.now();
    const snapshot = this.market.getSnapshot();
    for (const [id, entry] of this.openTrades) {
      if (now < entry.expiryTime) continue;
      const outcome = await this.executor.closeTrade(id, snapshot.price);
      this.openTrades.delete(id);
      if (!outcome.ok) {
        logger.error("TRADE SETTLEMENT FAILED", { tradeId: id, code: outcome.error.code, message: outcome.error.message });
        continue;
      }

      await repo.persistTrade(outcome.trade);
      this.riskManager.recordTradeResult(outcome.trade, now);
      wsHub.broadcast("TRADE_CLOSED", outcome.trade);
      logger.info(`TRADE RESULT: ${outcome.trade.result}`, { pnl: outcome.trade.pnl?.toFixed(2), direction: outcome.trade.direction });

      await this.syncStateAfterSettlement(outcome.trade);
    }
  }

  private async syncStateAfterSettlement(trade: Trade): Promise<void> {
    const riskState = this.riskManager.getState();
    let balance = env.PAPER_INITIAL_BALANCE;
    try {
      balance = await this.executor.getBalance();
    } catch (err) {
      logger.error("Could not read executor balance", { error: (err as Error).message });
    }

    const current = await repo.getOrCreateBotState({ mode: this.mode, executionMode: strategyConfig.executionMode, balance });
    const isWin = trade.result === "WIN";
    const isLoss = trade.result === "LOSS";
    const currentStreak = isWin ? Math.max(1, current.currentStreak + 1) : isLoss ? Math.min(-1, current.currentStreak - 1) : 0;

    await repo.updateBotState({
      balance,
      dailyPnl: riskState.dailyPnl,
      wins: current.wins + (isWin ? 1 : 0),
      losses: current.losses + (isLoss ? 1 : 0),
      consecutiveLosses: riskState.consecutiveLosses,
      currentStreak,
      bestStreak: Math.max(current.bestStreak, currentStreak),
      worstStreak: Math.min(current.worstStreak, currentStreak),
    });

    if (riskState.halted) {
      this.status = "HALTED";
      await this.persistStatus(riskState.haltReason ?? undefined);
      logger.error("BOT STATUS: HALTED", { reason: riskState.haltReason });
    }

    await this.broadcastStatus();
  }

  private async persistStatus(haltReason?: string): Promise<void> {
    await repo.updateBotState({
      status: this.status,
      mode: this.mode,
      executionMode: strategyConfig.executionMode,
      haltReason: haltReason ?? null,
    });
  }

  private async broadcastStatus(): Promise<void> {
    const state = await repo.getOrCreateBotState({ mode: this.mode, executionMode: strategyConfig.executionMode, balance: env.PAPER_INITIAL_BALANCE });
    wsHub.broadcast("BOT_STATUS_UPDATE", { ...state, status: this.status, mode: this.mode });
    wsHub.broadcast("RISK_UPDATE", this.riskManager.getState());
  }
}

export const botEngine = new BotEngine();
