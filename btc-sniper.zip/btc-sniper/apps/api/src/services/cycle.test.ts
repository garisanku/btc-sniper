import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { getCurrentCycle } from "./cycle.js";

describe("getCurrentCycle", () => {
  it("aligns cycle boundaries to 5-minute wall-clock marks", () => {
    // 12:07:30 -> cycle should start at 12:05:00 and end at 12:10:00
    const t = new Date("2026-01-01T12:07:30.000Z").getTime();
    const cycle = getCurrentCycle(5 * 60_000, t);
    assert.equal(cycle.cycleStart, new Date("2026-01-01T12:05:00.000Z").getTime());
    assert.equal(cycle.cycleEnd, new Date("2026-01-01T12:10:00.000Z").getTime());
    assert.equal(cycle.elapsedMs, 2 * 60_000 + 30_000);
    assert.equal(cycle.remainingMs, 2 * 60_000 + 30_000);
  });

  it("produces a stable, unique cycleId per 5-minute window", () => {
    const t1 = new Date("2026-01-01T12:05:00.000Z").getTime();
    const t2 = new Date("2026-01-01T12:09:59.000Z").getTime();
    const t3 = new Date("2026-01-01T12:10:00.000Z").getTime();
    assert.equal(getCurrentCycle(5 * 60_000, t1).cycleId, getCurrentCycle(5 * 60_000, t2).cycleId);
    assert.notEqual(getCurrentCycle(5 * 60_000, t2).cycleId, getCurrentCycle(5 * 60_000, t3).cycleId);
  });
});
