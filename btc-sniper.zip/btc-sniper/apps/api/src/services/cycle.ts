/**
 * The 5-minute cycle clock. Cycle boundaries are derived purely from the
 * server's own clock (Date.now()), aligned to 5-minute wall-clock
 * boundaries (…:00, …:05, …:10, …) — never from the browser, and never
 * drifted by accumulating per-tick durations.
 */
export interface CycleInfo {
  cycleId: string;
  cycleStart: number;
  cycleEnd: number;
  remainingMs: number;
  elapsedMs: number;
}

export function getCurrentCycle(cycleMs: number, now = Date.now()): CycleInfo {
  const cycleStart = Math.floor(now / cycleMs) * cycleMs;
  const cycleEnd = cycleStart + cycleMs;
  return {
    cycleId: new Date(cycleStart).toISOString(),
    cycleStart,
    cycleEnd,
    remainingMs: cycleEnd - now,
    elapsedMs: now - cycleStart,
  };
}
