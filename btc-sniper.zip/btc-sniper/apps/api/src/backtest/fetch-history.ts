import type { Candle } from "@btc-sniper/types";
import { env } from "../config.js";

const MAX_LIMIT = 1000;

/** Paginates Binance's public klines REST endpoint to build a candle history for backtesting. */
export async function fetchHistoricalCandles(interval: "1m" | "5m", startTime: number, endTime: number): Promise<Candle[]> {
  const intervalMs = interval === "1m" ? 60_000 : 300_000;
  const candles: Candle[] = [];
  let cursor = startTime;

  while (cursor < endTime) {
    const url = `${env.BINANCE_REST_BASE_URL}/api/v3/klines?symbol=${env.SYMBOL}&interval=${interval}&startTime=${cursor}&endTime=${endTime}&limit=${MAX_LIMIT}`;
    const res = await fetch(url);
    if (!res.ok) throw new Error(`Binance REST klines request failed: ${res.status} ${res.statusText}`);
    const raw = (await res.json()) as Array<[number, string, string, string, string, string, number, string, number, string, string, string]>;
    if (raw.length === 0) break;

    for (const k of raw) {
      const volume = Number(k[5]);
      const takerBuy = Number(k[9]);
      candles.push({
        symbol: env.SYMBOL,
        interval,
        openTime: k[0],
        closeTime: k[6],
        open: Number(k[1]),
        high: Number(k[2]),
        low: Number(k[3]),
        close: Number(k[4]),
        volume,
        quoteVolume: Number(k[7]),
        trades: k[8],
        takerBuyBaseVolume: takerBuy,
        takerBuySellVolume: Math.max(0, volume - takerBuy),
        isClosed: true,
      });
    }

    const last = raw[raw.length - 1]!;
    cursor = last[6] + 1; // continue from the close time of the last candle received
    if (raw.length < MAX_LIMIT) break;
  }

  return candles.filter((c) => c.interval === interval).sort((a, b) => a.openTime - b.openTime);
}
