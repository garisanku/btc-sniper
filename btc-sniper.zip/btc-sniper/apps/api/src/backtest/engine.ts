import type { BacktestResult, BookTicker, Candle, StrategyConfig, Trade, TradeFlowSnapshot } from "@btc-sniper/types";
import { computeIndicatorSnapshot, detectMarketStructure } from "@btc-sniper/indicators";
import { PredictionEngine } from "@btc-sniper/prediction-engine";
import { PaperTradingExecutor } from "@btc-sniper/trading-engine";

const WARMUP_CANDLES = 60; // enough history for EMA50/RSI/MACD/Bollinger before the first decision

/**
 * Replays historical 5-minute candles through the exact same
 * PredictionEngine used live, one candle at a time, using only data up to
 * and including the candle being evaluated — the decision for "will the
 * NEXT 5-minute candle close up or down" is made using indicators computed
 * strictly from candles[0..i], and only ever checked against
 * candles[i+1].close afterwards. There is no parameter fitting here and no
 * peeking at future candles while computing indicators or the signal.
 *
 * Order-book depth isn't available from historical kline data, so the
 * book-ticker input is approximated from each candle's own taker buy/sell
 * split (a small fixed spread, bid/ask quantities proportional to that
 * candle's buy/sell volume). This is a deliberate, documented
 * approximation — real backtests with L2 order-book history would need a
 * paid historical data provider.
 */
export class BacktestEngine {
  private readonly engine = new PredictionEngine();

  async run(candles: Candle[], config: StrategyConfig, initialBalance = 10_000, payoutRatio = 0.85): Promise<BacktestResult> {
    if (candles.length < WARMUP_CANDLES + 2) {
      return emptyResult(initialBalance);
    }

    const executor = new PaperTradingExecutor({ initialBalance, payoutRatio, maxPositionSizeUsd: config.risk.maxPositionSizeUsd, strategyName: "backtest" });
    const trades: Trade[] = [];
    const balanceCurve: number[] = [initialBalance];

    for (let i = WARMUP_CANDLES; i < candles.length - 1; i++) {
      const history = candles.slice(0, i + 1); // no look-ahead: only past + current candle
      const current = history[history.length - 1]!;
      const next = candles[i + 1]!;

      const indicators = computeIndicatorSnapshot(history);
      const structure = detectMarketStructure(history);
      const tradeFlow = approximateTradeFlow(current);
      const bookTicker = approximateBookTicker(current, tradeFlow);

      const prediction = this.engine.generate(
        {
          symbol: config.symbol,
          cycleId: new Date(current.openTime).toISOString(),
          timestamp: current.closeTime,
          price: current.close,
          indicators,
          structure,
          tradeFlow,
          bookTicker,
          candles5m: history,
          cycleRemainingMs: config.cycleMs, // backtest treats each candle close as a fresh decision point
          stale: false,
        },
        config
      );

      if (prediction.signal === "NO_TRADE") continue;

      const direction = prediction.signal === "BUY_UP" ? "UP" : "DOWN";
      const sizeUsd = Math.max(1, Math.round(config.risk.maxPositionSizeUsd * Math.min(1, prediction.confidence / 100) * 100) / 100);

      const openOutcome = await executor.openTrade({
        cycleId: prediction.cycleId,
        symbol: config.symbol,
        direction,
        confidence: prediction.confidence,
        entryPrice: current.close,
        entryTime: current.closeTime,
        expiryTime: next.closeTime,
        prediction,
        sizeUsd,
      });
      if (!openOutcome.ok) continue;

      const closeOutcome = await executor.closeTrade(openOutcome.trade.id, next.close);
      if (!closeOutcome.ok) continue;

      trades.push(closeOutcome.trade);
      balanceCurve.push(balanceCurve[balanceCurve.length - 1]! + (closeOutcome.trade.pnl ?? 0));
    }

    return summarize(trades, balanceCurve, initialBalance);
  }
}

function approximateTradeFlow(candle: Candle): TradeFlowSnapshot {
  const buyVolume = candle.takerBuyBaseVolume;
  const sellVolume = candle.takerBuySellVolume;
  const total = buyVolume + sellVolume;
  return {
    symbol: candle.symbol,
    windowMs: 5 * 60_000,
    buyVolume,
    sellVolume,
    totalVolume: total,
    volumeDelta: buyVolume - sellVolume,
    buyRatio: total > 0 ? buyVolume / total : 0.5,
    tradeCount: candle.trades,
    timestamp: candle.closeTime,
  };
}

function approximateBookTicker(candle: Candle, tradeFlow: TradeFlowSnapshot): BookTicker {
  const spreadBps = 1; // a conservative, fixed approximation — real historical L1 spread isn't available
  const spread = candle.close * (spreadBps / 10_000);
  const skew = tradeFlow.buyRatio - 0.5; // -0.5..0.5, tilts quantities toward the dominant side
  return {
    symbol: candle.symbol,
    bidPrice: candle.close - spread / 2,
    bidQty: Math.max(0.01, 5 + skew * 10),
    askPrice: candle.close + spread / 2,
    askQty: Math.max(0.01, 5 - skew * 10),
    spread,
    spreadBps,
    timestamp: candle.closeTime,
  };
}

function summarize(trades: Trade[], balanceCurve: number[], initialBalance: number): BacktestResult {
  const wins = trades.filter((t) => t.result === "WIN");
  const losses = trades.filter((t) => t.result === "LOSS");
  const grossProfit = wins.reduce((s, t) => s + Math.max(0, t.pnl ?? 0), 0);
  const grossLoss = Math.abs(losses.reduce((s, t) => s + Math.min(0, t.pnl ?? 0), 0));
  const totalReturnPct = trades.length > 0 ? trades.reduce((s, t) => s + ((t.pnl ?? 0) / t.sizeUsd) * 100, 0) / trades.length : 0;

  let peak = initialBalance;
  let maxDrawdown = 0;
  for (const balance of balanceCurve) {
    peak = Math.max(peak, balance);
    const drawdown = peak > 0 ? ((peak - balance) / peak) * 100 : 0;
    maxDrawdown = Math.max(maxDrawdown, drawdown);
  }

  return {
    totalTrades: trades.length,
    wins: wins.length,
    losses: losses.length,
    winRate: trades.length > 0 ? (wins.length / trades.length) * 100 : 0,
    profitFactor: grossLoss > 0 ? grossProfit / grossLoss : grossProfit > 0 ? Number.POSITIVE_INFINITY : 0,
    maxDrawdown,
    averageConfidence: trades.length > 0 ? trades.reduce((s, t) => s + t.confidence, 0) / trades.length : 0,
    averageReturnPct: totalReturnPct,
    finalBalance: balanceCurve[balanceCurve.length - 1] ?? initialBalance,
    trades,
  };
}

function emptyResult(initialBalance: number): BacktestResult {
  return {
    totalTrades: 0,
    wins: 0,
    losses: 0,
    winRate: 0,
    profitFactor: 0,
    maxDrawdown: 0,
    averageConfidence: 0,
    averageReturnPct: 0,
    finalBalance: initialBalance,
    trades: [],
  };
}
