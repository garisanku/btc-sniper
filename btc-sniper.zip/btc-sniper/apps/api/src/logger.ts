import { EventEmitter } from "node:events";

export type LogLevel = "info" | "warn" | "error";

export interface LogEntry {
  level: LogLevel;
  message: string;
  timestamp: number;
  context?: Record<string, unknown>;
}

/**
 * A small structured logger with two outputs: a human-readable console
 * line in the `[HH:MM:SS] LABEL: value` style called for by the spec, and
 * an event stream any part of the app (the WS hub, in particular) can
 * subscribe to for pushing the same entries to the dashboard's live log
 * panel. Deliberately dependency-free — the formatting contract is small
 * enough that pulling in a full logging library wasn't worth the extra
 * unverified dependency.
 */
class Logger extends EventEmitter {
  private line(level: LogLevel, message: string, context?: Record<string, unknown>): void {
    const now = new Date();
    const ts = now.toTimeString().slice(0, 8);
    const suffix = context && Object.keys(context).length > 0 ? ` ${JSON.stringify(context)}` : "";
    const rendered = `[${ts}] ${message}${suffix}`;

    if (level === "error") console.error(rendered);
    else if (level === "warn") console.warn(rendered);
    else console.log(rendered);

    const entry: LogEntry = { level, message, timestamp: now.getTime(), context };
    this.emit("log", entry);
  }

  info(message: string, context?: Record<string, unknown>): void {
    this.line("info", message, context);
  }

  warn(message: string, context?: Record<string, unknown>): void {
    this.line("warn", message, context);
  }

  error(message: string, context?: Record<string, unknown>): void {
    this.line("error", message, context);
  }

  onLog(handler: (entry: LogEntry) => void): () => void {
    this.on("log", handler);
    return () => this.off("log", handler);
  }
}

export const logger = new Logger();
