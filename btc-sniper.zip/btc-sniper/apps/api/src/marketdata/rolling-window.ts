import type { BookTicker, Candle, TradeFlowSnapshot } from "@btc-sniper/types";
import { MAX_CANDLE_HISTORY, TRADE_FLOW_WINDOW_MS, type RawTrade } from "./types.js";

/**
 * Shared in-memory state for a symbol: candle history for both timeframes,
 * a rolling trade tape for buy/sell-volume analysis, and the latest book
 * ticker. Used by both the Binance provider and the synthetic provider so
 * they present an identical MarketSnapshot shape to the rest of the app.
 */
export class RollingWindow {
  private candles1m: Candle[] = [];
  private candles5m: Candle[] = [];
  private trades: RawTrade[] = [];
  private latestBookTicker: BookTicker | null = null;
  private latestPrice = 0;
  private lastUpdateAt = 0;

  constructor(private readonly symbol: string) {}

  upsertCandle(interval: "1m" | "5m", candle: Candle): void {
    const arr = interval === "1m" ? this.candles1m : this.candles5m;
    const last = arr[arr.length - 1];
    if (last && last.openTime === candle.openTime) {
      arr[arr.length - 1] = candle;
    } else {
      arr.push(candle);
      if (arr.length > MAX_CANDLE_HISTORY) arr.shift();
    }
    this.latestPrice = candle.close;
    this.lastUpdateAt = Date.now();
  }

  seedCandles(interval: "1m" | "5m", candles: Candle[]): void {
    const trimmed = candles.slice(-MAX_CANDLE_HISTORY);
    if (interval === "1m") this.candles1m = trimmed;
    else this.candles5m = trimmed;

    const last = trimmed[trimmed.length - 1];
    if (last) {
      this.latestPrice = last.close;
      this.lastUpdateAt = Date.now();
    }
  }

  recordTrade(trade: RawTrade): void {
    this.trades.push(trade);
    const cutoff = trade.timestamp - TRADE_FLOW_WINDOW_MS;
    while (this.trades.length > 0 && this.trades[0]!.timestamp < cutoff) this.trades.shift();
    this.latestPrice = trade.price;
    this.lastUpdateAt = Date.now();
  }

  setBookTicker(ticker: BookTicker): void {
    this.latestBookTicker = ticker;
    this.lastUpdateAt = Date.now();
  }

  getCandles1m(): Candle[] {
    return this.candles1m;
  }

  getCandles5m(): Candle[] {
    return this.candles5m;
  }

  getBookTicker(): BookTicker | null {
    return this.latestBookTicker;
  }

  getLatestPrice(): number {
    return this.latestPrice;
  }

  getLastUpdateAt(): number {
    return this.lastUpdateAt;
  }

  getTradeFlowSnapshot(now = Date.now()): TradeFlowSnapshot {
    const cutoff = now - TRADE_FLOW_WINDOW_MS;
    let buyVolume = 0;
    let sellVolume = 0;
    let tradeCount = 0;
    for (const t of this.trades) {
      if (t.timestamp < cutoff) continue;
      if (t.isBuyerMaker) sellVolume += t.qty;
      else buyVolume += t.qty;
      tradeCount++;
    }
    const totalVolume = buyVolume + sellVolume;
    return {
      symbol: this.symbol,
      windowMs: TRADE_FLOW_WINDOW_MS,
      buyVolume,
      sellVolume,
      totalVolume,
      volumeDelta: buyVolume - sellVolume,
      buyRatio: totalVolume > 0 ? buyVolume / totalVolume : 0.5,
      tradeCount,
      timestamp: now,
    };
  }
}
