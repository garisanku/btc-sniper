import WebSocket from "ws";
import type { BookTicker, Candle, MarketSnapshot } from "@btc-sniper/types";
import { logger } from "../logger.js";
import { MarketDataProvider } from "./types.js";
import { RollingWindow } from "./rolling-window.js";

export interface BinanceProviderOptions {
  symbol: string; // e.g. BTCUSDT
  wsBaseUrl: string; // wss://stream.binance.com:9443
  restBaseUrl: string; // https://api.binance.com
}

const INITIAL_BACKOFF_MS = 1_000;
const MAX_BACKOFF_MS = 30_000;

interface BinanceKlinePayload {
  e: "kline";
  s: string;
  k: {
    t: number;
    T: number;
    i: string;
    o: string;
    h: string;
    l: string;
    c: string;
    v: string;
    q: string;
    n: number;
    V: string; // taker buy base volume
    x: boolean; // is candle closed
  };
}

interface BinanceBookTickerPayload {
  u: number;
  s: string;
  b: string;
  B: string;
  a: string;
  A: string;
}

interface BinanceAggTradePayload {
  e: "aggTrade";
  s: string;
  p: string;
  q: string;
  T: number;
  m: boolean; // true = buyer is maker (i.e. a sell-initiated trade)
}

/**
 * Real Binance market-data ingestion over the public combined WebSocket
 * stream, with REST snapshot resync on (re)connect and automatic
 * reconnection with exponential backoff + jitter. This is the only place
 * in the system that talks to Binance.
 */
export class BinanceMarketDataProvider extends MarketDataProvider {
  private ws: WebSocket | null = null;
  private readonly window: RollingWindow;
  private reconnectAttempt = 0;
  private reconnectTimer: NodeJS.Timeout | null = null;
  private stopped = false;

  constructor(private readonly options: BinanceProviderOptions) {
    super();
    this.window = new RollingWindow(options.symbol);
  }

  async start(): Promise<void> {
    this.stopped = false;
    await this.resyncHistory();
    this.connect();
  }

  stop(): void {
    this.stopped = true;
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    this.ws?.close();
    this.ws = null;
  }

  getSnapshot(): MarketSnapshot {
    return {
      symbol: this.options.symbol,
      price: this.window.getLatestPrice(),
      bookTicker: this.window.getBookTicker(),
      tradeFlow: this.window.getTradeFlowSnapshot(),
      candles1m: this.window.getCandles1m(),
      candles5m: this.window.getCandles5m(),
      timestamp: Date.now(),
      stale: this.isStale(15_000),
    };
  }

  isStale(maxAgeMs: number): boolean {
    const last = this.window.getLastUpdateAt();
    if (last === 0) return true;
    return Date.now() - last > maxAgeMs;
  }

  /** Fetches recent closed candles via REST so indicators have enough history immediately on boot/reconnect. */
  private async resyncHistory(): Promise<void> {
    try {
      const [candles1m, candles5m] = await Promise.all([
        this.fetchKlines("1m", 250),
        this.fetchKlines("5m", 250),
      ]);
      this.window.seedCandles("1m", candles1m);
      this.window.seedCandles("5m", candles5m);
      logger.info("MARKET DATA RESYNCED", { symbol: this.options.symbol, candles1m: candles1m.length, candles5m: candles5m.length });
    } catch (err) {
      logger.error("Failed to resync historical candles from Binance REST API", { error: (err as Error).message });
    }
  }

  private async fetchKlines(interval: "1m" | "5m", limit: number): Promise<Candle[]> {
    const url = `${this.options.restBaseUrl}/api/v3/klines?symbol=${this.options.symbol}&interval=${interval}&limit=${limit}`;
    const res = await fetch(url);
    if (!res.ok) throw new Error(`Binance REST klines request failed: ${res.status} ${res.statusText}`);
    const raw = (await res.json()) as Array<
      [number, string, string, string, string, string, number, string, number, string, string, string]
    >;
    return raw.map((k) => klineArrayToCandle(this.options.symbol, interval, k, true));
  }

  private connect(): void {
    if (this.stopped) return;
    const symbolLower = this.options.symbol.toLowerCase();
    const streams = [`${symbolLower}@kline_1m`, `${symbolLower}@kline_5m`, `${symbolLower}@bookTicker`, `${symbolLower}@aggTrade`];
    const url = `${this.options.wsBaseUrl}/stream?streams=${streams.join("/")}`;

    logger.info("Connecting to Binance market data stream", { url });
    const ws = new WebSocket(url);
    this.ws = ws;

    ws.on("open", () => {
      this.reconnectAttempt = 0;
      logger.info("BINANCE WEBSOCKET CONNECTED", { symbol: this.options.symbol });
      this.emit("connected");
    });

    ws.on("message", (data) => {
      try {
        this.handleMessage(data.toString());
      } catch (err) {
        // Malformed/unexpected payloads must never crash the process.
        logger.error("Failed to process Binance message", { error: (err as Error).message });
      }
    });

    ws.on("ping", () => ws.pong());

    ws.on("error", (err) => {
      logger.error("Binance WebSocket error", { error: err.message });
      this.emit("error", err);
    });

    ws.on("close", (code, reason) => {
      logger.warn("BINANCE WEBSOCKET DISCONNECTED", { code, reason: reason.toString() });
      this.emit("disconnected", reason.toString());
      this.ws = null;
      if (!this.stopped) this.scheduleReconnect();
    });
  }

  private scheduleReconnect(): void {
    this.reconnectAttempt += 1;
    const backoff = Math.min(INITIAL_BACKOFF_MS * 2 ** (this.reconnectAttempt - 1), MAX_BACKOFF_MS);
    const jitter = Math.random() * 0.3 * backoff;
    const delay = backoff + jitter;

    logger.warn("RECONNECTING TO BINANCE", { attempt: this.reconnectAttempt, delayMs: Math.round(delay) });
    this.emit("reconnecting", this.reconnectAttempt, delay);

    this.reconnectTimer = setTimeout(() => {
      // Resync history before reopening the socket so any gap while
      // disconnected doesn't leave stale/missing candles behind.
      this.resyncHistory().finally(() => this.connect());
    }, delay);
  }

  private handleMessage(raw: string): void {
    const envelope = JSON.parse(raw) as { stream: string; data: unknown };
    const data = envelope.data;
    if (!data || typeof data !== "object") return;

    if ("e" in data && (data as { e: string }).e === "kline") {
      const payload = data as BinanceKlinePayload;
      const interval = payload.k.i === "1m" ? "1m" : payload.k.i === "5m" ? "5m" : null;
      if (!interval) return;
      const candle = klineToCandle(this.options.symbol, interval, payload.k);
      this.window.upsertCandle(interval, candle);
      this.emit("candle", interval, candle);
      this.emit("price", candle.close, Date.now());
      return;
    }

    if ("e" in data && (data as { e: string }).e === "aggTrade") {
      const payload = data as BinanceAggTradePayload;
      const trade = { price: Number(payload.p), qty: Number(payload.q), isBuyerMaker: payload.m, timestamp: payload.T };
      this.window.recordTrade(trade);
      this.emit("trade", trade);
      return;
    }

    if ("b" in data && "a" in data && "B" in data && "A" in data) {
      const payload = data as BinanceBookTickerPayload;
      const bidPrice = Number(payload.b);
      const askPrice = Number(payload.a);
      const spread = askPrice - bidPrice;
      const mid = (askPrice + bidPrice) / 2;
      const ticker: BookTicker = {
        symbol: this.options.symbol,
        bidPrice,
        bidQty: Number(payload.B),
        askPrice,
        askQty: Number(payload.A),
        spread,
        spreadBps: mid > 0 ? (spread / mid) * 10_000 : 0,
        timestamp: Date.now(),
      };
      this.window.setBookTicker(ticker);
      this.emit("bookTicker", ticker);
    }
  }
}

function klineToCandle(symbol: string, interval: "1m" | "5m", k: BinanceKlinePayload["k"]): Candle {
  const volume = Number(k.v);
  const takerBuyBaseVolume = Number(k.V);
  return {
    symbol,
    interval,
    openTime: k.t,
    closeTime: k.T,
    open: Number(k.o),
    high: Number(k.h),
    low: Number(k.l),
    close: Number(k.c),
    volume,
    quoteVolume: Number(k.q),
    trades: k.n,
    takerBuyBaseVolume,
    takerBuySellVolume: Math.max(0, volume - takerBuyBaseVolume),
    isClosed: k.x,
  };
}

function klineArrayToCandle(
  symbol: string,
  interval: "1m" | "5m",
  k: [number, string, string, string, string, string, number, string, number, string, string, string],
  isClosed: boolean
): Candle {
  const [openTime, open, high, low, close, volume, closeTime, quoteVolume, trades, takerBuyBaseVolume] = k;
  const vol = Number(volume);
  const takerBuy = Number(takerBuyBaseVolume);
  return {
    symbol,
    interval,
    openTime,
    closeTime,
    open: Number(open),
    high: Number(high),
    low: Number(low),
    close: Number(close),
    volume: vol,
    quoteVolume: Number(quoteVolume),
    trades,
    takerBuyBaseVolume: takerBuy,
    takerBuySellVolume: Math.max(0, vol - takerBuy),
    isClosed,
  };
}
