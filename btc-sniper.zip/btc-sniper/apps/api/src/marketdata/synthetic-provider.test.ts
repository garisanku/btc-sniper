import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { SyntheticMarketDataProvider } from "./synthetic-provider.js";

function wait(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

describe("SyntheticMarketDataProvider", () => {
  it("seeds enough candle history for indicators immediately on start", async () => {
    const provider = new SyntheticMarketDataProvider("BTCUSDT", 65_000);
    await provider.start();
    try {
      const snapshot = provider.getSnapshot();
      assert.equal(snapshot.symbol, "BTCUSDT");
      assert.ok(snapshot.candles5m.length >= 200, `expected >=200 seeded 5m candles, got ${snapshot.candles5m.length}`);
      assert.ok(snapshot.candles1m.length >= 200);
      assert.ok(snapshot.price > 0);
      assert.equal(snapshot.stale, false);

      // Every seeded candle must have internally consistent OHLC ordering.
      for (const c of snapshot.candles5m) {
        assert.ok(c.high >= c.low, "high must be >= low");
        assert.ok(c.high >= c.open && c.high >= c.close, "high must dominate open/close");
        assert.ok(c.low <= c.open && c.low <= c.close, "low must be dominated by open/close");
        assert.ok(c.volume >= 0);
        assert.ok(c.takerBuyBaseVolume >= 0 && c.takerBuyBaseVolume <= c.volume + 1e-9);
      }
    } finally {
      provider.stop();
    }
  });

  it("emits connected on start and reports stale immediately after stop", async () => {
    const provider = new SyntheticMarketDataProvider("BTCUSDT");
    let connected = false;
    provider.on("connected", () => {
      connected = true;
    });

    await provider.start();
    assert.equal(connected, true);
    assert.equal(provider.isStale(15_000), false);

    provider.stop();
    assert.equal(provider.isStale(15_000), true);
  });

  it("advances price and candle state over time via emitted trade/candle events", async () => {
    const provider = new SyntheticMarketDataProvider("BTCUSDT", 65_000);
    const trades: number[] = [];
    provider.on("trade", (t: { price: number }) => trades.push(t.price));

    await provider.start();
    try {
      await wait(600); // a couple of 250ms ticks
      assert.ok(trades.length >= 1, "expected at least one synthetic trade tick to fire");
      const snapshot = provider.getSnapshot();
      assert.ok(snapshot.price > 0);
      assert.ok(snapshot.tradeFlow.totalVolume > 0);
    } finally {
      provider.stop();
    }
  });
});
