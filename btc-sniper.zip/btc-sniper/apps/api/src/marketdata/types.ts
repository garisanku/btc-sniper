import { EventEmitter } from "node:events";
import type { BookTicker, Candle, MarketSnapshot } from "@btc-sniper/types";

export interface RawTrade {
  price: number;
  qty: number;
  isBuyerMaker: boolean; // true => aggressor was the seller (sell volume)
  timestamp: number;
}

/**
 * Every market-data source (real Binance, or the offline synthetic
 * simulator) implements this interface and emits the same events. The bot
 * engine and REST controllers only ever depend on this — never on Binance
 * or the simulator directly — so swapping providers is a one-line config
 * change (MARKET_DATA_PROVIDER=binance|synthetic).
 */
export abstract class MarketDataProvider extends EventEmitter {
  abstract start(): Promise<void>;
  abstract stop(): void;
  abstract getSnapshot(): MarketSnapshot;
  abstract isStale(maxAgeMs: number): boolean;
}

export interface MarketDataEvents {
  price: (price: number, timestamp: number) => void;
  candle: (interval: "1m" | "5m", candle: Candle) => void;
  bookTicker: (ticker: BookTicker) => void;
  trade: (trade: RawTrade) => void;
  connected: () => void;
  disconnected: (reason: string) => void;
  reconnecting: (attempt: number, delayMs: number) => void;
  error: (err: Error) => void;
}

export const MAX_CANDLE_HISTORY = 300;
export const TRADE_FLOW_WINDOW_MS = 60_000;
