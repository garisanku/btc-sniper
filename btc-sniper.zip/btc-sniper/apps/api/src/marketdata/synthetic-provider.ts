import type { BookTicker, Candle, MarketSnapshot } from "@btc-sniper/types";
import { logger } from "../logger.js";
import { MarketDataProvider } from "./types.js";
import { RollingWindow } from "./rolling-window.js";
import type { RawTrade } from "./types.js";

interface Bucket {
  openTime: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  takerBuy: number;
  trades: number;
}

const INTERVAL_MS = { "1m": 60_000, "5m": 300_000 } as const;

/**
 * A local random-walk price simulator implementing the exact same
 * MarketDataProvider interface as the real Binance feed. It exists solely
 * so the full pipeline (indicators -> prediction -> sniper -> paper
 * execution -> dashboard) can be exercised end-to-end without network
 * access to Binance — e.g. in CI, offline development, or this sandbox.
 *
 * IMPORTANT: this is a simulation. Prices are NOT real BTC prices. Every
 * price/candle/trade it emits is synthetic and must never be presented to
 * a user as live market data — the dashboard and logs both surface which
 * provider is active for exactly this reason.
 */
export class SyntheticMarketDataProvider extends MarketDataProvider {
  private readonly window: RollingWindow;
  private price: number;
  private tickTimer: ReturnType<typeof setInterval> | null = null;
  private stopped = true;
  private buckets: Record<"1m" | "5m", Bucket | null> = { "1m": null, "5m": null };

  constructor(private readonly symbol: string, seedPrice = 65_000) {
    super();
    this.window = new RollingWindow(symbol);
    this.price = seedPrice;
  }

  async start(): Promise<void> {
    this.stopped = false;
    this.seedHistory();
    this.tickTimer = setInterval(() => this.tick(), 250);
    logger.warn("SYNTHETIC MARKET DATA ACTIVE — prices are simulated, not real Binance data", { symbol: this.symbol });
    this.emit("connected");
  }

  stop(): void {
    this.stopped = true;
    if (this.tickTimer) clearInterval(this.tickTimer);
    this.tickTimer = null;
  }

  getSnapshot(): MarketSnapshot {
    return {
      symbol: this.symbol,
      price: this.window.getLatestPrice(),
      bookTicker: this.window.getBookTicker(),
      tradeFlow: this.window.getTradeFlowSnapshot(),
      candles1m: this.window.getCandles1m(),
      candles5m: this.window.getCandles5m(),
      timestamp: Date.now(),
      stale: this.isStale(15_000),
    };
  }

  isStale(maxAgeMs: number): boolean {
    if (this.stopped) return true;
    const last = this.window.getLastUpdateAt();
    if (last === 0) return true;
    return Date.now() - last > maxAgeMs;
  }

  private seedHistory(): void {
    const now = Date.now();
    this.window.seedCandles("1m", this.generateSeries("1m", 250, now));
    this.window.seedCandles("5m", this.generateSeries("5m", 250, now));
    this.pushBookTicker();
  }

  private generateSeries(interval: "1m" | "5m", count: number, now: number): Candle[] {
    const ms = INTERVAL_MS[interval];
    const candles: Candle[] = [];
    let close = this.price;
    const startTime = Math.floor(now / ms) * ms - count * ms;
    for (let i = 0; i < count; i++) {
      const openTime = startTime + i * ms;
      const open = close;
      const shock = (Math.random() - 0.5) * 0.004;
      close = Math.max(1, open * (1 + shock));
      const high = Math.max(open, close) * (1 + Math.random() * 0.0015);
      const low = Math.min(open, close) * (1 - Math.random() * 0.0015);
      const volume = 5 + Math.random() * 25;
      const takerBuy = volume * (0.3 + Math.random() * 0.4);
      candles.push({
        symbol: this.symbol,
        interval,
        openTime,
        closeTime: openTime + ms - 1,
        open,
        high,
        low,
        close,
        volume,
        quoteVolume: volume * close,
        trades: Math.round(20 + Math.random() * 200),
        takerBuyBaseVolume: takerBuy,
        takerBuySellVolume: Math.max(0, volume - takerBuy),
        isClosed: true,
      });
    }
    this.price = close;
    return candles;
  }

  private tick(): void {
    const now = Date.now();
    const shock = (Math.random() - 0.5) * 0.0006;
    this.price = Math.max(1, this.price * (1 + shock));
    const qty = 0.01 + Math.random() * 0.5;
    const isBuyerMaker = Math.random() < 0.5;
    const trade: RawTrade = { price: this.price, qty, isBuyerMaker, timestamp: now };

    this.window.recordTrade(trade);
    this.emit("trade", trade);
    this.emit("price", this.price, now);

    this.updateBucket("1m", trade);
    this.updateBucket("5m", trade);

    if (Math.random() < 0.3) this.pushBookTicker();
  }

  private updateBucket(interval: "1m" | "5m", trade: RawTrade): void {
    const ms = INTERVAL_MS[interval];
    const openTime = Math.floor(trade.timestamp / ms) * ms;
    const current = this.buckets[interval];

    if (!current || current.openTime !== openTime) {
      if (current) {
        this.window.upsertCandle(interval, bucketToCandle(this.symbol, interval, current, ms, true));
      }
      const next: Bucket = {
        openTime,
        open: trade.price,
        high: trade.price,
        low: trade.price,
        close: trade.price,
        volume: trade.qty,
        takerBuy: trade.isBuyerMaker ? 0 : trade.qty,
        trades: 1,
      };
      this.buckets[interval] = next;
      this.window.upsertCandle(interval, bucketToCandle(this.symbol, interval, next, ms, false));
      this.emit("candle", interval, bucketToCandle(this.symbol, interval, next, ms, false));
      return;
    }

    current.high = Math.max(current.high, trade.price);
    current.low = Math.min(current.low, trade.price);
    current.close = trade.price;
    current.volume += trade.qty;
    if (!trade.isBuyerMaker) current.takerBuy += trade.qty;
    current.trades += 1;

    const candle = bucketToCandle(this.symbol, interval, current, ms, false);
    this.window.upsertCandle(interval, candle);
    this.emit("candle", interval, candle);
  }

  private pushBookTicker(): void {
    const spreadBps = 0.5 + Math.random() * 2;
    const spread = this.price * (spreadBps / 10_000);
    const ticker: BookTicker = {
      symbol: this.symbol,
      bidPrice: this.price - spread / 2,
      bidQty: 1 + Math.random() * 10,
      askPrice: this.price + spread / 2,
      askQty: 1 + Math.random() * 10,
      spread,
      spreadBps,
      timestamp: Date.now(),
    };
    this.window.setBookTicker(ticker);
    this.emit("bookTicker", ticker);
  }
}

function bucketToCandle(symbol: string, interval: "1m" | "5m", bucket: Bucket, ms: number, isClosed: boolean): Candle {
  return {
    symbol,
    interval,
    openTime: bucket.openTime,
    closeTime: bucket.openTime + ms - 1,
    open: bucket.open,
    high: bucket.high,
    low: bucket.low,
    close: bucket.close,
    volume: bucket.volume,
    quoteVolume: bucket.volume * bucket.close,
    trades: bucket.trades,
    takerBuyBaseVolume: bucket.takerBuy,
    takerBuySellVolume: Math.max(0, bucket.volume - bucket.takerBuy),
    isClosed,
  };
}
