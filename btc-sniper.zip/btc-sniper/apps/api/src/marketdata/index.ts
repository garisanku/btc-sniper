import { env } from "../config.js";
import { logger } from "../logger.js";
import { MarketDataProvider } from "./types.js";
import { BinanceMarketDataProvider } from "./binance-provider.js";
import { SyntheticMarketDataProvider } from "./synthetic-provider.js";

export { MarketDataProvider } from "./types.js";
export type { RawTrade } from "./types.js";

export function createMarketDataProvider(): MarketDataProvider {
  if (env.MARKET_DATA_PROVIDER === "synthetic") {
    logger.warn("MARKET_DATA_PROVIDER=synthetic — using the local simulator, NOT real Binance data");
    return new SyntheticMarketDataProvider(env.SYMBOL);
  }
  return new BinanceMarketDataProvider({
    symbol: env.SYMBOL,
    wsBaseUrl: env.BINANCE_WS_BASE_URL,
    restBaseUrl: env.BINANCE_REST_BASE_URL,
  });
}
