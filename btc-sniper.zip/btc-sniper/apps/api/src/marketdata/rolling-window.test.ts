import { describe, it } from "node:test";
import assert from "node:assert/strict";
import type { Candle } from "@btc-sniper/types";
import { RollingWindow } from "./rolling-window.js";
import { TRADE_FLOW_WINDOW_MS } from "./types.js";

function makeCandle(openTime: number, close: number): Candle {
  return {
    symbol: "BTCUSDT",
    interval: "1m",
    openTime,
    closeTime: openTime + 59_999,
    open: close,
    high: close,
    low: close,
    close,
    volume: 10,
    quoteVolume: 10 * close,
    trades: 5,
    takerBuyBaseVolume: 5,
    takerBuySellVolume: 5,
    isClosed: true,
  };
}

describe("RollingWindow — candles", () => {
  it("appends a new candle when the open time differs, replaces when it matches (forming candle updates)", () => {
    const w = new RollingWindow("BTCUSDT");
    w.upsertCandle("1m", makeCandle(0, 100));
    w.upsertCandle("1m", makeCandle(0, 101)); // same openTime -> update in place, not a new entry
    w.upsertCandle("1m", makeCandle(60_000, 102)); // new candle

    const candles = w.getCandles1m();
    assert.equal(candles.length, 2);
    assert.equal(candles[0]!.close, 101);
    assert.equal(candles[1]!.close, 102);
  });

  it("tracks the latest price from the most recent candle or trade", () => {
    const w = new RollingWindow("BTCUSDT");
    w.upsertCandle("1m", makeCandle(0, 100));
    assert.equal(w.getLatestPrice(), 100);
    w.recordTrade({ price: 105, qty: 1, isBuyerMaker: false, timestamp: Date.now() });
    assert.equal(w.getLatestPrice(), 105);
  });
});

describe("RollingWindow — trade flow", () => {
  it("classifies buyer-is-maker trades as sell volume and the rest as buy volume", () => {
    const w = new RollingWindow("BTCUSDT");
    const now = Date.now();
    w.recordTrade({ price: 100, qty: 2, isBuyerMaker: false, timestamp: now }); // taker buy
    w.recordTrade({ price: 100, qty: 3, isBuyerMaker: true, timestamp: now }); // taker sell

    const flow = w.getTradeFlowSnapshot(now);
    assert.equal(flow.buyVolume, 2);
    assert.equal(flow.sellVolume, 3);
    assert.equal(flow.totalVolume, 5);
    assert.equal(flow.volumeDelta, -1);
    assert.ok(Math.abs(flow.buyRatio - 0.4) < 1e-9);
  });

  it("prunes trades that fall outside the rolling window", () => {
    const w = new RollingWindow("BTCUSDT");
    const now = Date.now();
    w.recordTrade({ price: 100, qty: 10, isBuyerMaker: false, timestamp: now - TRADE_FLOW_WINDOW_MS - 1_000 }); // too old
    w.recordTrade({ price: 100, qty: 4, isBuyerMaker: false, timestamp: now });

    const flow = w.getTradeFlowSnapshot(now);
    assert.equal(flow.buyVolume, 4); // the stale trade must not count
  });

  it("defaults to a neutral 0.5 buy ratio when there is no volume", () => {
    const w = new RollingWindow("BTCUSDT");
    const flow = w.getTradeFlowSnapshot();
    assert.equal(flow.buyRatio, 0.5);
    assert.equal(flow.totalVolume, 0);
  });
});
