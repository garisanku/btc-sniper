import type { TradingExecutor } from "@btc-sniper/trading-engine";
import { PaperTradingExecutor, LiveTradingExecutor } from "@btc-sniper/trading-engine";
import { env } from "../config.js";
import { logger } from "../logger.js";

export type { TradingExecutor } from "@btc-sniper/trading-engine";

/**
 * Chooses the execution backend from EXECUTION_MODE. LIVE has no broker
 * adapter wired in (see @btc-sniper/trading-engine/live-executor.ts for
 * why) — selecting it does not fabricate trades, it makes every execution
 * call fail with a clear UNSUPPORTED error until a real adapter is
 * implemented against your prediction-market's documented API.
 */
export function createExecutor(): TradingExecutor {
  if (env.EXECUTION_MODE === "LIVE") {
    logger.warn(
      "EXECUTION_MODE=LIVE but no broker adapter is configured — trade execution will fail until one is implemented. Falling back is NOT automatic: the bot will report every trade attempt as an error rather than silently paper-trading."
    );
    return new LiveTradingExecutor(null);
  }
  return new PaperTradingExecutor({
    initialBalance: env.PAPER_INITIAL_BALANCE,
    payoutRatio: env.PAPER_PAYOUT_RATIO,
    maxPositionSizeUsd: env.MAX_POSITION_SIZE_USD,
    strategyName: "sniper-v1",
  });
}
