import Fastify, { type FastifyError } from "fastify";
import cors from "@fastify/cors";
import websocketPlugin from "@fastify/websocket";
import { env } from "./config.js";
import { logger } from "./logger.js";
import { registerRoutes } from "./routes.js";
import { wsHub } from "./websocket/hub.js";
import { botEngine } from "./services/bot-engine.js";

export async function buildServer() {
  const fastify = Fastify({
    logger: false, // we use our own structured logger; see src/logger.ts
  });

  // CORS_ORIGIN accepts a comma-separated list (e.g. "http://localhost:5173,
  // http://localhost:4173") so the dashboard's Vite dev server (5173) and a
  // local production preview (4173) can both talk to this API without
  // editing .env every time you switch between them — see the
  // "CORS blocked" entry in README's Troubleshooting section.
  const corsOrigins = env.CORS_ORIGIN.split(",")
    .map((origin) => origin.trim())
    .filter(Boolean);
  await fastify.register(cors, { origin: corsOrigins, credentials: true });
  await fastify.register(websocketPlugin);

  await fastify.register(async (instance) => {
    instance.get("/ws", { websocket: true }, (connection) => {
      wsHub.addClient(connection);
      // Prime the newly-connected dashboard with current state immediately
      // rather than making it wait for the next tick.
      const snapshot = botEngine.getStatusSnapshot();
      connection.send(JSON.stringify({ type: "BOT_STATUS_UPDATE", payload: snapshot.botState }));
      if (snapshot.lastPrediction) {
        connection.send(JSON.stringify({ type: "PREDICTION_UPDATE", payload: snapshot.lastPrediction }));
      }
    });
  });

  await registerRoutes(fastify);

  // Relay every structured log entry to connected dashboards too.
  logger.onLog((entry) => wsHub.broadcast("LOG", entry));

  // Explicitly typed as FastifyError rather than relying on inference —
  // depending on the installed @types/node / TypeScript combination, the
  // generic default on setErrorHandler's callback can resolve to `unknown`
  // instead of FastifyError, which fails strict-mode builds with TS18046
  // ('error' is of type 'unknown') on `error.message` / `error.statusCode`.
  fastify.setErrorHandler((error: FastifyError, _request, reply) => {
    logger.error("Unhandled request error", { error: error.message });
    reply.status(error.statusCode ?? 500).send({ error: error.message });
  });

  return fastify;
}
