import type { WebSocket } from "ws";
import type { WsEventMap, WsEventName } from "@btc-sniper/types";
import { makeWsMessage } from "@btc-sniper/types";

/**
 * Fan-out hub for the dashboard's real-time feed. The bot engine and
 * market-data layer call `broadcast(...)` with a typed event name/payload;
 * every connected browser socket gets the same JSON message. Dead sockets
 * are pruned on send failure rather than left to accumulate.
 */
export class WebSocketHub {
  private readonly clients = new Set<WebSocket>();

  addClient(socket: WebSocket): void {
    this.clients.add(socket);
    socket.on("close", () => this.clients.delete(socket));
    socket.on("error", () => this.clients.delete(socket));
  }

  broadcast<K extends WsEventName>(type: K, payload: WsEventMap[K]): void {
    const message = JSON.stringify(makeWsMessage(type, payload));
    for (const client of this.clients) {
      if (client.readyState !== client.OPEN) {
        this.clients.delete(client);
        continue;
      }
      try {
        client.send(message);
      } catch {
        this.clients.delete(client);
      }
    }
  }

  get clientCount(): number {
    return this.clients.size;
  }
}

export const wsHub = new WebSocketHub();
