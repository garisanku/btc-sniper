import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { EventEmitter } from "node:events";
import type { WebSocket } from "ws";
import { WebSocketHub } from "./hub.js";

/**
 * A minimal stand-in for `ws`'s WebSocket satisfying only what
 * WebSocketHub actually touches (readyState/OPEN, send, on). The `ws`
 * import above is type-only and erased at build time, so this test needs
 * no real WebSocket implementation to validate the hub's connection
 * bookkeeping and broadcast/prune behavior.
 */
class FakeSocket extends EventEmitter {
  static readonly OPEN = 1;
  static readonly CLOSED = 3;
  readyState: number = FakeSocket.OPEN;
  sent: string[] = [];
  readonly OPEN = FakeSocket.OPEN;

  send(data: string): void {
    if (this.readyState !== FakeSocket.OPEN) throw new Error("socket not open");
    this.sent.push(data);
  }
}

describe("WebSocketHub", () => {
  it("broadcasts a typed event to every connected client", () => {
    const hub = new WebSocketHub();
    const a = new FakeSocket();
    const b = new FakeSocket();
    hub.addClient(a as unknown as WebSocket);
    hub.addClient(b as unknown as WebSocket);

    hub.broadcast("PRICE_UPDATE", { symbol: "BTCUSDT", price: 65000, timestamp: Date.now() });

    assert.equal(a.sent.length, 1);
    assert.equal(b.sent.length, 1);
    const parsed = JSON.parse(a.sent[0]!);
    assert.equal(parsed.type, "PRICE_UPDATE");
    assert.equal(parsed.payload.symbol, "BTCUSDT");
  });

  it("prunes a client once its socket closes", () => {
    const hub = new WebSocketHub();
    const a = new FakeSocket();
    hub.addClient(a as unknown as WebSocket);
    assert.equal(hub.clientCount, 1);

    a.emit("close");
    assert.equal(hub.clientCount, 0);

    // Broadcasting afterward must not throw even though the client is gone.
    assert.doesNotThrow(() => hub.broadcast("BOT_STATUS_UPDATE", {} as never));
  });

  it("drops a socket that is no longer open instead of throwing on send", () => {
    const hub = new WebSocketHub();
    const a = new FakeSocket();
    hub.addClient(a as unknown as WebSocket);
    a.readyState = FakeSocket.CLOSED;

    assert.doesNotThrow(() => hub.broadcast("BOT_STATUS_UPDATE", {} as never));
    assert.equal(hub.clientCount, 0);
  });
});
