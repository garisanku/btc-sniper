import { env } from "./config.js";
import { logger } from "./logger.js";
import { buildServer } from "./server.js";
import { botEngine } from "./services/bot-engine.js";

process.on("uncaughtException", (err) => {
  logger.error("UNCAUGHT EXCEPTION — bot continues running", { error: err.message, stack: err.stack });
});
process.on("unhandledRejection", (reason) => {
  logger.error("UNHANDLED REJECTION — bot continues running", { reason: reason instanceof Error ? reason.message : String(reason) });
});

async function main(): Promise<void> {
  const fastify = await buildServer();

  await fastify.listen({ port: env.PORT, host: env.HOST });
  logger.info("BTC SNIPER API LISTENING", { port: env.PORT, host: env.HOST, symbol: env.SYMBOL });
  logger.info("EXECUTION MODE", { mode: env.EXECUTION_MODE });
  if (env.EXECUTION_MODE === "PAPER") {
    logger.warn("PAPER TRADING MODE — no real funds are at risk. Set EXECUTION_MODE=LIVE only after implementing a real broker adapter.");
  }

  await botEngine.init();
  await botEngine.start();

  const shutdown = async (signal: string): Promise<void> => {
    logger.info(`Received ${signal}, shutting down gracefully`);
    await botEngine.stop();
    await fastify.close();
    process.exit(0);
  };
  process.on("SIGINT", () => void shutdown("SIGINT"));
  process.on("SIGTERM", () => void shutdown("SIGTERM"));
}

main().catch((err) => {
  logger.error("FATAL: failed to start server", { error: (err as Error).message });
  process.exit(1);
});
