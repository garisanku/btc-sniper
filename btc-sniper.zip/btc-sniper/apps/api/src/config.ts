import { fileURLToPath } from "node:url";
import path from "node:path";
import dotenv from "dotenv";
import { z } from "zod";

// Load the monorepo-root .env regardless of the process's current working
// directory (running via `npm run dev -w @btc-sniper/api` sets cwd to
// apps/api, not the repo root where .env actually lives).
const __dirname = path.dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: path.resolve(__dirname, "../../../.env") });
import type { BotMode, ExecutionMode, RiskConfig, ScoreWeights, SniperRequirements, StrategyConfig } from "@btc-sniper/types";
import { defaultStrategyConfig } from "@btc-sniper/prediction-engine";

const numeric = (fallback: number) =>
  z
    .string()
    .optional()
    .transform((v) => (v === undefined || v === "" ? fallback : Number(v)))
    .pipe(z.number());

const envSchema = z.object({
  NODE_ENV: z.enum(["development", "production", "test"]).default("development"),
  PORT: numeric(4000),
  HOST: z.string().default("0.0.0.0"),
  // Comma-separated list of allowed origins. Defaults cover both the Vite
  // dev server (5173) and a local `npm run preview` build (4173) so you
  // don't need to touch this just to compare the two.
  CORS_ORIGIN: z.string().default("http://localhost:5173,http://localhost:4173"),
  DASHBOARD_API_KEY: z.string().optional(),

  DATABASE_URL: z.string().default("file:./dev.db"),

  SYMBOL: z.string().default("BTCUSDT"),
  MARKET_DATA_PROVIDER: z.enum(["binance", "synthetic"]).default("binance"),
  BINANCE_WS_BASE_URL: z.string().default("wss://stream.binance.com:9443"),
  BINANCE_REST_BASE_URL: z.string().default("https://api.binance.com"),
  BINANCE_API_KEY: z.string().optional(),
  BINANCE_API_SECRET: z.string().optional(),

  TRADING_API_KEY: z.string().optional(),
  TRADING_API_SECRET: z.string().optional(),

  BOT_MODE: z.enum(["MANUAL", "SEMI_AUTO", "AUTOMATIC", "SNIPER"]).default("SNIPER"),
  EXECUTION_MODE: z.enum(["PAPER", "LIVE"]).default("PAPER"),

  MIN_CONFIDENCE: numeric(defaultStrategyConfig.minConfidenceToTrade),
  MAX_SPREAD_BPS: numeric(defaultStrategyConfig.maxSpreadBpsToTrade),
  EARLY_ENTRY_THRESHOLD_MS: numeric(defaultStrategyConfig.earlyEntryThresholdMs),
  LATE_ENTRY_THRESHOLD_MS: numeric(defaultStrategyConfig.lateEntryThresholdMs),
  STALE_DATA_MS: numeric(defaultStrategyConfig.staleDataMs),

  WEIGHT_TREND: numeric(defaultStrategyConfig.weights.trend),
  WEIGHT_MOMENTUM: numeric(defaultStrategyConfig.weights.momentum),
  WEIGHT_VOLUME: numeric(defaultStrategyConfig.weights.volume),
  WEIGHT_ORDER_FLOW: numeric(defaultStrategyConfig.weights.orderFlow),
  WEIGHT_PRICE_ACTION: numeric(defaultStrategyConfig.weights.priceAction),
  WEIGHT_VOLATILITY: numeric(defaultStrategyConfig.weights.volatility),

  SNIPER_MIN_CONFIDENCE: numeric(defaultStrategyConfig.sniper.minConfidence),
  SNIPER_MIN_VOLUME_RATIO: numeric(defaultStrategyConfig.sniper.minVolumeRatio),
  SNIPER_MAX_SPREAD_BPS: numeric(defaultStrategyConfig.sniper.maxSpreadBps),
  SNIPER_MIN_SIGNAL_ALIGNMENT: numeric(defaultStrategyConfig.sniper.minSignalAlignment),
  SNIPER_MAX_TRADES_PER_CYCLE: numeric(defaultStrategyConfig.sniper.maxTradesPerCycle),

  MAX_RISK_PER_TRADE: numeric(defaultStrategyConfig.risk.maxRiskPerTradePct),
  MAX_DAILY_LOSS: numeric(defaultStrategyConfig.risk.maxDailyLossPct),
  MAX_CONSECUTIVE_LOSSES: numeric(defaultStrategyConfig.risk.maxConsecutiveLosses),
  MAX_TRADES_PER_HOUR: numeric(defaultStrategyConfig.risk.maxTradesPerHour),
  COOLDOWN_AFTER_LOSS_MS: numeric(defaultStrategyConfig.risk.cooldownAfterLossMs),
  RISK_MIN_CONFIDENCE: numeric(defaultStrategyConfig.risk.minConfidence),
  MAX_POSITION_SIZE_USD: numeric(defaultStrategyConfig.risk.maxPositionSizeUsd),

  PAPER_INITIAL_BALANCE: numeric(10_000),
  PAPER_PAYOUT_RATIO: numeric(0.85),
});

const parsed = envSchema.safeParse(process.env);
if (!parsed.success) {
  // eslint-disable-next-line no-console
  console.error("Invalid environment configuration:", parsed.error.flatten().fieldErrors);
  process.exit(1);
}

export const env = parsed.data;

const weights: ScoreWeights = {
  trend: env.WEIGHT_TREND,
  momentum: env.WEIGHT_MOMENTUM,
  volume: env.WEIGHT_VOLUME,
  orderFlow: env.WEIGHT_ORDER_FLOW,
  priceAction: env.WEIGHT_PRICE_ACTION,
  volatility: env.WEIGHT_VOLATILITY,
};

const sniper: SniperRequirements = {
  minConfidence: env.SNIPER_MIN_CONFIDENCE,
  minVolumeRatio: env.SNIPER_MIN_VOLUME_RATIO,
  maxSpreadBps: env.SNIPER_MAX_SPREAD_BPS,
  minSignalAlignment: env.SNIPER_MIN_SIGNAL_ALIGNMENT,
  maxTradesPerCycle: env.SNIPER_MAX_TRADES_PER_CYCLE,
};

const risk: RiskConfig = {
  maxRiskPerTradePct: env.MAX_RISK_PER_TRADE,
  maxDailyLossPct: env.MAX_DAILY_LOSS,
  maxConsecutiveLosses: env.MAX_CONSECUTIVE_LOSSES,
  maxTradesPerHour: env.MAX_TRADES_PER_HOUR,
  cooldownAfterLossMs: env.COOLDOWN_AFTER_LOSS_MS,
  minConfidence: env.RISK_MIN_CONFIDENCE,
  maxPositionSizeUsd: env.MAX_POSITION_SIZE_USD,
};

export const strategyConfig: StrategyConfig = {
  symbol: env.SYMBOL,
  cycleMs: 5 * 60_000,
  weights,
  sniper,
  risk,
  mode: env.BOT_MODE as BotMode,
  executionMode: env.EXECUTION_MODE as ExecutionMode,
  minConfidenceToTrade: env.MIN_CONFIDENCE,
  maxSpreadBpsToTrade: env.MAX_SPREAD_BPS,
  lateEntryThresholdMs: env.LATE_ENTRY_THRESHOLD_MS,
  earlyEntryThresholdMs: env.EARLY_ENTRY_THRESHOLD_MS,
  staleDataMs: env.STALE_DATA_MS,
};

export type Env = typeof env;
