import type { Trade as PrismaTradeRow, BotState as PrismaBotStateRow } from "@prisma/client";
import type { BotMode, BotState, ExecutionMode, Prediction, Trade, TradeStats } from "@btc-sniper/types";
import { prisma } from "./prisma.js";

// ---------------------------------------------------------------------------
// Trades
// ---------------------------------------------------------------------------

export async function persistTrade(trade: Trade): Promise<void> {
  await prisma.trade.upsert({
    where: { id: trade.id },
    create: {
      id: trade.id,
      cycleId: trade.cycleId,
      symbol: trade.symbol,
      direction: trade.direction,
      entryPrice: trade.entryPrice,
      exitPrice: trade.exitPrice,
      entryTime: new Date(trade.entryTime),
      exitTime: trade.exitTime ? new Date(trade.exitTime) : null,
      confidence: trade.confidence,
      upProbability: trade.upProbability,
      downProbability: trade.downProbability,
      buyVolume: trade.buyVolume,
      sellVolume: trade.sellVolume,
      volumeDelta: trade.volumeDelta,
      signalStrength: trade.signalStrength,
      result: trade.result,
      pnl: trade.pnl,
      sizeUsd: trade.sizeUsd,
      mode: trade.mode,
      strategyName: trade.strategyName,
    },
    update: {
      exitPrice: trade.exitPrice,
      exitTime: trade.exitTime ? new Date(trade.exitTime) : null,
      result: trade.result,
      pnl: trade.pnl,
    },
  });
}

export async function listRecentTrades(limit = 100, mode?: ExecutionMode): Promise<Trade[]> {
  const rows = await prisma.trade.findMany({
    where: mode ? { mode } : undefined,
    orderBy: { createdAt: "desc" },
    take: limit,
  });
  return rows.map(rowToTrade);
}

function rowToTrade(row: PrismaTradeRow): Trade {
  return {
    id: row.id,
    cycleId: row.cycleId,
    symbol: row.symbol,
    direction: row.direction as Trade["direction"],
    entryPrice: row.entryPrice,
    exitPrice: row.exitPrice,
    entryTime: row.entryTime.getTime(),
    exitTime: row.exitTime ? row.exitTime.getTime() : null,
    confidence: row.confidence,
    upProbability: row.upProbability,
    downProbability: row.downProbability,
    buyVolume: row.buyVolume,
    sellVolume: row.sellVolume,
    volumeDelta: row.volumeDelta,
    signalStrength: row.signalStrength as Trade["signalStrength"],
    result: row.result as Trade["result"],
    pnl: row.pnl,
    sizeUsd: row.sizeUsd,
    mode: row.mode as Trade["mode"],
    strategyName: row.strategyName,
    createdAt: row.createdAt.getTime(),
  };
}

export async function computeTradeStats(mode?: ExecutionMode): Promise<TradeStats> {
  const settled = await prisma.trade.findMany({
    where: { result: { in: ["WIN", "LOSS", "PUSH"] }, ...(mode ? { mode } : {}) },
  });

  const wins = settled.filter((t) => t.result === "WIN");
  const losses = settled.filter((t) => t.result === "LOSS");
  const totalPnl = settled.reduce((sum, t) => sum + (t.pnl ?? 0), 0);
  const grossProfit = wins.reduce((sum, t) => sum + Math.max(0, t.pnl ?? 0), 0);
  const grossLoss = Math.abs(losses.reduce((sum, t) => sum + Math.min(0, t.pnl ?? 0), 0));
  const avgConfidence = settled.length > 0 ? settled.reduce((s, t) => s + t.confidence, 0) / settled.length : 0;
  const durations = settled.filter((t) => t.exitTime).map((t) => t.exitTime!.getTime() - t.entryTime.getTime());
  const avgDuration = durations.length > 0 ? durations.reduce((a, b) => a + b, 0) / durations.length : 0;

  const chronological = [...settled].sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
  let currentStreak = 0;
  let bestStreak = 0;
  let worstStreak = 0;
  let running = 0;
  for (const t of chronological) {
    if (t.result === "WIN") {
      running = running > 0 ? running + 1 : 1;
    } else if (t.result === "LOSS") {
      running = running < 0 ? running - 1 : -1;
    } else {
      running = 0;
    }
    bestStreak = Math.max(bestStreak, running);
    worstStreak = Math.min(worstStreak, running);
  }
  currentStreak = running;

  return {
    totalTrades: settled.length,
    wins: wins.length,
    losses: losses.length,
    winRate: settled.length > 0 ? (wins.length / settled.length) * 100 : 0,
    totalPnl,
    averageConfidence: avgConfidence,
    averageDurationMs: avgDuration,
    currentStreak,
    bestStreak,
    worstStreak,
    profitFactor: grossLoss > 0 ? grossProfit / grossLoss : grossProfit > 0 ? Number.POSITIVE_INFINITY : 0,
  };
}

// ---------------------------------------------------------------------------
// Predictions
// ---------------------------------------------------------------------------

export async function persistPrediction(prediction: Prediction): Promise<void> {
  await prisma.prediction.create({
    data: {
      symbol: prediction.symbol,
      timestamp: new Date(prediction.timestamp),
      upProbability: prediction.upProbability,
      downProbability: prediction.downProbability,
      confidence: prediction.confidence,
      signal: prediction.signal,
      entryStatus: prediction.entryStatus,
      price: prediction.price,
      volume: prediction.volume,
      cycleId: prediction.cycleId,
      reason: prediction.reason,
      factorsJson: JSON.stringify(prediction.factors),
    },
  });
}

// ---------------------------------------------------------------------------
// Bot state
// ---------------------------------------------------------------------------

const BOT_STATE_ID = "default";

export async function getOrCreateBotState(defaults: { mode: BotMode; executionMode: ExecutionMode; balance: number }): Promise<BotState> {
  const row = await prisma.botState.upsert({
    where: { id: BOT_STATE_ID },
    create: {
      id: BOT_STATE_ID,
      mode: defaults.mode,
      status: "STOPPED",
      executionMode: defaults.executionMode,
      balance: defaults.balance,
    },
    update: {},
  });
  return rowToBotState(row);
}

export async function updateBotState(patch: Partial<Omit<BotState, "id" | "updatedAt">>): Promise<BotState> {
  const row = await prisma.botState.update({
    where: { id: BOT_STATE_ID },
    data: {
      ...(patch.mode !== undefined ? { mode: patch.mode } : {}),
      ...(patch.status !== undefined ? { status: patch.status } : {}),
      ...(patch.executionMode !== undefined ? { executionMode: patch.executionMode } : {}),
      ...(patch.dailyPnl !== undefined ? { dailyPnl: patch.dailyPnl } : {}),
      ...(patch.totalTrades !== undefined ? { totalTrades: patch.totalTrades } : {}),
      ...(patch.wins !== undefined ? { wins: patch.wins } : {}),
      ...(patch.losses !== undefined ? { losses: patch.losses } : {}),
      ...(patch.consecutiveLosses !== undefined ? { consecutiveLosses: patch.consecutiveLosses } : {}),
      ...(patch.currentStreak !== undefined ? { currentStreak: patch.currentStreak } : {}),
      ...(patch.bestStreak !== undefined ? { bestStreak: patch.bestStreak } : {}),
      ...(patch.worstStreak !== undefined ? { worstStreak: patch.worstStreak } : {}),
      ...(patch.balance !== undefined ? { balance: patch.balance } : {}),
      ...(patch.haltReason !== undefined ? { haltReason: patch.haltReason } : {}),
    },
  });
  return rowToBotState(row);
}

function rowToBotState(row: PrismaBotStateRow): BotState {
  return {
    id: row.id,
    mode: row.mode as BotMode,
    status: row.status as BotState["status"],
    executionMode: row.executionMode as ExecutionMode,
    haltReason: row.haltReason,
    dailyPnl: row.dailyPnl,
    totalTrades: row.totalTrades,
    wins: row.wins,
    losses: row.losses,
    consecutiveLosses: row.consecutiveLosses,
    currentStreak: row.currentStreak,
    bestStreak: row.bestStreak,
    worstStreak: row.worstStreak,
    balance: row.balance,
    updatedAt: row.updatedAt.getTime(),
  };
}
