import { PrismaClient } from "@prisma/client";

/**
 * Single shared PrismaClient instance. In dev mode (tsx watch reloads the
 * module graph but not the process) we stash it on globalThis to avoid
 * exhausting SQLite's connection handles across reloads.
 */
const globalForPrisma = globalThis as unknown as { prisma?: PrismaClient };

export const prisma = globalForPrisma.prisma ?? new PrismaClient();

if (process.env.NODE_ENV !== "production") {
  globalForPrisma.prisma = prisma;
}
