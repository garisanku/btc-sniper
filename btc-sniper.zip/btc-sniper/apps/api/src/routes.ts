import type { FastifyInstance } from "fastify";
import { marketController } from "./controllers/market.js";
import { predictionController } from "./controllers/prediction.js";
import { tradesController } from "./controllers/trades.js";
import { botController } from "./controllers/bot.js";
import { backtestController } from "./controllers/backtest.js";

export async function registerRoutes(fastify: FastifyInstance): Promise<void> {
  await fastify.register(marketController);
  await fastify.register(predictionController);
  await fastify.register(tradesController);
  await fastify.register(botController);
  await fastify.register(backtestController);

  fastify.get("/api/health", async () => ({ ok: true, timestamp: Date.now() }));
}
