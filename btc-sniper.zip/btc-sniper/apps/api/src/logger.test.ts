import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { logger } from "./logger.js";

describe("logger", () => {
  it("emits a structured log entry for every info/warn/error call", () => {
    const received: Array<{ level: string; message: string }> = [];
    const unsubscribe = logger.onLog((entry) => received.push(entry));

    logger.info("BTC PRICE", { price: 112450 });
    logger.warn("BUY VOLUME", { pct: 64 });
    logger.error("MARKET DATA ERROR", { reason: "timeout" });

    unsubscribe();

    assert.equal(received.length, 3);
    assert.equal(received[0]!.level, "info");
    assert.equal(received[0]!.message, "BTC PRICE");
    assert.equal(received[1]!.level, "warn");
    assert.equal(received[2]!.level, "error");
  });

  it("stops delivering events after unsubscribe", () => {
    const received: unknown[] = [];
    const unsubscribe = logger.onLog((entry) => received.push(entry));
    unsubscribe();
    logger.info("should not be received");
    assert.equal(received.length, 0);
  });
});
