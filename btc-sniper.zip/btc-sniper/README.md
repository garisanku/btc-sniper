# BTC Sniper — 5-Minute Up/Down Prediction Terminal

A full-stack TypeScript system that continuously analyzes BTC/USDT market data, scores the likely direction of the *next* 5-minute period using a configurable multi-factor model, times entries within that 5-minute window, and (in paper-trading mode by default) simulates trade execution with real risk management — all surfaced on a real-time dark-themed trading dashboard.

**This is a probabilistic signal/paper-trading system, not a guaranteed-profit machine.** See [Safety & risk warnings](#safety--risk-warnings).

---

## 1. Architecture

```
btc-sniper/
├── apps/
│   ├── web/     React + TypeScript + Vite + Tailwind dashboard (lightweight-charts, WebSocket live feed)
│   └── api/     Fastify + TypeScript backend (Binance ingestion, prediction loop, risk, REST + WS, Prisma/SQLite)
├── packages/
│   ├── types/               Shared TypeScript types/contracts used by every package and app
│   ├── indicators/          Pure-function technical indicators (EMA, RSI, MACD, ATR, Bollinger, StochRSI, ROC, VWAP, structure)
│   ├── prediction-engine/   Multi-factor weighted scoring engine, smart entry timing, sniper alignment checks
│   └── trading-engine/      TradingExecutor abstraction (paper + live), RiskManager
├── prisma/schema.prisma     Trade / Prediction / BotState models (SQLite)
├── Dockerfile, docker-compose.yml
└── .env.example
```

**Separation of concerns** (this is deliberate, not incidental):
- **Market data** (`apps/api/src/marketdata`) only ever produces a `MarketSnapshot`. It knows nothing about predictions or trading.
- **Prediction** (`packages/prediction-engine`) only ever turns a snapshot + indicators into a `Prediction`. It knows nothing about execution.
- **Execution** (`packages/trading-engine`) only ever turns a `TradeSignal` into a `Trade` via the `TradingExecutor` interface. It knows nothing about how the signal was derived.
- **Risk** (`RiskManager`) is consulted before every execution and after every settlement, independent of everything else — it can halt the whole system on its own.

This means swapping the market-data source, the scoring model, or the broker is a localized change, not a rewrite.

---

## 2. Installation

Requires **Node.js ≥ 20** and npm.

```bash
git clone <this-repo>
cd btc-sniper
cp .env.example .env
cp apps/web/.env.example apps/web/.env
npm install
npm run db:generate
npm run db:migrate
```

`npm install` installs all workspaces (`packages/*` and `apps/*`) from the root — this is an npm workspaces monorepo, so there is exactly one `npm install` for the whole project, not one per package. A `postinstall` hook then runs `npm run build:packages`, compiling `packages/types`, `packages/indicators`, `packages/prediction-engine`, and `packages/trading-engine` to `dist/` — both `apps/api` and `apps/web` import these as regular packages (`@btc-sniper/indicators`, etc.), resolved via their `main`/`exports` fields, which point at that compiled output, not at `src/`. `npm run dev` and `npm run build` also run `build:packages` first as a safety net, so this never has to be a manually-remembered step.

## 3. Running

**Development** (backend with hot-reload via `tsx watch`, frontend via Vite dev server, both concurrently):

```bash
npm run dev
```

- API: http://localhost:4000 (REST + WebSocket at `/ws`)
- Dashboard: http://localhost:5173

Or run them separately: `npm run dev:api` / `npm run dev:web`.

If you edit a file inside `packages/*` (e.g. add an indicator), its `dist/` output is stale until the next `npm run dev`/`build:packages` run — there's no package-level watch mode, so restart `npm run dev` (or run `npm run build:packages` manually) to pick up the change.

**Production build + start:**

```bash
npm run build
npm run start          # starts the API (apps/api/dist/index.js)
npm run preview -w @btc-sniper/web   # serves the built dashboard on :4173
```

**Docker:**

```bash
docker compose up -d --build
```

This builds and runs both the API (`:4000`) and the static dashboard (`:4173`) from the single root `Dockerfile` (multi-stage, `api` and `web` targets), runs Prisma migrations on container start, and persists the SQLite database in a named volume.

**Run tests:**

```bash
npm test
```

Runs the indicator, prediction-engine, trading-engine, and API test suites (Node's built-in test runner, via `tsx --test`).

---

## 4. Environment variables

See [`.env.example`](./.env.example) for the full, commented list. Highlights:

| Variable | Purpose |
|---|---|
| `MARKET_DATA_PROVIDER` | `binance` (real live data) or `synthetic` (built-in offline simulator — see below) |
| `BOT_MODE` | `MANUAL` \| `SEMI_AUTO` \| `AUTOMATIC` \| `SNIPER` |
| `EXECUTION_MODE` | `PAPER` (default, simulated) or `LIVE` (requires a real broker adapter — see [Live trading](#7-live-trading)) |
| `MIN_CONFIDENCE`, `MAX_SPREAD_BPS`, `*_ENTRY_THRESHOLD_MS`, `STALE_DATA_MS` | Entry-timing and data-quality gates |
| `WEIGHT_TREND` … `WEIGHT_VOLATILITY` | Prediction score weights (auto-normalized to sum to 1 — **never hard-coded**, see `packages/prediction-engine/src/default-config.ts`) |
| `SNIPER_MIN_CONFIDENCE`, `SNIPER_MIN_VOLUME_RATIO`, `SNIPER_MAX_SPREAD_BPS`, `SNIPER_MIN_SIGNAL_ALIGNMENT`, `SNIPER_MAX_TRADES_PER_CYCLE` | Sniper Mode requirements |
| `MAX_RISK_PER_TRADE`, `MAX_DAILY_LOSS`, `MAX_CONSECUTIVE_LOSSES`, `MAX_TRADES_PER_HOUR`, `COOLDOWN_AFTER_LOSS_MS`, `MAX_POSITION_SIZE_USD` | Risk management limits |
| `PAPER_INITIAL_BALANCE`, `PAPER_PAYOUT_RATIO` | Paper-trading simulation parameters (binary-market payout model) |
| `DASHBOARD_API_KEY` | Shared secret required on mutating endpoints (start/stop/mode/execute/emergency-stop) when set. Empty by default for local dev. |
| `BINANCE_API_KEY/SECRET`, `TRADING_API_KEY/SECRET` | Never sent to the frontend; read only server-side. The public Binance market-data streams used here need no key at all. |

**Never** put secrets in `apps/web/.env` — only `VITE_API_URL`/`VITE_WS_URL` belong there, and Vite bakes them into the client bundle at build time (they are not secrets).

---

## 5. Binance integration

`apps/api/src/marketdata/binance-provider.ts` connects to Binance's public **combined WebSocket stream** (`btcusdt@kline_1m`, `@kline_5m`, `@bookTicker`, `@aggTrade`) and seeds indicator history via the public REST klines endpoint on (re)connect. No API key is required for any of this — it's all public market data.

**Reconnection:** on any close/error, the provider backs off exponentially (1s → 2s → 4s … capped at 30s, with jitter), re-fetches REST history to close any gap, and reopens the socket — the bot loop keeps running throughout (predictions simply gate to `NO_TRADE — MARKET DATA STALE` if the feed has been down long enough).

### Offline / synthetic mode

Set `MARKET_DATA_PROVIDER=synthetic` to run the entire system (prediction engine, sniper mode, paper trading, dashboard) against a local random-walk price simulator instead of Binance — useful for demos, CI, or any environment without outbound network access to Binance (this is how the system was exercised end-to-end during development in a network-restricted sandbox; see [Limitations](#9-known-limitations)). The dashboard and logs both clearly flag when synthetic data is active; it is never silently substituted.

---

## 6. Paper trading (default)

`EXECUTION_MODE=PAPER` (the default) uses `PaperTradingExecutor`, which simulates a **binary 5-minute market**: a win pays `stake × PAPER_PAYOUT_RATIO` profit, a loss forfeits the stake, and an exact-tie settlement price is a push (stake returned). This is never connected to any real money or exchange — it's an in-memory simulation, seeded with `PAPER_INITIAL_BALANCE`.

## 7. Live trading

`EXECUTION_MODE=LIVE` selects `LiveTradingExecutor`. **Out of the box this has no working broker connected.** The task of "automated trading on a 5-minute BTC prediction market" doesn't name a single, universal, documented trading API — those APIs vary by venue — so this system ships the clean adapter boundary (`LiveBrokerAdapter` in `packages/trading-engine/src/live-executor.ts`) and *does not fabricate a working integration against an unspecified API*. Every execution call fails loudly with `UNSUPPORTED` until you implement a real adapter against your specific broker/prediction-market's documented API and pass it into `LiveTradingExecutor`. This is intentional: the alternative would be either a fake integration or silently falling back to paper trading, both of which the spec explicitly rules out ("never fake successful execution").

## 8. Bot modes

| Mode | Behavior |
|---|---|
| `MANUAL` | Generates and broadcasts predictions/signals only. Never executes. |
| `SEMI_AUTO` | Generates a signal and holds it as "pending" — the dashboard operator confirms via `POST /api/trade/execute` before it executes. |
| `AUTOMATIC` | Executes any signal that clears the confidence/entry-timing/risk gates. |
| `SNIPER` | Only executes when `sniperReady` is true — confidence, volume ratio, spread, **and** a minimum count of the 6 factor-alignment checks (trend/momentum/volume/order-flow/price-action/volatility) all pass simultaneously. |

**Manual test trade** — regardless of mode, the dashboard's "Manual Test Trade" panel opens a trade immediately in whichever direction you click (`POST /api/trade/manual`, body `{ direction: "UP" | "DOWN", sizeUsd?: number }`), bypassing both the prediction engine's own signal and the risk manager's minimum-confidence gate (there's no prediction to be confident about in a manual override). Every capital-based risk limit still applies and can still block it — kill switch, cooldown, max trades/hour, max consecutive losses, daily loss, balance — and it goes through the same executor as every other trade, so it places a **real** order whenever `EXECUTION_MODE=LIVE`, exactly like an automatic trade would (the panel shows a warning badge when that's the case).

## 9. Strategy configuration

Every weight and threshold lives in `.env` (see above) and is loaded once into a single `StrategyConfig` object (`apps/api/src/config.ts`) — nothing in `packages/prediction-engine` hard-codes a weight or threshold. Weights are auto-normalized to sum to 1 regardless of what you set them to.

## 10. Backtesting

`POST /api/backtest/run { "days": 7 }` fetches that many days of real historical 5-minute candles from Binance's REST API and replays them through the **exact same** `PredictionEngine` used live — one candle at a time, using only data up to and including the candle being evaluated (no look-ahead). The result for candle *i* is checked only against candle *i+1*'s close, after the decision for *i* has already been made. Order-book depth isn't available from historical klines, so the book-ticker input is approximated from each candle's own taker buy/sell split — this is a documented approximation, not real historical L1 data. See `apps/api/src/backtest/engine.ts` for the exact method.

## 11. Database

SQLite via Prisma (`prisma/schema.prisma`): `Trade`, `Prediction`, `BotState`. Direction/result/mode/status fields are validated strings rather than native enums (SQLite has no enum type). Run `npm run db:studio -w @btc-sniper/api` to browse the data.

## 12. WebSocket architecture

The backend is the single source of truth; the frontend never polls. `apps/api/src/websocket/hub.ts` fans out typed events (`PRICE_UPDATE`, `CANDLE_UPDATE`, `VOLUME_UPDATE`, `ORDER_FLOW_UPDATE`, `INDICATOR_UPDATE`, `PREDICTION_UPDATE`, `SIGNAL_UPDATE`, `TRADE_OPENED`, `TRADE_CLOSED`, `BOT_STATUS_UPDATE`, `RISK_UPDATE`, `LOG`, `MARKET_STALE`) to every connected dashboard over one `/ws` endpoint. The dashboard (`apps/web/src/services/ws.ts`) reconnects with the same exponential-backoff pattern as the Binance client.

## 13. Deployment

- `npm run build` / `npm run start` for a bare-metal Node deployment.
- `docker compose up -d --build` for containers (see [Docker build networking](#docker-build-networking) below if your build environment has restricted network access).
- **Hosting it 24/7, for free, without keeping your own machine on** — see below.

### Running this live without your computer on, for $0/mo

GitHub only stores the code; it doesn't run anything. This project is a long-running process — it holds an open Binance WebSocket connection and an in-memory 5-minute prediction cycle that must keep running whether or not anyone is looking at the dashboard, and it writes to a SQLite file that must persist across restarts. That rules out every serverless/edge "free tier" (Vercel, Netlify, Cloudflare Workers — no function kept warm indefinitely, no persistent local disk) and it also rules out the typical *free* container platforms: Render's free web services spin down after 15 minutes idle, and Fly.io no longer has a free tier at all as of 2026.

The one kind of thing that's both genuinely free *and* actually stays on: the **Always Free tier of a real cloud VM** — Oracle Cloud and Google Cloud both give you an actual small Linux server, forever, at no cost, no trial period to run out. You SSH into it once to set it up, then `git pull && docker compose up -d --build` is the entire redeploy story from then on (and the included GitHub Actions workflow does even that for you).

- **Oracle Cloud "Always Free"** (recommended — more headroom): an Ampere A1 (ARM) VM with 2 OCPU / 12 GB RAM and 200 GB disk, or two AMD micro VMs, forever, as long as you stay within that allowance. Sign-up asks for a card for identity verification but Always Free resources aren't billed; the well-known catch is that the popular regions/shapes sometimes show "out of capacity" during signup — if that happens, try a different Availability Domain or region, or fall back to the option below. [oracle.com/cloud/free](https://www.oracle.com/cloud/free/)
- **Google Cloud "Always Free" e2-micro**: one small VM (1 shared vCPU, 1 GB RAM, 30 GB disk) forever, in `us-west1`/`us-central1`/`us-east1` only (any other region bills normally). Tighter on RAM, but this app is light enough to run on it. [cloud.google.com free tier docs](https://cloud.google.com/free)

Either way you end up with: a public IP, root/sudo access, and Docker. From there the setup is identical.

#### 1. Push to GitHub

```bash
cd btc-sniper
git init
git add .
git commit -m "Initial commit"
gh repo create btc-sniper --private --source=. --push
# or, without the gh CLI: create the repo on github.com, then
#   git remote add origin git@github.com:<you>/btc-sniper.git
#   git branch -M main && git push -u origin main
```

`.gitignore` already excludes `.env`, `node_modules`, `dist`, and the local `.db` files, so nothing sensitive or generated gets committed.

#### 2. Create the VM and open its firewall

Create the instance (Ubuntu is the simplest image choice on either provider), note its **public IP**, and open ports **22, 80, and 443** in the cloud provider's own firewall/security-list UI (Oracle calls this a Security List on the VM's subnet; Google calls it a Firewall rule). This step is easy to think you've done when you've only done half of it — see the gotcha at the end of step 4.

SSH in and install Docker:

```bash
ssh <user>@<vm-public-ip>
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER && newgrp docker
```

#### 3. Clone the repo and configure it

```bash
git clone https://github.com/<you>/btc-sniper.git
cd btc-sniper
cp .env.example .env
```

Edit `.env` and set:

```bash
# A free hostname that resolves to THIS VM's public IP with no signup and
# no domain purchase — replace the dashes with your actual IP's octets.
SITE_ADDRESS=203-0-113-10.sslip.io

# Vite inlines these into the frontend at build time, so they must be the
# real public https URL, not localhost — and must be set *before* the
# first `docker compose up --build` (changing .env alone doesn't rebuild).
VITE_API_URL=https://203-0-113-10.sslip.io
VITE_WS_URL=wss://203-0-113-10.sslip.io/ws

DASHBOARD_API_KEY=<a random string — this dashboard is now on the open internet>
```

(`sslip.io` is a free wildcard DNS service — `203-0-113-10.sslip.io` automatically resolves to `203.0.113.10` for anyone, with zero signup. It exists specifically so a bare cloud VM can get a real, publicly-resolvable hostname — which is what Caddy needs to request a real HTTPS certificate for it — without you owning a domain.)

#### 4. Bring it up

```bash
docker compose up -d --build
```

This builds and starts three containers: `api` and `web` (bound to `127.0.0.1` only — not directly reachable from outside the VM), and `caddy` (bound to `0.0.0.0:80`/`:443`, the only thing actually facing the internet), which reverse-proxies `/api/*` and `/ws` to `api` and everything else to `web` under your `SITE_ADDRESS`. Caddy requests and auto-renews its own Let's Encrypt certificate the first time it starts — check `docker compose logs -f caddy` if `https://<your-site-address>` doesn't come up within a minute or two.

**The gotcha almost everyone hits here**: opening 80/443 in the cloud provider's firewall (step 2) is necessary but often not sufficient — many stock VM images (Oracle's Ubuntu image in particular) also ship with the *OS's own* firewall blocking those ports. If the site still doesn't load after Caddy's logs look healthy, check and open the OS firewall too:

```bash
sudo iptables -I INPUT -p tcp --dport 80 -j ACCEPT
sudo iptables -I INPUT -p tcp --dport 443 -j ACCEPT
sudo netfilter-persistent save 2>/dev/null || true   # persist across reboots, if installed
# or, if the VM uses ufw instead:
sudo ufw allow 80,443/tcp
```

Because Caddy serves the dashboard and proxies the API under the exact same hostname, the browser sees one same-origin app — `CORS_ORIGIN` doesn't come into play for this deployment shape at all (it still matters for local dev; see `.env.example`).

#### 5. Keep it auto-deploying on every push

This repo includes `.github/workflows/vps-deploy.yml`, which SSHes into your VM and re-runs `git pull && docker compose up -d --build` on every push to `main`. Add three secrets in the GitHub repo's **Settings → Secrets and variables → Actions**:

```
VPS_HOST      = your VM's public IP
VPS_USER      = the SSH user you used in step 2
VPS_SSH_KEY   = the private half of a keypair whose public half is in
                that user's ~/.ssh/authorized_keys on the VM
```

From here, `git push` redeploys the live bot on its own — no computer needs to stay on, and it's not costing you anything either.

The same three secrets also power `.github/workflows/vps-diagnose.yml` — a manually-triggered, read-only workflow (repo's **Actions** tab → "Diagnose VPS" → **Run workflow**) that SSHes in and prints `docker compose ps`, the relevant `.env` values, and recent `api`/`caddy` logs right into the Actions run output. Useful for checking on the VM (e.g. confirming a real HTTPS certificate was issued) from anywhere you can open the GitHub website, including a phone, without an SSH app.

### Using Netlify (or Vercel) for the dashboard instead of Caddy's copy

The steps above serve the dashboard from the VM itself (via the `web` + `caddy` containers), but there's nothing wrong with hosting it on Netlify or Vercel instead if you'd rather — both are genuinely free for a static site like this one and give you their own auto-deploy-on-push. **The one thing that's easy to miss: the API/bot itself still has to be deployed to the VM (steps 2-4 above) — Netlify and Vercel are both static/serverless hosts and can't run it, for the exact same reason Fly.io's free tier and Render's free tier can't (see the top of this section).** A frontend-only deploy will load, but every fetch it makes will fail, because `VITE_API_URL`/`VITE_WS_URL` default to `http://localhost:4000` — which, once the page is live on the public internet, means "whatever's running on each visitor's own machine," not your server. Modern browsers actively block a public HTTPS page from reaching into `localhost`/a private network anyway, so this fails loudly (CORS errors, `blocked ... loopback address space`) rather than silently.

To wire a Netlify/Vercel-hosted frontend up to the VM's API:

1. Get the VM's public URL from step 3 (`https://<your-site-address>`).
2. In Netlify: **Site configuration → Environment variables** → add `VITE_API_URL=https://<your-site-address>` and `VITE_WS_URL=wss://<your-site-address>/ws` → **Deploys → Trigger deploy** (env var changes never apply to a build that already ran — Vite bakes them in at build time). This repo's committed `netlify.toml` handles the install/build/publish commands if the site is connected via Git; on Vercel the equivalent is `vercel.json`, already included.
3. On the VM, add the frontend's URL to `CORS_ORIGIN` in `.env` and restart: `CORS_ORIGIN=https://<your-site-address>,https://<your-netlify-site>.netlify.app` (use your site's permanent `https://<name>.netlify.app` URL, not a per-deploy preview URL like `https://<hash>--<name>.netlify.app` — those change on every deploy).

### Alternative: managed platforms (no VM to maintain, but not free)

If you'd rather not manage a VM yourself, `fly.toml` and `vercel.json` are also included in this repo for a **Fly.io (API + bot) + Vercel (dashboard)** split deployment — Vercel's free tier is still genuinely free, but Fly.io's free tier is gone as of 2026, so this path costs a few dollars a month. See the git history of this README (or ask) for the full walkthrough if you'd rather go this route; the short version is the same shape as above — push to GitHub, `fly deploy` the API with a persistent volume, import the repo into Vercel with `VITE_API_URL`/`VITE_WS_URL` pointing at the Fly app, then set `CORS_ORIGIN` on Fly to the Vercel URL (this split needs real CORS config, since the two halves are on different origins).

**Before setting `EXECUTION_MODE=LIVE` anywhere in this pipeline** — VM `.env`, Fly secrets, Vercel env vars, or otherwise — re-read [§7 Live trading](#7-live-trading) and [Safety & risk warnings](#safety--risk-warnings) below; the defaults above (`EXECUTION_MODE=PAPER`, no `TRADING_API_KEY`/`SECRET` set) mean nothing here risks real funds until you deliberately change that.

## 14. Troubleshooting

- **"No prediction available yet"** — the engine needs enough 5-minute candle history (EMA50/Bollinger/ATR all need ≥ 20–50 candles). On boot against real Binance this backfills instantly via REST; the synthetic provider seeds 250 candles immediately.
- **Binance WebSocket won't connect** — check outbound network access to `stream.binance.com:9443` and `api.binance.com`; some sandboxed/corporate networks block this. Fall back to `MARKET_DATA_PROVIDER=synthetic` to keep developing against the rest of the system.
- **Prisma errors on a fresh clone** — run `npm run db:generate` then `npm run db:migrate`.
- **`P1012: Environment variable not found: DATABASE_URL`** when running `npm run db:generate` / `npm run db:migrate` locally — the root `.env` doesn't exist yet. All four `db:*` scripts in `apps/api/package.json` run through a small wrapper (`node scripts/with-env.mjs prisma ...`) specifically because the Prisma CLI does its own environment loading, independent of `src/config.ts`, and doesn't reliably find a root-level `.env` when the schema lives at a custom path (`prisma.schema` in `apps/api/package.json` points at `../../prisma/schema.prisma`) and the npm workspace script's cwd is `apps/api`. The wrapper only *warns* (doesn't fail) when `.env` is missing — `DATABASE_URL` might legitimately come from elsewhere (a Docker `ENV`, a CI secret) — so if you see this locally, the fix is: `cp .env.example .env` in the project root.
- **Docker build fails on `npm run db:generate` with the same `P1012`** — this is different from the local case above: `.dockerignore` deliberately excludes `.env` from the build context (an image layer is not where secrets belong), so there is never a root `.env` inside the container. `Dockerfile`'s `build` stage instead sets a placeholder `ARG DATABASE_URL=file:./dev.db` before running `db:generate`, since `prisma generate` only needs *some* validly-formatted value to pass schema validation — it generates client code from `schema.prisma` and never actually connects to a database for that step. If you still see `P1012` in a Docker build, something removed or overrode that `ARG`/`ENV` pair in the `build` stage; the real, connectable `DATABASE_URL` used once the container is actually running comes from `docker-compose.yml`'s `environment:` block, pointing at the `sniper-data` volume — that's unrelated to this build-time placeholder.
- **401 on start/stop/mode endpoints** — you've set `DASHBOARD_API_KEY`; enter the same value in the dashboard's "API key" field (top right) or pass `x-api-key` yourself.
- **`[plugin:vite:import-analysis] Failed to resolve entry for package "@btc-sniper/indicators"`** (or `types`/`prediction-engine`/`trading-engine`) — these packages ship compiled output, not raw TypeScript: their `package.json` `main`/`exports` point at `dist/index.js`, produced by `tsc -b`, which is never checked into the repo. A `postinstall` hook runs `npm run build:packages` once after `npm install`, and `apps/web`'s and `apps/api`'s own `dev`/`build` scripts now also rebuild the four shared packages before doing anything else — this applies whether you run them from the repo root (`npm run dev`) or directly inside `apps/web`/`apps/api` (`cd apps/web && npm run dev`), so the two are never out of sync. If you still see this, an `npm install` was probably interrupted before `postinstall` finished — fix: from the repo root, run `npm run build:packages`, then retry.
- **EMA/Bollinger/RSI/MACD show blank on a local production preview (`npm run build && npm run preview`, port 4173) while `npm run dev` (port 5173) draws them fine, and the browser console shows `blocked by CORS policy` for `/api/market/candles`, `/api/stats`, etc.** — the API's `CORS_ORIGIN` only allowed one origin (defaulting to `http://localhost:5173`), so once the dashboard was loaded from `http://localhost:4173` instead, the browser blocked every REST call the API made (the WebSocket connection isn't subject to CORS the same way, so it kept trickling in live candles one at a time — which is why candles/volume eventually show *something*, while EMA/Bollinger/RSI/MACD stay blank: those all need the REST-backed historical backfill to have enough periods of history, e.g. 20+ for Bollinger, 35+ for MACD, and waiting for that many live 5-minute candles to trickle in one by one takes hours). `CORS_ORIGIN` now accepts a comma-separated list and defaults to `http://localhost:5173,http://localhost:4173` so both are allowed out of the box — but a default only applies when the variable is unset entirely, so if you already have a `.env` with `CORS_ORIGIN=http://localhost:5173` in it, add the second origin yourself: `CORS_ORIGIN=http://localhost:5173,http://localhost:4173`, then restart the API.
- **Deployed the dashboard (Netlify/Vercel/etc.) and it loads, but nothing shows and the console says `blocked by CORS policy` for requests to `http://localhost:4000`, or `Permission was denied for this request to access the 'loopback' address space`** — this means the frontend was built with the *default* `VITE_API_URL`/`VITE_WS_URL` (`http://localhost:4000`), which only ever means "whatever's running on the visitor's own machine." Deploying the frontend does not deploy the bot — the API/bot (`apps/api`) is a separate, long-running process that has to be deployed on its own (see "Free 24/7 hosting" above) before the frontend has anything real to talk to. Once it's deployed and you have its public `https://` URL, set `VITE_API_URL`/`VITE_WS_URL` to that URL in your static host's environment variables and trigger a fresh deploy (see "Using Netlify (or Vercel) for the dashboard" above) — env var changes never apply retroactively to a build that already ran.
- **Docker build fails with `TS2307: Cannot find module '@btc-sniper/types'`** (or `@btc-sniper/indicators`) inside `apps/web`, often alongside cascading `TS7006` implicit-`any` errors on unrelated `.map()` calls — those are downstream symptoms, not separate bugs: once TypeScript can't resolve the import, everything derived from it types as `any` until some callback loses an inferable signature. If this happens on a machine where the same source has built successfully before, it's almost always a stale Docker layer cache left over from an earlier, broken build — rebuild with `docker compose build --no-cache` (or `docker builder prune` to clear the cache entirely) before assuming the source is wrong.
- **Docker build: one app's build failure blocks the *other* app's image too** (e.g. the log shows something like `[api build 5/5] RUN npm run build -w @btc-sniper/web` right before `target api: failed to solve`) — this was a real structural bug in `Dockerfile`: the API and web builds used to share one `build` stage, so the final `api` image's `COPY --from=build` transitively depended on the *web* build succeeding as well (and vice versa). `Dockerfile` now splits this into three stages: `build-shared` (compiles the four shared packages once), then independent `build-api` and `build-web` stages both extending from it — so a break in one app's build can no longer block the other's image.
- **Docker build networking** — see below.

### Docker build networking

`docker build`/`docker compose build` run `npm install` and `prisma generate` inside the build container, which needs outbound access to npm's registry (and, for Prisma, its engine-binary CDN). If you're building behind a restrictive proxy, pass it through with `--build-arg HTTP_PROXY=... --build-arg HTTPS_PROXY=...` (and add corresponding `ARG`/`ENV` lines to the `deps` stage in `Dockerfile`), or build on a network-unrestricted machine and push the resulting images.

---

## Safety & risk warnings

- **This system does not and cannot guarantee profitable trades.** Every prediction carries an explicit confidence score and a plain-language reason; treat both skeptically.
- **Defaults to paper trading.** `EXECUTION_MODE` must be explicitly set to `LIVE`, and a real broker adapter must be implemented and wired in, before any real money is at risk. Nothing here fabricates a successful trade — a failed or unsupported execution is always reported as an error, never silently treated as a fill.
- When market data is stale or incomplete, or indicators disagree, the engine returns `NO_TRADE` with an explicit reason (`MARKET DATA STALE`, `INSUFFICIENT MARKET DATA`, `SIGNAL CONFLICT`, `SPREAD TOO WIDE`, …) rather than guessing.
- Risk limits (max risk/trade, max daily loss, max consecutive losses, max trades/hour, cooldown, kill switch) are enforced by a component (`RiskManager`) that is independent of the prediction engine and can halt the bot on its own.
- This project is provided for educational/experimental purposes. You are solely responsible for how you configure and operate it, and for complying with the terms of service of any exchange or prediction market you connect it to.

---

## Known limitations

- **Live trading has no default broker.** See [§7](#7-live-trading) — this is by design, not an oversight.
- **Backtest book-ticker data is approximated** from kline taker-volume splits, since free historical L2 order-book data isn't available (see [§10](#10-backtesting)).
- The **frontend has no automated test suite** — the spec's test requirements (indicators, prediction scenarios, risk limits, trading engine, WebSocket) are all backend/shared-package concerns and are covered there; UI testing (component/e2e) would be a reasonable next addition (e.g. Vitest + Testing Library, or Playwright).
- The market-structure detector (`detectMarketStructure`) uses a simple fixed-lookback 3-bar fractal definition for swing highs/lows — adequate and explainable, but not a substitute for a dedicated pivot/zig-zag library if you need more sophisticated support/resistance detection.
